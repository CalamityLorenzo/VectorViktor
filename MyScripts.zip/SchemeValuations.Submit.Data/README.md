# SchemeValuations.Submit.Data

This project is an EF Core 10 (.NET 10) conversion of the `SchemeValuations.Submit.Databases.SchemeValuation` SQL database project (`myscripts`). It covers the tables, views, reference data, schemas and the `db_reportreader` role.

The database project's 25 stored procedures have been rewritten as C# methods, and the database no longer contains any stored procedures.

## Layout

| Path | Contents |
|---|---|
| `SchemeValuationDbContext.cs` | The context, with DbSets for every table and view. |
| `Services/SchemeValuationCommands.cs` | Write operations that replace `usp_Write_*` and `usp_Create_EventById`. |
| `Services/SchemeValuationQueries.cs` | Read operations that replace `usp_Read_*` and `usp_Report_Recent_Submissions_By_Date`. |
| `Services/Results.cs` | Result types returned by the queries. |
| `ReferenceDataIds.cs` | Named constants for event types, statuses and other reference data ids, e.g. `SubmissionStatusTypeIds.Superseded`. |
| `Entities/` | Table entities. Rows tracked by events implement `IEventTracked` (StartEvent/EndEvent navigations). |
| `Entities/Messaging/` | NServiceBus outbox and saga tables in the `SharePointEndpoint`, `WebEndpoint` and `WebSagaEndpoint` schemas. |
| `Entities/Views/` | Keyless, read-only types mapped to the `uvw_*` views. |
| `Configurations/` | Fluent mappings: column types, constraint and index names, INCLUDE columns, filtered indexes and reference data seed rows. |
| `Sql/Views` | The view definitions, as `CREATE OR ALTER` scripts compiled in as embedded resources. |
| `Migrations/` | `InitialCreate` creates the tables and reference data. `AddViews` creates the views and the report role. |

## Usage

```csharp
services.AddSchemeValuationDbContext(connectionString); // also registers SchemeValuationCommands and SchemeValuationQueries (scoped)

// Each stored procedure is now a method with the same name, e.g. usp_Write_ValuationSubmission:
var id = await commands.WriteValuationSubmissionAsync(svsId, psr, schemeName, effectiveDate, userId, EventSourceTypeIds.SchemeValuationSubmission);
var saved = await queries.ReadUserSavedSubmissionAsync(psr);

// Or query tables and views directly
var current = await db.SchemeValuationSubmissionsCurrent.Where(s => s.PSRNumber == psr).ToListAsync();
```

### How the commands behave

- **Audit trail:** every change creates an `Event` row. New rows use it as their `StartEventReference`. The rows they replace are soft-deleted by setting their `EndEventReference` to it. This is the same model the procedures used.
- **Transactions:** each command runs in its own transaction. If the context already has a transaction open, the command joins it instead, so several commands can be committed or rolled back together. Commands go through the execution strategy, so they also work with `EnableRetryOnFailure`.
- **Saving:** commands call `SaveChanges`, so any unsaved changes already in the context are saved along with them. Rows the commands insert are detached afterwards, so the change tracker never holds stale copies.
- **String matching:** comparisons such as scheme names, case references and file names run in SQL, so they stay case-insensitive under the database collation, as before.
- **Errors:** business rule failures throw `SchemeValuationDataException` with the procedures' original messages. Constraint violations still surface as `DbUpdateException`.

### Verified against the original procedures

The same scenario was run through the original stored procedures and through these services, on two fresh databases. It covered every write path, including replacements, idempotent repeats, supersede and cancel, and error cases. The resulting tables matched row for row, identity values included. Every return value and error message also matched, apart from the two intentional changes listed below.

## Behaviour changes from the stored procedures

- **`WriteValuationSubmissionDataAsync` fixes a data-loss bug.** When a document already had extracted data, the procedure end-dated that row but never inserted the new one, so re-extracting a document left it with no current data. The new code always inserts the new data.
- **`ReadSubmittedSubmissionAsync` now throws when the submission is not in Submitted status.** The procedure's status checks could never fire, so for an in-progress, cancelled, superseded or unknown submission it returned a row of nulls. The new code throws `SchemeValuationDataException`, using the procedure's intended messages.
- **Where a procedure end-dated one arbitrary "current" row, the code end-dates all current rows.** This affects confirmation dates and submission status. The result is the same while the one-current-row rule holds.
- **User ids are no longer truncated.** The procedures declared `@UserId VARCHAR(50)`, which silently cut longer ids to 50 characters even though `Event.UserId` is `varchar(300)`.
- **The procedures only rolled back their own work.** When a procedure failed, it rolled back the caller's whole transaction. A failing command now leaves the caller's transaction for the caller to handle.
- **`db_reportreader` is still created, but it no longer has anything to execute.** It used to be granted EXECUTE on the report procedure. The reporting account needs another route, for example SELECT on the views, or a report built on `ReportRecentSubmissionsByDateAsync`.

## Deploying

The design-time factory targets `(localdb)\MSSQLLocalDB`, database `SchemeValuation`. To target a different database, set `SCHEMEVALUATION_CONNECTIONSTRING`.

```powershell
dotnet ef database update --project SchemeValuations.Submit.Data
dotnet ef migrations script --idempotent --project SchemeValuations.Submit.Data -o deploy.sql   # for DBA / pipeline deployment
```

### Existing databases deployed from the DACPAC

These databases already contain the tables, so `InitialCreate` must not run against them. Record it as applied instead. `AddViews` uses `CREATE OR ALTER`, so it can run normally afterwards.

```sql
IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
    CREATE TABLE [__EFMigrationsHistory] ([MigrationId] nvarchar(150) NOT NULL, [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId]));
INSERT INTO [__EFMigrationsHistory] VALUES (N'20260928150543_InitialCreate', N'10.0.12');
```

The existing stored procedures are left in place, so anything that still calls them keeps working. Once nothing calls them, drop them:

```sql
DROP PROCEDURE IF EXISTS dbo.usp_Create_EventById, dbo.usp_Read_CaseReferenceData, dbo.usp_Read_DocumentMetadata,
    dbo.usp_Read_DynamicUserJourney, dbo.usp_Read_IsUserSubmissionInProgress, dbo.usp_Read_PsrHasUserSubmissionInProgress,
    dbo.usp_Read_Submission, dbo.usp_Read_SubmittedSubmission, dbo.usp_Read_UserSavedAndValuationSubmission,
    dbo.usp_Read_UserSavedSubmission, dbo.usp_Read_ValuationSubmissionId, dbo.usp_Report_Recent_Submissions_By_Date,
    dbo.usp_Write_CancelDocument, dbo.usp_Write_Document, dbo.usp_Write_DocumentStatus, dbo.usp_Write_DynamicUserJourney,
    dbo.usp_Write_UserSavedSubmission, dbo.usp_Write_ValuationCase, dbo.usp_Write_ValuationScheme,
    dbo.usp_Write_ValuationSubmission, dbo.usp_Write_ValuationSubmissionConfirmationDates,
    dbo.usp_Write_ValuationSubmissionData, dbo.usp_Write_ValuationSubmissionGuardQuestionAnswer,
    dbo.usp_Write_ValuationSubmissionStatus, dbo.usp_Write_ValuationSubmittedDetail;
```

## Changing things

- **Tables and reference data:** change the entity, configuration or `HasData` rows, then run `dotnet ef migrations add <Name>`.
- **Views:** `AddViews` reads the current files in `Sql/Views`, so editing a file also changes what that migration deploys. To ship a change:
  1. Edit the file.
  2. Add a migration that re-applies it, for example `migrationBuilder.Sql(SqlScripts.View("uvw_ValuationCase"))`.

  If the new definition depends on a column added in that same later migration, don't edit the file in place. Put the new definition in a new file, or inline in the new migration. Otherwise a fresh deployment fails at `AddViews`.

## Other differences from the database project

- `FK_ValuationSubmissionStatus_Event` is not recreated. It duplicated `FK_ValuationSubmissionStatus_Event_End` on the same column, and EF allows only one relationship per column.
- The database project leaves some constraints to SQL Server to name: the outbox/saga primary keys and all defaults except `DF_Event_CreateDateTime` and `DF_Event_EventSourceType`. EF now gives these its own deterministic names.
- The `Script/SchemaChanges` pre/post-deployment scripts are not carried over. They are guarded, one-off upgrades from older schema versions and do nothing on a current database.
- `dbo.UserManagedSubmissionStatusType.sql`, `usp_Write_UserManagedSubmission.sql` and `usp_Write_UserManagedSubmissionStatus.sql` in the project root are empty files, so there was nothing to convert.
- Columns with a database default (`IsActive`, `IsExcludedSubmission`, `IsMultiDocUpload`, `Dispatched`, `SagaUploadedFileCorrelationId`, `Event.EventSourceTypeId`) keep the default for raw SQL inserts. EF always sends the property value, so an EF insert with `IsActive = false` is not overridden by the column default of 1. `Event.CreateDateTime` still uses `getdate()` when left unset.
