namespace SchemeValuations.Submit.Data.Entities;

public class ValuationCase : IEventTracked
{
    public int ValuationCaseId { get; set; }

    public int ValuationSubmissionId { get; set; }

    /// <summary>The case reference assigned by D365.</summary>
    public string CaseReference { get; set; } = null!;

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
