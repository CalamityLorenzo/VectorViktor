namespace SchemeValuations.Submit.Data.Entities.Views;

/// <summary>dbo.uvw_Documents_Current: current documents with their type and current status.</summary>
public class DocumentCurrentView
{
    public int DocumentId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public string UploadedFileName { get; set; } = null!;

    public string InternalFileName { get; set; } = null!;

    public string FileHash { get; set; } = null!;

    public long? FileSize { get; set; }

    public Guid SagaUploadedFileCorrelationId { get; set; }

    public short DocumentTypeId { get; set; }

    public string DocumentTypeDescription { get; set; } = null!;

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public int? DocumentStatusId { get; set; }

    public short? DocumentStatusTypeId { get; set; }

    public string? DocumentStatusName { get; set; }

    public string? DocumentStatusDescription { get; set; }

    public bool? IsActive { get; set; }
}
