namespace SchemeValuations.Submit.Data.Entities.Views;

/// <summary>dbo.uvw_ValuationCase: all (past and current) ValuationCase rows for current valuation submissions.</summary>
public class ValuationCaseView
{
    public int ValuationCaseId { get; set; }

    public int ValuationSchemeId { get; set; }

    public int PSRNumber { get; set; }

    public string SchemeName { get; set; } = null!;

    public int ValuationSubmissionId { get; set; }

    public string CaseReference { get; set; } = null!;

    public int StartEventReference { get; set; }

    public DateTime CreateDateTime { get; set; }

    public string StartEventUser { get; set; } = null!;

    public DateTime? NotificationDate { get; set; }

    public int? EndEventReference { get; set; }

    public DateTime? EndEventDateTime { get; set; }

    public string? EndEventUser { get; set; }

    public string? EventTypeDescription { get; set; }

    public string SchemeValuationSubmissionId { get; set; } = null!;

    public DateOnly EffectiveDate { get; set; }
}
