namespace SchemeValuations.Submit.Data.Entities.Views;

/// <summary>dbo.uvw_ValuationSubmissionGuardQuestionAnswers_Current: current guard question answers for current submissions.</summary>
public class ValuationSubmissionGuardQuestionAnswerCurrentView
{
    public int ValuationSchemeId { get; set; }

    public int PSRNumber { get; set; }

    public string SchemeName { get; set; } = null!;

    public int ValuationSubmissionId { get; set; }

    public string SchemeValuationSubmissionId { get; set; } = null!;

    public DateOnly EffectiveDate { get; set; }

    public int GuardQuestionId { get; set; }

    public string GuardQuestionName { get; set; } = null!;

    public string GuardQuestionDescription { get; set; } = null!;

    public bool IsActive { get; set; }

    public int GuardQuestionAnswerId { get; set; }

    public string GuardAnswerName { get; set; } = null!;

    public string GuardAnswerDescription { get; set; } = null!;

    public int ValuationSubmissionGuardQuestionAnswerId { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }
}
