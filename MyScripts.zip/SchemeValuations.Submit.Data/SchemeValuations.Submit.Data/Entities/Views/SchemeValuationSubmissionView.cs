namespace SchemeValuations.Submit.Data.Entities.Views;

/// <summary>Columns shared by dbo.uvw_SchemeValuationSubmissions and dbo.uvw_SchemeValuationSubmissions_Current.</summary>
public abstract class SchemeValuationSubmissionViewBase
{
    public int ValuationSchemeId { get; set; }

    public int PSRNumber { get; set; }

    public string SchemeName { get; set; } = null!;

    public int ValuationSubmissionId { get; set; }

    public string SchemeValuationSubmissionId { get; set; } = null!;

    public DateOnly EffectiveDate { get; set; }

    public DateOnly? DateFundingAndInvestmentStrategyWasFinalised { get; set; }

    public DateOnly? DateStatementOfStrategyWasSigned { get; set; }

    public int? ValuationSubmissionStatusId { get; set; }

    public short? SubmissionStatusTypeId { get; set; }

    public bool IsExcludedSubmission { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public DateTime CreateDateTime { get; set; }

    public string UserId { get; set; } = null!;

    public DateTime? SubmittedDateTime { get; set; }

    public string? SubmittedUserId { get; set; }
}

/// <summary>dbo.uvw_SchemeValuationSubmissions: all valuation submissions (current and end-dated) with their scheme.</summary>
public class SchemeValuationSubmissionView : SchemeValuationSubmissionViewBase;

/// <summary>dbo.uvw_SchemeValuationSubmissions_Current: valuation submissions that have not been end-dated.</summary>
public class SchemeValuationSubmissionCurrentView : SchemeValuationSubmissionViewBase;
