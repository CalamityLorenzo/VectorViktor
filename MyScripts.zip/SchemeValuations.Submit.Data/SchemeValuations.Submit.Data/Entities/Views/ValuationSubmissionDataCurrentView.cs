namespace SchemeValuations.Submit.Data.Entities.Views;

/// <summary>dbo.uvw_ValuationSubmissionData_Current: data extracted from the current Statement of Strategy spreadsheet.</summary>
public class ValuationSubmissionDataCurrentView
{
    public int DocumentId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public int ValuationSubmissionDataId { get; set; }

    public string QuestionsAndResponses { get; set; } = null!;

    public DateTime CreateDateTime { get; set; }

    public string StartEventUser { get; set; } = null!;

    public DateTime? NotificationDate { get; set; }

    public string? CreateEvent { get; set; }

    public int? EndEventReference { get; set; }

    public DateTime? EndEventDateTime { get; set; }

    public string? EndEventUser { get; set; }

    public string? EndEvent { get; set; }
}
