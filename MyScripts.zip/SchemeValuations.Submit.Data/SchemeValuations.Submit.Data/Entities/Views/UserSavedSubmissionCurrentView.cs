namespace SchemeValuations.Submit.Data.Entities.Views;

/// <summary>dbo.uvw_UserSavedSubmissions_Current: current (not soft-deleted) user-saved submissions and their statuses.</summary>
public class UserSavedSubmissionCurrentView
{
    public int UserSavedSubmissionId { get; set; }

    public int PSRNumber { get; set; }

    public string SchemeValuationSubmissionId { get; set; } = null!;

    public DateOnly EffectiveDate { get; set; }

    public string? CaseReference { get; set; }

    public DateTime LastUpdated { get; set; }

    public Guid LastActionPageId { get; set; }

    public string LastPageData { get; set; } = null!;

    public int UserSavedSubmissionStartEventReference { get; set; }

    public string SchemeName { get; set; } = null!;

    public int ValuationSchemeId { get; set; }

    public short SubmissionStatusTypeId { get; set; }

    public string SubmissionStatusDescription { get; set; } = null!;

    public DateTime ValuationSubmissionCreateDateTime { get; set; }

    public int ValuationSubmissionId { get; set; }

    public DateOnly? DateFundingAndInvestmentStrategyWasFinalised { get; set; }

    public DateOnly? DateStatementOfStrategyWasSigned { get; set; }

    public bool IsExcludedSubmission { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public DateTime CreateDateTime { get; set; }

    public string ValuationSubmissionUserId { get; set; } = null!;

    public int? DynamicUserJourneyId { get; set; }

    public short? AdditionalRequiredDocumentTypeId { get; set; }

    public string? AdditionalRequiredDocumentDescription { get; set; }

    public short? FastTrackOrBespokeTypeId { get; set; }

    public string? FastTrackOrBespokeDescription { get; set; }

    public short? DeficitOrSurplusTypeId { get; set; }

    public string? DeficitOrSurplusDescription { get; set; }

    public bool? IsMultiDocUpload { get; set; }
}
