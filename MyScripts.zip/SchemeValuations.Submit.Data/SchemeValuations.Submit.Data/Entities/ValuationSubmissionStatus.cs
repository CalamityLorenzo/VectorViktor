namespace SchemeValuations.Submit.Data.Entities;

public class ValuationSubmissionStatus : IEventTracked
{
    public int ValuationSubmissionStatusId { get; set; }

    public short SubmissionStatusTypeId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public SubmissionStatusType SubmissionStatusType { get; set; } = null!;

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
