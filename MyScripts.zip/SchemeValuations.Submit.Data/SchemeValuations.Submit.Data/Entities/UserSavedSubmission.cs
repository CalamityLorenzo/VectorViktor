namespace SchemeValuations.Submit.Data.Entities;

public class UserSavedSubmission : IEventTracked
{
    public int UserSavedSubmissionId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public DateTime LastUpdated { get; set; }

    public Guid LastActionPageId { get; set; }

    public string LastPageData { get; set; } = null!;

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
