namespace SchemeValuations.Submit.Data.Entities;

public class ValuationSubmittedDetail : IEventTracked
{
    public int ValuationSubmittedDetailId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public DateTime SubmittedDateTime { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
