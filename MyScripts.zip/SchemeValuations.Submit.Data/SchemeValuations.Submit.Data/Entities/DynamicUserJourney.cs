namespace SchemeValuations.Submit.Data.Entities;

public class DynamicUserJourney : IEventTracked
{
    public int DynamicUserJourneyId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public short FastTrackOrBespokeTypeId { get; set; }

    public short DeficitOrSurplusTypeId { get; set; }

    public short AdditionalRequiredDocumentTypeId { get; set; }

    public bool IsMultiDocUpload { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public FastTrackOrBespokeType FastTrackOrBespokeType { get; set; } = null!;

    public DeficitOrSurplusType DeficitOrSurplusType { get; set; } = null!;

    public AdditionalRequiredDocumentType AdditionalRequiredDocumentType { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
