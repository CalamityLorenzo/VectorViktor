namespace SchemeValuations.Submit.Data.Entities;

public class ValuationSubmissionConfirmationDates : IEventTracked
{
    public int ValuationSubmissionConfirmationDatesId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public DateOnly DateFundingAndInvestmentStrategyWasFinalised { get; set; }

    public DateOnly DateStatementOfStrategyWasSigned { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
