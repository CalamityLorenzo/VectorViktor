namespace SchemeValuations.Submit.Data.Entities;

public class ValuationSubmission : IEventTracked
{
    public int ValuationSubmissionId { get; set; }

    public int ValuationSchemeId { get; set; }

    /// <summary>The id used throughout TPR to uniquely identify an individual valuation submission version.</summary>
    public string SchemeValuationSubmissionId { get; set; } = null!;

    public DateOnly EffectiveDate { get; set; }

    public bool IsExcludedSubmission { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationScheme ValuationScheme { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }

    public ICollection<Document> Documents { get; set; } = new List<Document>();

    public ICollection<DynamicUserJourney> DynamicUserJourneys { get; set; } = new List<DynamicUserJourney>();

    public ICollection<Event> Events { get; set; } = new List<Event>();

    public ICollection<UserSavedSubmission> UserSavedSubmissions { get; set; } = new List<UserSavedSubmission>();

    public ICollection<ValuationCase> ValuationCases { get; set; } = new List<ValuationCase>();

    public ICollection<ValuationSubmissionConfirmationDates> ValuationSubmissionConfirmationDates { get; set; } = new List<ValuationSubmissionConfirmationDates>();

    public ICollection<ValuationSubmissionGuardQuestionAnswer> ValuationSubmissionGuardQuestionAnswers { get; set; } = new List<ValuationSubmissionGuardQuestionAnswer>();

    public ICollection<ValuationSubmissionStatus> ValuationSubmissionStatuses { get; set; } = new List<ValuationSubmissionStatus>();

    public ICollection<ValuationSubmittedDetail> ValuationSubmittedDetails { get; set; } = new List<ValuationSubmittedDetail>();
}
