namespace SchemeValuations.Submit.Data.Entities;

// Reference data tables. Rows are seeded by the model (see Configurations/LookupConfigurations.cs),
// replacing the Script/ReferenceData post-deployment scripts of the database project.

public class AdditionalRequiredDocumentType
{
    public short AdditionalRequiredDocumentTypeId { get; set; }

    public string AdditionalRequiredDocumentName { get; set; } = null!;

    public string AdditionalRequiredDocumentDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class DeficitOrSurplusType
{
    public short DeficitOrSurplusTypeId { get; set; }

    public string DeficitOrSurplusName { get; set; } = null!;

    public string DeficitOrSurplusDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class DocumentStatusType
{
    public short DocumentStatusTypeId { get; set; }

    public string DocumentStatusName { get; set; } = null!;

    public string DocumentStatusDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class DocumentType
{
    public short DocumentTypeId { get; set; }

    public string DocumentTypeName { get; set; } = null!;

    public string DocumentTypeDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class EventSourceType
{
    public short EventSourceTypeId { get; set; }

    public string EventSourceName { get; set; } = null!;

    public string EventSourceDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class EventType
{
    public short EventTypeId { get; set; }

    public string EventTypeName { get; set; } = null!;

    public string EventTypeDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class FastTrackOrBespokeType
{
    public short FastTrackOrBespokeTypeId { get; set; }

    public string FastTrackOrBespokeName { get; set; } = null!;

    public string FastTrackOrBespokeDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}

public class GuardQuestion
{
    public int GuardQuestionId { get; set; }

    public string GuardQuestionName { get; set; } = null!;

    public string GuardQuestionDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;

    public ICollection<GuardQuestionAnswer> GuardQuestionAnswers { get; set; } = new List<GuardQuestionAnswer>();
}

public class GuardQuestionAnswer
{
    public int GuardQuestionAnswerId { get; set; }

    public int GuardQuestionId { get; set; }

    public string GuardAnswerName { get; set; } = null!;

    public string GuardAnswerDescription { get; set; } = null!;

    public GuardQuestion GuardQuestion { get; set; } = null!;
}

public class SubmissionStatusType
{
    public short SubmissionStatusTypeId { get; set; }

    public string SubmissionStatusName { get; set; } = null!;

    public string SubmissionStatusDescription { get; set; } = null!;

    public bool IsActive { get; set; } = true;
}
