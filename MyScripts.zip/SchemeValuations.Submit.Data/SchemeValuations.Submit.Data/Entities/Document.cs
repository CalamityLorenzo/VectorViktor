namespace SchemeValuations.Submit.Data.Entities;

public class Document : IEventTracked
{
    public int DocumentId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public string UploadedFileName { get; set; } = null!;

    public string InternalFileName { get; set; } = null!;

    public string FileHash { get; set; } = null!;

    public long? FileSize { get; set; }

    public Guid SagaUploadedFileCorrelationId { get; set; }

    public short DocumentTypeId { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public DocumentType DocumentType { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }

    public ICollection<DocumentStatus> DocumentStatuses { get; set; } = new List<DocumentStatus>();

    public ICollection<ValuationSubmissionData> ValuationSubmissionData { get; set; } = new List<ValuationSubmissionData>();
}
