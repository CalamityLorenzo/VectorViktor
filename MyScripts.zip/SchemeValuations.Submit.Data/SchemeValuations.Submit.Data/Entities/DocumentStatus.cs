namespace SchemeValuations.Submit.Data.Entities;

public class DocumentStatus : IEventTracked
{
    public int DocumentStatusId { get; set; }

    public short DocumentStatusTypeId { get; set; }

    public int DocumentId { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public DocumentStatusType DocumentStatusType { get; set; } = null!;

    public Document Document { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
