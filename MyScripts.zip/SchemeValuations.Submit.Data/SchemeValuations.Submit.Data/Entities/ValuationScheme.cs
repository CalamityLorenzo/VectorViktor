namespace SchemeValuations.Submit.Data.Entities;

public class ValuationScheme : IEventTracked
{
    public int ValuationSchemeId { get; set; }

    public int PSRNumber { get; set; }

    public string SchemeName { get; set; } = null!;

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }

    public ICollection<ValuationSubmission> ValuationSubmissions { get; set; } = new List<ValuationSubmission>();
}
