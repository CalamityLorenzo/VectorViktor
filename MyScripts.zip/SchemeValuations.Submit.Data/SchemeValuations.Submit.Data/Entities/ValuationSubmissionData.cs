namespace SchemeValuations.Submit.Data.Entities;

public class ValuationSubmissionData : IEventTracked
{
    public int ValuationSubmissionDataId { get; set; }

    /// <summary>JSON representation of the valuation data extracted from the uploaded Excel form.</summary>
    public string QuestionsAndResponses { get; set; } = null!;

    public int DocumentId { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public Document Document { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
