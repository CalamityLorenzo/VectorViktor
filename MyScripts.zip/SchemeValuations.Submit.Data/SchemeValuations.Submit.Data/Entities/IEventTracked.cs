namespace SchemeValuations.Submit.Data.Entities;

/// <summary>
/// A row whose lifetime is bounded by two <see cref="Event"/> rows. A row is "current" while
/// <see cref="EndEventReference"/> is null; superseded rows are soft-deleted by setting it.
/// </summary>
public interface IEventTracked
{
    int StartEventReference { get; set; }

    int? EndEventReference { get; set; }

    Event StartEvent { get; set; }

    Event? EndEvent { get; set; }
}
