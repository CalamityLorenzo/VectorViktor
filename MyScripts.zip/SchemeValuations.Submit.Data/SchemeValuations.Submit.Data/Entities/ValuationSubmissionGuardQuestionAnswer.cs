namespace SchemeValuations.Submit.Data.Entities;

public class ValuationSubmissionGuardQuestionAnswer : IEventTracked
{
    public int ValuationSubmissionGuardQuestionAnswerId { get; set; }

    public int ValuationSubmissionId { get; set; }

    public int GuardQuestionAnswerId { get; set; }

    public int StartEventReference { get; set; }

    public int? EndEventReference { get; set; }

    public ValuationSubmission ValuationSubmission { get; set; } = null!;

    public GuardQuestionAnswer GuardQuestionAnswer { get; set; } = null!;

    public Event StartEvent { get; set; } = null!;

    public Event? EndEvent { get; set; }
}
