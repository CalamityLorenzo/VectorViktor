namespace SchemeValuations.Submit.Data.Entities.Messaging;

/// <summary>NServiceBus SQL persistence saga data for the SubmitSchemeValuation saga.</summary>
public class SubmitSchemeValuationSaga
{
    public Guid Id { get; set; }

    public string Metadata { get; set; } = null!;

    public string Data { get; set; } = null!;

    public string PersistenceVersion { get; set; } = null!;

    public string SagaTypeVersion { get; set; } = null!;

    public int Concurrency { get; set; }

    /// <summary>Maps to column Correlation_SchemeValuationSubmissionId.</summary>
    public string? CorrelationSchemeValuationSubmissionId { get; set; }
}
