namespace SchemeValuations.Submit.Data.Entities.Messaging;

/// <summary>
/// NServiceBus SQL outbox record. The same table shape exists in each endpoint schema,
/// so each schema gets its own derived entity type (the base type is not part of the model).
/// </summary>
public abstract class OutboxData
{
    public string MessageId { get; set; } = null!;

    public bool Dispatched { get; set; }

    public DateTime? DispatchedAt { get; set; }

    public string PersistenceVersion { get; set; } = null!;

    public string Operations { get; set; } = null!;
}

public class SharePointEndpointOutboxData : OutboxData;

public class WebEndpointOutboxData : OutboxData;

public class WebSagaEndpointOutboxData : OutboxData;
