namespace SchemeValuations.Submit.Data.Entities;

/// <summary>
/// Audit record for every data change. Other tables reference it through their
/// StartEventReference / EndEventReference columns.
/// </summary>
public class Event
{
    public int EventReference { get; set; }

    public short EventTypeId { get; set; }

    public int? ValuationSubmissionId { get; set; }

    public string? SchemeValuationSubmissionId { get; set; }

    public string UserId { get; set; } = null!;

    /// <summary>Defaults to GETDATE() in the database when left unset.</summary>
    public DateTime CreateDateTime { get; set; }

    public string? TransactionId { get; set; }

    public DateTime? NotificationDate { get; set; }

    public short EventSourceTypeId { get; set; }

    public EventType EventType { get; set; } = null!;

    public EventSourceType EventSourceType { get; set; } = null!;

    public ValuationSubmission? ValuationSubmission { get; set; }
}
