﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace SchemeValuations.Submit.Data.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "SharePointEndpoint");

            migrationBuilder.EnsureSchema(
                name: "WebEndpoint");

            migrationBuilder.EnsureSchema(
                name: "WebSagaEndpoint");

            migrationBuilder.CreateTable(
                name: "AdditionalRequiredDocumentType",
                columns: table => new
                {
                    AdditionalRequiredDocumentTypeId = table.Column<short>(type: "smallint", nullable: false),
                    AdditionalRequiredDocumentName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    AdditionalRequiredDocumentDescription = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdditionalRequiredDocumentType", x => x.AdditionalRequiredDocumentTypeId);
                });

            migrationBuilder.CreateTable(
                name: "DeficitOrSurplusType",
                columns: table => new
                {
                    DeficitOrSurplusTypeId = table.Column<short>(type: "smallint", nullable: false),
                    DeficitOrSurplusName = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    DeficitOrSurplusDescription = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeficitOrSurplusType", x => x.DeficitOrSurplusTypeId);
                });

            migrationBuilder.CreateTable(
                name: "DocumentStatusType",
                columns: table => new
                {
                    DocumentStatusTypeId = table.Column<short>(type: "smallint", nullable: false),
                    DocumentStatusName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    DocumentStatusDescription = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentStatusType", x => x.DocumentStatusTypeId);
                });

            migrationBuilder.CreateTable(
                name: "DocumentType",
                columns: table => new
                {
                    DocumentTypeId = table.Column<short>(type: "smallint", nullable: false),
                    DocumentTypeName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    DocumentTypeDescription = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentType", x => x.DocumentTypeId);
                });

            migrationBuilder.CreateTable(
                name: "EventSourceType",
                columns: table => new
                {
                    EventSourceTypeId = table.Column<short>(type: "smallint", nullable: false),
                    EventSourceName = table.Column<string>(type: "varchar(75)", unicode: false, maxLength: 75, nullable: false),
                    EventSourceDescription = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventSourceType", x => x.EventSourceTypeId);
                });

            migrationBuilder.CreateTable(
                name: "EventType",
                columns: table => new
                {
                    EventTypeId = table.Column<short>(type: "smallint", nullable: false),
                    EventTypeName = table.Column<string>(type: "varchar(75)", unicode: false, maxLength: 75, nullable: false),
                    EventTypeDescription = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventType", x => x.EventTypeId);
                });

            migrationBuilder.CreateTable(
                name: "FastTrackOrBespokeType",
                columns: table => new
                {
                    FastTrackOrBespokeTypeId = table.Column<short>(type: "smallint", nullable: false),
                    FastTrackOrBespokeName = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    FastTrackOrBespokeDescription = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FastTrackOrBespokeType", x => x.FastTrackOrBespokeTypeId);
                });

            migrationBuilder.CreateTable(
                name: "GuardQuestion",
                columns: table => new
                {
                    GuardQuestionId = table.Column<int>(type: "int", nullable: false),
                    GuardQuestionName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    GuardQuestionDescription = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GuardQuestion", x => x.GuardQuestionId);
                });

            migrationBuilder.CreateTable(
                name: "OutboxData",
                schema: "SharePointEndpoint",
                columns: table => new
                {
                    MessageId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Dispatched = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    DispatchedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    PersistenceVersion = table.Column<string>(type: "varchar(23)", unicode: false, maxLength: 23, nullable: false),
                    Operations = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OutboxData", x => x.MessageId)
                        .Annotation("SqlServer:Clustered", false);
                });

            migrationBuilder.CreateTable(
                name: "OutboxData",
                schema: "WebEndpoint",
                columns: table => new
                {
                    MessageId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Dispatched = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    DispatchedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    PersistenceVersion = table.Column<string>(type: "varchar(23)", unicode: false, maxLength: 23, nullable: false),
                    Operations = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OutboxData", x => x.MessageId)
                        .Annotation("SqlServer:Clustered", false);
                });

            migrationBuilder.CreateTable(
                name: "OutboxData",
                schema: "WebSagaEndpoint",
                columns: table => new
                {
                    MessageId = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Dispatched = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    DispatchedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    PersistenceVersion = table.Column<string>(type: "varchar(23)", unicode: false, maxLength: 23, nullable: false),
                    Operations = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OutboxData", x => x.MessageId)
                        .Annotation("SqlServer:Clustered", false);
                });

            migrationBuilder.CreateTable(
                name: "SubmissionStatusType",
                columns: table => new
                {
                    SubmissionStatusTypeId = table.Column<short>(type: "smallint", nullable: false),
                    SubmissionStatusName = table.Column<string>(type: "varchar(16)", unicode: false, maxLength: 16, nullable: false),
                    SubmissionStatusDescription = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubmissionStatusType", x => x.SubmissionStatusTypeId);
                });

            migrationBuilder.CreateTable(
                name: "SubmitSchemeValuationSaga",
                schema: "WebSagaEndpoint",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Metadata = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Data = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PersistenceVersion = table.Column<string>(type: "varchar(23)", unicode: false, maxLength: 23, nullable: false),
                    SagaTypeVersion = table.Column<string>(type: "varchar(23)", unicode: false, maxLength: 23, nullable: false),
                    Concurrency = table.Column<int>(type: "int", nullable: false),
                    Correlation_SchemeValuationSubmissionId = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubmitSchemeValuationSaga", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GuardQuestionAnswer",
                columns: table => new
                {
                    GuardQuestionAnswerId = table.Column<int>(type: "int", nullable: false),
                    GuardQuestionId = table.Column<int>(type: "int", nullable: false),
                    GuardAnswerName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    GuardAnswerDescription = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GuardQuestionAnswer", x => x.GuardQuestionAnswerId);
                    table.ForeignKey(
                        name: "FK_GuardQuestionAnswer_GuardQuestion",
                        column: x => x.GuardQuestionId,
                        principalTable: "GuardQuestion",
                        principalColumn: "GuardQuestionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Document",
                columns: table => new
                {
                    DocumentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    UploadedFileName = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    InternalFileName = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    FileHash = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: false),
                    FileSize = table.Column<long>(type: "bigint", nullable: true),
                    SagaUploadedFileCorrelationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "CAST(0x0 AS UNIQUEIDENTIFIER)"),
                    DocumentTypeId = table.Column<short>(type: "smallint", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Document", x => x.DocumentId);
                    table.ForeignKey(
                        name: "FK_Document_DocumentType",
                        column: x => x.DocumentTypeId,
                        principalTable: "DocumentType",
                        principalColumn: "DocumentTypeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DocumentStatus",
                columns: table => new
                {
                    DocumentStatusId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentStatusTypeId = table.Column<short>(type: "smallint", nullable: false),
                    DocumentId = table.Column<int>(type: "int", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentStatus", x => x.DocumentStatusId);
                    table.ForeignKey(
                        name: "FK_DocumentStatus_Document",
                        column: x => x.DocumentId,
                        principalTable: "Document",
                        principalColumn: "DocumentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DocumentStatus_DocumentStatusType",
                        column: x => x.DocumentStatusTypeId,
                        principalTable: "DocumentStatusType",
                        principalColumn: "DocumentStatusTypeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DynamicUserJourney",
                columns: table => new
                {
                    DynamicUserJourneyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    FastTrackOrBespokeTypeId = table.Column<short>(type: "smallint", nullable: false),
                    DeficitOrSurplusTypeId = table.Column<short>(type: "smallint", nullable: false),
                    AdditionalRequiredDocumentTypeId = table.Column<short>(type: "smallint", nullable: false),
                    IsMultiDocUpload = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DynamicUserJourney", x => x.DynamicUserJourneyId);
                    table.ForeignKey(
                        name: "FK_DynamicUserJourney_AdditionalRequiredDocumentType",
                        column: x => x.AdditionalRequiredDocumentTypeId,
                        principalTable: "AdditionalRequiredDocumentType",
                        principalColumn: "AdditionalRequiredDocumentTypeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DynamicUserJourney_DeficitOrSurplusType",
                        column: x => x.DeficitOrSurplusTypeId,
                        principalTable: "DeficitOrSurplusType",
                        principalColumn: "DeficitOrSurplusTypeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DynamicUserJourney_FastTrackOrBespokeType",
                        column: x => x.FastTrackOrBespokeTypeId,
                        principalTable: "FastTrackOrBespokeType",
                        principalColumn: "FastTrackOrBespokeTypeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Event",
                columns: table => new
                {
                    EventReference = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EventTypeId = table.Column<short>(type: "smallint", nullable: false),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: true),
                    SchemeValuationSubmissionId = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    UserId = table.Column<string>(type: "varchar(300)", unicode: false, maxLength: 300, nullable: false),
                    CreateDateTime = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "getdate()")
                        .Annotation("Relational:DefaultConstraintName", "DF_Event_CreateDateTime"),
                    TransactionId = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    NotificationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EventSourceTypeId = table.Column<short>(type: "smallint", nullable: false, defaultValue: (short)0)
                        .Annotation("Relational:DefaultConstraintName", "DF_Event_EventSourceType")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Event", x => x.EventReference);
                    table.ForeignKey(
                        name: "FK_Event_EventSourceType",
                        column: x => x.EventSourceTypeId,
                        principalTable: "EventSourceType",
                        principalColumn: "EventSourceTypeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Event_EventType",
                        column: x => x.EventTypeId,
                        principalTable: "EventType",
                        principalColumn: "EventTypeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationScheme",
                columns: table => new
                {
                    ValuationSchemeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PSRNumber = table.Column<int>(type: "int", nullable: false),
                    SchemeName = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationScheme", x => x.ValuationSchemeId);
                    table.ForeignKey(
                        name: "FK_ValuationScheme_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationScheme_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationSubmissionData",
                columns: table => new
                {
                    ValuationSubmissionDataId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionsAndResponses = table.Column<string>(type: "varchar(max)", unicode: false, nullable: false),
                    DocumentId = table.Column<int>(type: "int", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationSubmissionData", x => x.ValuationSubmissionDataId);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionData_Document",
                        column: x => x.DocumentId,
                        principalTable: "Document",
                        principalColumn: "DocumentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionData_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionData_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationSubmission",
                columns: table => new
                {
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSchemeId = table.Column<int>(type: "int", nullable: false),
                    SchemeValuationSubmissionId = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    EffectiveDate = table.Column<DateOnly>(type: "date", nullable: false),
                    IsExcludedSubmission = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationSubmission", x => x.ValuationSubmissionId);
                    table.ForeignKey(
                        name: "FK_ValuationSubmission_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmission_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmission_ValuationScheme",
                        column: x => x.ValuationSchemeId,
                        principalTable: "ValuationScheme",
                        principalColumn: "ValuationSchemeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserSavedSubmission",
                columns: table => new
                {
                    UserSavedSubmissionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    LastUpdated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastActionPageId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    LastPageData = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserSavedSubmission", x => x.UserSavedSubmissionId);
                    table.ForeignKey(
                        name: "FK_UserSavedSubmission_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserSavedSubmission_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserSavedSubmission_ValuationSubmission",
                        column: x => x.ValuationSubmissionId,
                        principalTable: "ValuationSubmission",
                        principalColumn: "ValuationSubmissionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationCase",
                columns: table => new
                {
                    ValuationCaseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    CaseReference = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationCase", x => x.ValuationCaseId);
                    table.ForeignKey(
                        name: "FK_ValuationCase_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationCase_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationCase_ValuationSubmission",
                        column: x => x.ValuationSubmissionId,
                        principalTable: "ValuationSubmission",
                        principalColumn: "ValuationSubmissionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationSubmissionConfirmationDates",
                columns: table => new
                {
                    ValuationSubmissionConfirmationDatesId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    DateFundingAndInvestmentStrategyWasFinalised = table.Column<DateOnly>(type: "date", nullable: false),
                    DateStatementOfStrategyWasSigned = table.Column<DateOnly>(type: "date", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationSubmissionConfirmationDates", x => x.ValuationSubmissionConfirmationDatesId);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionConfirmationDates_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionConfirmationDates_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionConfirmationDates_ValuationSubmission",
                        column: x => x.ValuationSubmissionId,
                        principalTable: "ValuationSubmission",
                        principalColumn: "ValuationSubmissionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationSubmissionGuardQuestionAnswer",
                columns: table => new
                {
                    ValuationSubmissionGuardQuestionAnswerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    GuardQuestionAnswerId = table.Column<int>(type: "int", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationSubmissionGuardQuestionAnswer", x => x.ValuationSubmissionGuardQuestionAnswerId);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionGuardQuestionAnswer_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionGuardQuestionAnswer_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionGuardQuestionAnswer_GuardQuestionAnswer",
                        column: x => x.GuardQuestionAnswerId,
                        principalTable: "GuardQuestionAnswer",
                        principalColumn: "GuardQuestionAnswerId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionGuardQuestionAnswer_ValuationSubmission",
                        column: x => x.ValuationSubmissionId,
                        principalTable: "ValuationSubmission",
                        principalColumn: "ValuationSubmissionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationSubmissionStatus",
                columns: table => new
                {
                    ValuationSubmissionStatusId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubmissionStatusTypeId = table.Column<short>(type: "smallint", nullable: false),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationSubmissionStatus", x => x.ValuationSubmissionStatusId);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionStatus_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionStatus_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionStatus_SubmissionStatusType",
                        column: x => x.SubmissionStatusTypeId,
                        principalTable: "SubmissionStatusType",
                        principalColumn: "SubmissionStatusTypeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmissionStatus_ValuationSubmission",
                        column: x => x.ValuationSubmissionId,
                        principalTable: "ValuationSubmission",
                        principalColumn: "ValuationSubmissionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ValuationSubmittedDetail",
                columns: table => new
                {
                    ValuationSubmittedDetailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValuationSubmissionId = table.Column<int>(type: "int", nullable: false),
                    SubmittedDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    StartEventReference = table.Column<int>(type: "int", nullable: false),
                    EndEventReference = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValuationSubmittedDetail", x => x.ValuationSubmittedDetailId);
                    table.ForeignKey(
                        name: "FK_ValuationSubmittedDetail_Event_End",
                        column: x => x.EndEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmittedDetail_Event_Start",
                        column: x => x.StartEventReference,
                        principalTable: "Event",
                        principalColumn: "EventReference",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ValuationSubmittedDetail_ValuationSubmission",
                        column: x => x.ValuationSubmissionId,
                        principalTable: "ValuationSubmission",
                        principalColumn: "ValuationSubmissionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "AdditionalRequiredDocumentType",
                columns: new[] { "AdditionalRequiredDocumentTypeId", "AdditionalRequiredDocumentDescription", "AdditionalRequiredDocumentName", "IsActive" },
                values: new object[,]
                {
                    { (short)0, "No additional document is required", "NONE", true },
                    { (short)1, "Trustees' analysis of maximum affordable contributions is required - SASV-00184", "MAXIMUM_AFFORDABLE_CONTRIBUTIONS", true },
                    { (short)2, "Assessment of supportable risk over the reliabilityperiod is required - SASV-00185", "ASSESSMENT_OF_SUPPORTABLE_RISK", true }
                });

            migrationBuilder.InsertData(
                table: "DeficitOrSurplusType",
                columns: new[] { "DeficitOrSurplusTypeId", "DeficitOrSurplusDescription", "DeficitOrSurplusName", "IsActive" },
                values: new object[,]
                {
                    { (short)1, "Scheme is in deficit", "DEFICIT", true },
                    { (short)2, "Scheme is in surplus", "SURPLUS", true }
                });

            migrationBuilder.InsertData(
                table: "DocumentStatusType",
                columns: new[] { "DocumentStatusTypeId", "DocumentStatusDescription", "DocumentStatusName", "IsActive" },
                values: new object[,]
                {
                    { (short)1, "Document virus scan was successful", "VIRUS_SCAN_SUCCESSFUL", true },
                    { (short)2, "Document virus scan failed", "VIRUS_SCAN_FAILED", true }
                });

            migrationBuilder.InsertData(
                table: "DocumentType",
                columns: new[] { "DocumentTypeId", "DocumentTypeDescription", "DocumentTypeName", "IsActive" },
                values: new object[,]
                {
                    { (short)1, "Actuarial valuation, recovery plan and schedule of contributions", "COMBINED_VALUATION_RECOVERY_CONTRIBUTIONS_SCHEDULE", true },
                    { (short)2, "Statement of strategy", "STATEMENT_OF_STRATEGY", true },
                    { (short)3, "Actuarial valuation", "ACTUARIAL_VALUATION", true },
                    { (short)4, "Trustees' analysis of maximum affordable contributions", "MAXIMUM_AFFORDABLE_CONTRIBUTIONS", true },
                    { (short)5, "Assessment of supportable risk over the reliabilityperiod", "ASSESSMENT_OF_SUPPORTABLE_RISK", true }
                });

            migrationBuilder.InsertData(
                table: "EventSourceType",
                columns: new[] { "EventSourceTypeId", "EventSourceDescription", "EventSourceName", "IsActive" },
                values: new object[,]
                {
                    { (short)1, "Submit your Scheme Valuation application", "Scheme Valuation Submission", true },
                    { (short)2, "Submit your Scheme Valuation - event messaging", "Scheme Valuation Submission Event Messaging", true },
                    { (short)3, "IT Database change - end-date ValuationSubmissionStatus - simultaneous submission scenario", "IT Database change - End-event cancelled status (simultaneous submissions)", true },
                    { (short)4, "IT Database change - superseding automatically cancelled submissions (if previously submitted)", "IT Database change - supersede cancelled & end-dated submitted submissions", true },
                    { (short)5, "IT Database change - populate historical submitted dates in dbo.SubmittedDetail", "IT Database change - populate historical submitted dates", true }
                });

            migrationBuilder.InsertData(
                table: "EventType",
                columns: new[] { "EventTypeId", "EventTypeDescription", "EventTypeName", "IsActive" },
                values: new object[,]
                {
                    { (short)1, "A new scheme valuation submission has been started", "SCHEME_VALUATION_SUBMISSION_STARTED", true },
                    { (short)2, "The is scheme in deficit guard question has been answered", "SCHEME_IN_DEFICIT_GUARD_QUESTION_ANSWERED", true },
                    { (short)3, "The statement of strategy document has been uploaded", "STATEMENT_OF_STRATEGY_UPLOADED", true },
                    { (short)4, "The actuarial valuation document has been uploaded", "ACTUARIAL_VALUATION_UPLOADED", true },
                    { (short)5, "The combined document containing actuarial valuation, recovery document and statement of contributions has been uploaded", "COMBINED_VALUATION_RECOVERY_CONTRIBUTIONS_SCHEDULE", true },
                    { (short)6, "Scheme valuation has been submitted", "SCHEME_VALUATION_SUBMITTED", true },
                    { (short)7, "Case reference received", "CASE_REFERENCE_RECEIVED", true },
                    { (short)8, "The trustees' analysis of maximum affordable contributions document has been uploaded", "MAXIMUM_AFFORDABLE_CONTRIBUTIONS_UPLOADED", true },
                    { (short)9, "Assessment of supportable risk over the reliability period uploaded", "ASSESSMENT_OF_SUPPORTABLE_RISK_OVER_THE_RELIABILITY_PERIOD_UPLOADED", true },
                    { (short)10, "Statement of strategy extracted", "STATEMENT_OF_STRATEGY_EXTRACTED", true },
                    { (short)11, "Confirmation dates were added", "CONFIRMATION_DATES_ADDED", true },
                    { (short)12, "A scheme valuation was superseded by a submission with the same PSR and effective date", "SCHEME_VALUATION_SUPERSEDED", true },
                    { (short)13, "A previoulsy uploaded document has been cancelled", "USER_UPLOADED_DOCUMENT_CANCELLED", true },
                    { (short)14, "The current submission has been saved as a draft, before submission", "USER_SAVED_SUBMISSION", true },
                    { (short)15, "The submission status has been superseded by a user action", "USER_CHANGED_SUBMISSION_STATUS", true },
                    { (short)16, "The dynamic user journey has been saved", "DYNAMIC_USER_JOURNEY_SAVED", true },
                    { (short)17, "Special database update", "SPECIAL_UPDATE", true }
                });

            migrationBuilder.InsertData(
                table: "FastTrackOrBespokeType",
                columns: new[] { "FastTrackOrBespokeTypeId", "FastTrackOrBespokeDescription", "FastTrackOrBespokeName", "IsActive" },
                values: new object[,]
                {
                    { (short)0, "Fast-tracked valuation", "FAST_TRACK", true },
                    { (short)1, "Bespoke valuation", "BESPOKE", true }
                });

            migrationBuilder.InsertData(
                table: "GuardQuestion",
                columns: new[] { "GuardQuestionId", "GuardQuestionDescription", "GuardQuestionName", "IsActive" },
                values: new object[] { 1, "At the effective date was the scheme in deficit on a technical provisions basis?", "IS_SCHEME_IN_DEFICIT", true });

            migrationBuilder.InsertData(
                table: "SubmissionStatusType",
                columns: new[] { "SubmissionStatusTypeId", "IsActive", "SubmissionStatusDescription", "SubmissionStatusName" },
                values: new object[,]
                {
                    { (short)1, true, "In progress", "IN_PROGRESS" },
                    { (short)2, true, "Submitted", "SUBMITTED" },
                    { (short)3, true, "Cancelled", "CANCELLED" },
                    { (short)4, true, "Superseded", "SUPERSEDED" }
                });

            migrationBuilder.InsertData(
                table: "GuardQuestionAnswer",
                columns: new[] { "GuardQuestionAnswerId", "GuardAnswerDescription", "GuardAnswerName", "GuardQuestionId" },
                values: new object[,]
                {
                    { 1, "The scheme is in deficit", "DEFICIT", 1 },
                    { 2, "The scheme is in surplus", "SURPLUS", 1 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Document_ValuationSubmissionId",
                table: "Document",
                column: "ValuationSubmissionId")
                .Annotation("SqlServer:Include", new[] { "UploadedFileName", "InternalFileName", "FileHash", "FileSize", "DocumentTypeId", "EndEventReference", "SagaUploadedFileCorrelationId" });

            migrationBuilder.CreateIndex(
                name: "Index_DispatchedAt",
                schema: "SharePointEndpoint",
                table: "OutboxData",
                column: "DispatchedAt",
                filter: "([Dispatched]=(1))");

            migrationBuilder.CreateIndex(
                name: "Index_DispatchedAt",
                schema: "WebEndpoint",
                table: "OutboxData",
                column: "DispatchedAt",
                filter: "([Dispatched]=(1))");

            migrationBuilder.CreateIndex(
                name: "Index_DispatchedAt",
                schema: "WebSagaEndpoint",
                table: "OutboxData",
                column: "DispatchedAt",
                filter: "([Dispatched]=(1))");

            migrationBuilder.CreateIndex(
                name: "Index_Correlation_SchemeValuationSubmissionId",
                schema: "WebSagaEndpoint",
                table: "SubmitSchemeValuationSaga",
                column: "Correlation_SchemeValuationSubmissionId",
                unique: true,
                filter: "([Correlation_SchemeValuationSubmissionId] IS NOT NULL)");

            migrationBuilder.CreateIndex(
                name: "IX_UserSavedSubmission_ValuationSubmissionId",
                table: "UserSavedSubmission",
                column: "ValuationSubmissionId");

            migrationBuilder.CreateIndex(
                name: "IX_ValuationCase_ValuationSubmissionId",
                table: "ValuationCase",
                column: "ValuationSubmissionId")
                .Annotation("SqlServer:Include", new[] { "CaseReference", "EndEventReference" });

            migrationBuilder.CreateIndex(
                name: "IX_ValuationScheme_PSRNumber",
                table: "ValuationScheme",
                column: "PSRNumber");

            migrationBuilder.CreateIndex(
                name: "IX_ValuationSubmission_ValuationSchemeId",
                table: "ValuationSubmission",
                columns: new[] { "ValuationSchemeId", "EffectiveDate" })
                .Annotation("SqlServer:Include", new[] { "SchemeValuationSubmissionId", "IsExcludedSubmission", "StartEventReference", "EndEventReference" });

            migrationBuilder.CreateIndex(
                name: "UX_SchemeValuation",
                table: "ValuationSubmission",
                column: "SchemeValuationSubmissionId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ValuationSubmissionConfirmationDates_ValuationSubmissionId",
                table: "ValuationSubmissionConfirmationDates",
                column: "ValuationSubmissionId")
                .Annotation("SqlServer:Include", new[] { "DateFundingAndInvestmentStrategyWasFinalised", "DateStatementOfStrategyWasSigned", "EndEventReference" });

            migrationBuilder.CreateIndex(
                name: "IX_ValuationSubmissionData_DocumentId",
                table: "ValuationSubmissionData",
                column: "DocumentId")
                .Annotation("SqlServer:Include", new[] { "EndEventReference" });

            migrationBuilder.CreateIndex(
                name: "IX_ValuationSubmissionStatus_ValuationSubmissionId",
                table: "ValuationSubmissionStatus",
                column: "ValuationSubmissionId")
                .Annotation("SqlServer:Include", new[] { "SubmissionStatusTypeId", "EndEventReference" });

            migrationBuilder.CreateIndex(
                name: "IX_ValuationSubmittedDetail_ValuationSubmissionId",
                table: "ValuationSubmittedDetail",
                column: "ValuationSubmissionId")
                .Annotation("SqlServer:Include", new[] { "SubmittedDateTime", "StartEventReference", "EndEventReference" });

            migrationBuilder.AddForeignKey(
                name: "FK_Document_Event_End",
                table: "Document",
                column: "EndEventReference",
                principalTable: "Event",
                principalColumn: "EventReference",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Document_Event_Start",
                table: "Document",
                column: "StartEventReference",
                principalTable: "Event",
                principalColumn: "EventReference",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Document_ValuationSubmission",
                table: "Document",
                column: "ValuationSubmissionId",
                principalTable: "ValuationSubmission",
                principalColumn: "ValuationSubmissionId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_DocumentStatus_Event_End",
                table: "DocumentStatus",
                column: "EndEventReference",
                principalTable: "Event",
                principalColumn: "EventReference",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_DocumentStatus_Event_Start",
                table: "DocumentStatus",
                column: "StartEventReference",
                principalTable: "Event",
                principalColumn: "EventReference",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_DynamicUserJourney_Event_End",
                table: "DynamicUserJourney",
                column: "EndEventReference",
                principalTable: "Event",
                principalColumn: "EventReference",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_DynamicUserJourney_Event_Start",
                table: "DynamicUserJourney",
                column: "StartEventReference",
                principalTable: "Event",
                principalColumn: "EventReference",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_DynamicUserJourney_ValuationSubmission",
                table: "DynamicUserJourney",
                column: "ValuationSubmissionId",
                principalTable: "ValuationSubmission",
                principalColumn: "ValuationSubmissionId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Event_ValuationSubmission",
                table: "Event",
                column: "ValuationSubmissionId",
                principalTable: "ValuationSubmission",
                principalColumn: "ValuationSubmissionId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ValuationScheme_Event_End",
                table: "ValuationScheme");

            migrationBuilder.DropForeignKey(
                name: "FK_ValuationScheme_Event_Start",
                table: "ValuationScheme");

            migrationBuilder.DropForeignKey(
                name: "FK_ValuationSubmission_Event_End",
                table: "ValuationSubmission");

            migrationBuilder.DropForeignKey(
                name: "FK_ValuationSubmission_Event_Start",
                table: "ValuationSubmission");

            migrationBuilder.DropTable(
                name: "DocumentStatus");

            migrationBuilder.DropTable(
                name: "DynamicUserJourney");

            migrationBuilder.DropTable(
                name: "OutboxData",
                schema: "SharePointEndpoint");

            migrationBuilder.DropTable(
                name: "OutboxData",
                schema: "WebEndpoint");

            migrationBuilder.DropTable(
                name: "OutboxData",
                schema: "WebSagaEndpoint");

            migrationBuilder.DropTable(
                name: "SubmitSchemeValuationSaga",
                schema: "WebSagaEndpoint");

            migrationBuilder.DropTable(
                name: "UserSavedSubmission");

            migrationBuilder.DropTable(
                name: "ValuationCase");

            migrationBuilder.DropTable(
                name: "ValuationSubmissionConfirmationDates");

            migrationBuilder.DropTable(
                name: "ValuationSubmissionData");

            migrationBuilder.DropTable(
                name: "ValuationSubmissionGuardQuestionAnswer");

            migrationBuilder.DropTable(
                name: "ValuationSubmissionStatus");

            migrationBuilder.DropTable(
                name: "ValuationSubmittedDetail");

            migrationBuilder.DropTable(
                name: "DocumentStatusType");

            migrationBuilder.DropTable(
                name: "AdditionalRequiredDocumentType");

            migrationBuilder.DropTable(
                name: "DeficitOrSurplusType");

            migrationBuilder.DropTable(
                name: "FastTrackOrBespokeType");

            migrationBuilder.DropTable(
                name: "Document");

            migrationBuilder.DropTable(
                name: "GuardQuestionAnswer");

            migrationBuilder.DropTable(
                name: "SubmissionStatusType");

            migrationBuilder.DropTable(
                name: "DocumentType");

            migrationBuilder.DropTable(
                name: "GuardQuestion");

            migrationBuilder.DropTable(
                name: "Event");

            migrationBuilder.DropTable(
                name: "EventSourceType");

            migrationBuilder.DropTable(
                name: "EventType");

            migrationBuilder.DropTable(
                name: "ValuationSubmission");

            migrationBuilder.DropTable(
                name: "ValuationScheme");
        }
    }
}
