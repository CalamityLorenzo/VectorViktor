using System.Reflection;

namespace SchemeValuations.Submit.Data.Migrations;

/// <summary>Reads the view scripts embedded from the Sql/Views folder.</summary>
internal static class SqlScripts
{
    private static readonly Assembly Assembly = typeof(SqlScripts).Assembly;

    /// <summary>Views in dependency order: a view is listed after any view it selects from.</summary>
    public static readonly string[] Views =
    [
        "uvw_Documents_Current",
        "uvw_SchemeValuationSubmissions",
        "uvw_SchemeValuationSubmissions_Current",
        "uvw_UserSavedSubmissions_Current",
        "uvw_ValuationCase",
        "uvw_ValuationSubmissionData_Current",
        "uvw_ValuationSubmissionGuardQuestionAnswers_Current",
    ];

    public static string View(string name) => Read($".Sql.Views.{name}.sql");

    private static string Read(string resourceSuffix)
    {
        var resourceName = Assembly.GetManifestResourceNames().SingleOrDefault(n => n.EndsWith(resourceSuffix, StringComparison.Ordinal))
            ?? throw new InvalidOperationException($"Embedded SQL script '*{resourceSuffix}' was not found.");

        using var stream = Assembly.GetManifestResourceStream(resourceName)!;
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }
}
