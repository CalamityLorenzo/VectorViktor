using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SchemeValuations.Submit.Data.Migrations
{
    /// <summary>
    /// Creates the views and the db_reportreader role from the SQL database project. The view scripts use
    /// CREATE OR ALTER, so this migration can also be applied over an existing database.
    /// The project's stored procedures are not created; their logic lives in the Services folder.
    /// </summary>
    public partial class AddViews : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            foreach (var view in SqlScripts.Views)
            {
                migrationBuilder.Sql(SqlScripts.View(view));
            }

            migrationBuilder.Sql("IF DATABASE_PRINCIPAL_ID('db_reportreader') IS NULL CREATE ROLE [db_reportreader];");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP ROLE IF EXISTS [db_reportreader];");

            foreach (var view in Enumerable.Reverse(SqlScripts.Views))
            {
                migrationBuilder.Sql($"DROP VIEW IF EXISTS [dbo].[{view}];");
            }
        }
    }
}
