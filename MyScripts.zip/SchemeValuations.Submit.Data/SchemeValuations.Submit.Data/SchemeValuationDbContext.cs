using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using SchemeValuations.Submit.Data.Entities;
using SchemeValuations.Submit.Data.Entities.Messaging;
using SchemeValuations.Submit.Data.Entities.Views;

namespace SchemeValuations.Submit.Data;

/// <summary>
/// EF Core model of the SchemeValuation database, converted from the
/// SchemeValuations.Submit.Databases.SchemeValuation SQL database project.
/// </summary>
/// <remarks>
/// The database project's stored procedures are implemented in C# by
/// <see cref="Services.SchemeValuationQueries"/> and <see cref="Services.SchemeValuationCommands"/>.
/// </remarks>
public class SchemeValuationDbContext(DbContextOptions<SchemeValuationDbContext> options) : DbContext(options)
{
    // Reference data
    public DbSet<AdditionalRequiredDocumentType> AdditionalRequiredDocumentTypes => Set<AdditionalRequiredDocumentType>();
    public DbSet<DeficitOrSurplusType> DeficitOrSurplusTypes => Set<DeficitOrSurplusType>();
    public DbSet<DocumentStatusType> DocumentStatusTypes => Set<DocumentStatusType>();
    public DbSet<DocumentType> DocumentTypes => Set<DocumentType>();
    public DbSet<EventSourceType> EventSourceTypes => Set<EventSourceType>();
    public DbSet<EventType> EventTypes => Set<EventType>();
    public DbSet<FastTrackOrBespokeType> FastTrackOrBespokeTypes => Set<FastTrackOrBespokeType>();
    public DbSet<GuardQuestion> GuardQuestions => Set<GuardQuestion>();
    public DbSet<GuardQuestionAnswer> GuardQuestionAnswers => Set<GuardQuestionAnswer>();
    public DbSet<SubmissionStatusType> SubmissionStatusTypes => Set<SubmissionStatusType>();

    // Submission data
    public DbSet<Event> Events => Set<Event>();
    public DbSet<ValuationScheme> ValuationSchemes => Set<ValuationScheme>();
    public DbSet<ValuationSubmission> ValuationSubmissions => Set<ValuationSubmission>();
    public DbSet<Document> Documents => Set<Document>();
    public DbSet<DocumentStatus> DocumentStatuses => Set<DocumentStatus>();
    public DbSet<DynamicUserJourney> DynamicUserJourneys => Set<DynamicUserJourney>();
    public DbSet<UserSavedSubmission> UserSavedSubmissions => Set<UserSavedSubmission>();
    public DbSet<ValuationCase> ValuationCases => Set<ValuationCase>();
    public DbSet<ValuationSubmissionConfirmationDates> ValuationSubmissionConfirmationDates => Set<ValuationSubmissionConfirmationDates>();
    public DbSet<ValuationSubmissionData> ValuationSubmissionData => Set<ValuationSubmissionData>();
    public DbSet<ValuationSubmissionGuardQuestionAnswer> ValuationSubmissionGuardQuestionAnswers => Set<ValuationSubmissionGuardQuestionAnswer>();
    public DbSet<ValuationSubmissionStatus> ValuationSubmissionStatuses => Set<ValuationSubmissionStatus>();
    public DbSet<ValuationSubmittedDetail> ValuationSubmittedDetails => Set<ValuationSubmittedDetail>();

    // NServiceBus persistence
    public DbSet<SharePointEndpointOutboxData> SharePointEndpointOutboxData => Set<SharePointEndpointOutboxData>();
    public DbSet<WebEndpointOutboxData> WebEndpointOutboxData => Set<WebEndpointOutboxData>();
    public DbSet<WebSagaEndpointOutboxData> WebSagaEndpointOutboxData => Set<WebSagaEndpointOutboxData>();
    public DbSet<SubmitSchemeValuationSaga> SubmitSchemeValuationSagas => Set<SubmitSchemeValuationSaga>();

    // Views (read-only)
    public DbSet<DocumentCurrentView> DocumentsCurrent => Set<DocumentCurrentView>();
    public DbSet<SchemeValuationSubmissionView> SchemeValuationSubmissionsView => Set<SchemeValuationSubmissionView>();
    public DbSet<SchemeValuationSubmissionCurrentView> SchemeValuationSubmissionsCurrent => Set<SchemeValuationSubmissionCurrentView>();
    public DbSet<UserSavedSubmissionCurrentView> UserSavedSubmissionsCurrent => Set<UserSavedSubmissionCurrentView>();
    public DbSet<ValuationCaseView> ValuationCasesView => Set<ValuationCaseView>();
    public DbSet<ValuationSubmissionDataCurrentView> ValuationSubmissionDataCurrent => Set<ValuationSubmissionDataCurrentView>();
    public DbSet<ValuationSubmissionGuardQuestionAnswerCurrentView> ValuationSubmissionGuardQuestionAnswersCurrent => Set<ValuationSubmissionGuardQuestionAnswerCurrentView>();

    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
    {
        // The database is almost entirely varchar; nvarchar columns opt in with IsUnicode().
        configurationBuilder.Properties<string>().AreUnicode(false);

        // Only create the indexes the database project declares, not one per foreign key.
        configurationBuilder.Conventions.Remove(typeof(ForeignKeyIndexConvention));
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(SchemeValuationDbContext).Assembly);

        // None of the database's foreign keys cascade.
        foreach (var foreignKey in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
        {
            foreignKey.DeleteBehavior = DeleteBehavior.Restrict;
        }
    }
}
