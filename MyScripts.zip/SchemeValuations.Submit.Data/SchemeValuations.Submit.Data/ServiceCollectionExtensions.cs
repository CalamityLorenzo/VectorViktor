using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SchemeValuations.Submit.Data.Services;

namespace SchemeValuations.Submit.Data;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers <see cref="SchemeValuationDbContext"/> against SQL Server, plus the scoped
    /// <see cref="SchemeValuationQueries"/> and <see cref="SchemeValuationCommands"/> that share it.
    /// </summary>
    public static IServiceCollection AddSchemeValuationDbContext(this IServiceCollection services, string connectionString)
    {
        services.AddDbContext<SchemeValuationDbContext>(options => options.UseSqlServer(connectionString));
        services.AddScoped<SchemeValuationQueries>();
        services.AddScoped<SchemeValuationCommands>();
        return services;
    }
}
