namespace SchemeValuations.Submit.Data;

// Ids of the seeded reference data rows (see Configurations/LookupConfigurations.cs).

public static class EventTypeIds
{
    public const short SchemeValuationSubmissionStarted = 1;
    public const short SchemeInDeficitGuardQuestionAnswered = 2;
    public const short StatementOfStrategyUploaded = 3;
    public const short ActuarialValuationUploaded = 4;
    public const short CombinedValuationRecoveryContributionsSchedule = 5;
    public const short SchemeValuationSubmitted = 6;
    public const short CaseReferenceReceived = 7;
    public const short MaximumAffordableContributionsUploaded = 8;
    public const short AssessmentOfSupportableRiskUploaded = 9;
    public const short StatementOfStrategyExtracted = 10;
    public const short ConfirmationDatesAdded = 11;
    public const short SchemeValuationSuperseded = 12;
    public const short UserUploadedDocumentCancelled = 13;
    public const short UserSavedSubmission = 14;
    public const short UserChangedSubmissionStatus = 15;
    public const short DynamicUserJourneySaved = 16;
    public const short SpecialUpdate = 17;
}

public static class EventSourceTypeIds
{
    public const short SchemeValuationSubmission = 1;
    public const short SchemeValuationSubmissionEventMessaging = 2;
}

public static class SubmissionStatusTypeIds
{
    public const short InProgress = 1;
    public const short Submitted = 2;
    public const short Cancelled = 3;
    public const short Superseded = 4;
}

public static class DocumentTypeIds
{
    public const short CombinedValuationRecoveryContributionsSchedule = 1;
    public const short StatementOfStrategy = 2;
    public const short ActuarialValuation = 3;
    public const short MaximumAffordableContributions = 4;
    public const short AssessmentOfSupportableRisk = 5;
}

public static class DocumentStatusTypeIds
{
    public const short VirusScanSuccessful = 1;
    public const short VirusScanFailed = 2;
}
