using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SchemeValuations.Submit.Data.Entities;

namespace SchemeValuations.Submit.Data.Configurations;

internal static class ConfigurationExtensions
{
    /// <summary>
    /// Maps the StartEventReference / EndEventReference foreign keys to dbo.Event using the
    /// FK_{table}_Event_Start / FK_{table}_Event_End constraint names used by the database project.
    /// </summary>
    public static EntityTypeBuilder<T> HasEventReferences<T>(this EntityTypeBuilder<T> builder, string tableName)
        where T : class, IEventTracked
    {
        builder.HasOne(typeof(Event), nameof(IEventTracked.StartEvent))
            .WithMany()
            .HasForeignKey(nameof(IEventTracked.StartEventReference))
            .HasConstraintName($"FK_{tableName}_Event_Start");

        builder.HasOne(typeof(Event), nameof(IEventTracked.EndEvent))
            .WithMany()
            .HasForeignKey(nameof(IEventTracked.EndEventReference))
            .HasConstraintName($"FK_{tableName}_Event_End");

        return builder;
    }

    /// <summary>
    /// Creates a column default in the database while EF still always sends the property value on insert.
    /// Without <c>ValueGeneratedNever</c>, EF would skip a CLR-default value (e.g. <c>false</c>) and let a
    /// database default of 1 win, silently turning <c>IsActive = false</c> into true.
    /// </summary>
    public static PropertyBuilder<TProperty> HasColumnDefault<TProperty>(this PropertyBuilder<TProperty> builder, TProperty value)
        => builder.HasDefaultValue(value).ValueGeneratedNever();
}
