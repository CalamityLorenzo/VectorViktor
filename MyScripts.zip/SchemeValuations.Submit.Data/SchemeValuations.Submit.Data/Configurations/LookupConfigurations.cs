using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SchemeValuations.Submit.Data.Entities;

namespace SchemeValuations.Submit.Data.Configurations;

// Reference data tables. The HasData rows replace the Script/ReferenceData post-deployment
// scripts: add or change a row here and add a migration to deploy it.

internal sealed class AdditionalRequiredDocumentTypeConfiguration : IEntityTypeConfiguration<AdditionalRequiredDocumentType>
{
    public void Configure(EntityTypeBuilder<AdditionalRequiredDocumentType> builder)
    {
        builder.ToTable("AdditionalRequiredDocumentType");
        builder.HasKey(e => e.AdditionalRequiredDocumentTypeId).HasName("PK_AdditionalRequiredDocumentType");
        builder.Property(e => e.AdditionalRequiredDocumentTypeId).ValueGeneratedNever();
        builder.Property(e => e.AdditionalRequiredDocumentName).HasMaxLength(50);
        builder.Property(e => e.AdditionalRequiredDocumentDescription).HasMaxLength(200);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new AdditionalRequiredDocumentType { AdditionalRequiredDocumentTypeId = 0, AdditionalRequiredDocumentName = "NONE", AdditionalRequiredDocumentDescription = "No additional document is required", IsActive = true },
            new AdditionalRequiredDocumentType { AdditionalRequiredDocumentTypeId = 1, AdditionalRequiredDocumentName = "MAXIMUM_AFFORDABLE_CONTRIBUTIONS", AdditionalRequiredDocumentDescription = "Trustees' analysis of maximum affordable contributions is required - SASV-00184", IsActive = true },
            new AdditionalRequiredDocumentType { AdditionalRequiredDocumentTypeId = 2, AdditionalRequiredDocumentName = "ASSESSMENT_OF_SUPPORTABLE_RISK", AdditionalRequiredDocumentDescription = "Assessment of supportable risk over the reliabilityperiod is required - SASV-00185", IsActive = true });
    }
}

internal sealed class DeficitOrSurplusTypeConfiguration : IEntityTypeConfiguration<DeficitOrSurplusType>
{
    public void Configure(EntityTypeBuilder<DeficitOrSurplusType> builder)
    {
        builder.ToTable("DeficitOrSurplusType");
        builder.HasKey(e => e.DeficitOrSurplusTypeId).HasName("PK_DeficitOrSurplusType");
        builder.Property(e => e.DeficitOrSurplusTypeId).ValueGeneratedNever();
        builder.Property(e => e.DeficitOrSurplusName).HasMaxLength(20);
        builder.Property(e => e.DeficitOrSurplusDescription).HasMaxLength(100);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new DeficitOrSurplusType { DeficitOrSurplusTypeId = 1, DeficitOrSurplusName = "DEFICIT", DeficitOrSurplusDescription = "Scheme is in deficit", IsActive = true },
            new DeficitOrSurplusType { DeficitOrSurplusTypeId = 2, DeficitOrSurplusName = "SURPLUS", DeficitOrSurplusDescription = "Scheme is in surplus", IsActive = true });
    }
}

internal sealed class DocumentStatusTypeConfiguration : IEntityTypeConfiguration<DocumentStatusType>
{
    public void Configure(EntityTypeBuilder<DocumentStatusType> builder)
    {
        builder.ToTable("DocumentStatusType");
        builder.HasKey(e => e.DocumentStatusTypeId).HasName("PK_DocumentStatusType");
        builder.Property(e => e.DocumentStatusTypeId).ValueGeneratedNever();
        builder.Property(e => e.DocumentStatusName).HasMaxLength(50);
        builder.Property(e => e.DocumentStatusDescription).HasMaxLength(100);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new DocumentStatusType { DocumentStatusTypeId = 1, DocumentStatusName = "VIRUS_SCAN_SUCCESSFUL", DocumentStatusDescription = "Document virus scan was successful", IsActive = true },
            new DocumentStatusType { DocumentStatusTypeId = 2, DocumentStatusName = "VIRUS_SCAN_FAILED", DocumentStatusDescription = "Document virus scan failed", IsActive = true });
    }
}

internal sealed class DocumentTypeConfiguration : IEntityTypeConfiguration<DocumentType>
{
    public void Configure(EntityTypeBuilder<DocumentType> builder)
    {
        builder.ToTable("DocumentType");
        builder.HasKey(e => e.DocumentTypeId).HasName("PK_DocumentType");
        builder.Property(e => e.DocumentTypeId).ValueGeneratedNever();
        builder.Property(e => e.DocumentTypeName).HasMaxLength(50);
        builder.Property(e => e.DocumentTypeDescription).HasMaxLength(200);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new DocumentType { DocumentTypeId = 1, DocumentTypeName = "COMBINED_VALUATION_RECOVERY_CONTRIBUTIONS_SCHEDULE", DocumentTypeDescription = "Actuarial valuation, recovery plan and schedule of contributions", IsActive = true },
            new DocumentType { DocumentTypeId = 2, DocumentTypeName = "STATEMENT_OF_STRATEGY", DocumentTypeDescription = "Statement of strategy", IsActive = true },
            new DocumentType { DocumentTypeId = 3, DocumentTypeName = "ACTUARIAL_VALUATION", DocumentTypeDescription = "Actuarial valuation", IsActive = true },
            new DocumentType { DocumentTypeId = 4, DocumentTypeName = "MAXIMUM_AFFORDABLE_CONTRIBUTIONS", DocumentTypeDescription = "Trustees' analysis of maximum affordable contributions", IsActive = true },
            new DocumentType { DocumentTypeId = 5, DocumentTypeName = "ASSESSMENT_OF_SUPPORTABLE_RISK", DocumentTypeDescription = "Assessment of supportable risk over the reliabilityperiod", IsActive = true });
    }
}

internal sealed class EventSourceTypeConfiguration : IEntityTypeConfiguration<EventSourceType>
{
    public void Configure(EntityTypeBuilder<EventSourceType> builder)
    {
        builder.ToTable("EventSourceType");
        builder.HasKey(e => e.EventSourceTypeId).HasName("PK_EventSourceType");
        builder.Property(e => e.EventSourceTypeId).ValueGeneratedNever();
        builder.Property(e => e.EventSourceName).HasMaxLength(75);
        builder.Property(e => e.EventSourceDescription).HasMaxLength(100);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new EventSourceType { EventSourceTypeId = 1, EventSourceName = "Scheme Valuation Submission", EventSourceDescription = "Submit your Scheme Valuation application", IsActive = true },
            new EventSourceType { EventSourceTypeId = 2, EventSourceName = "Scheme Valuation Submission Event Messaging", EventSourceDescription = "Submit your Scheme Valuation - event messaging", IsActive = true },
            new EventSourceType { EventSourceTypeId = 3, EventSourceName = "IT Database change - End-event cancelled status (simultaneous submissions)", EventSourceDescription = "IT Database change - end-date ValuationSubmissionStatus - simultaneous submission scenario", IsActive = true },
            new EventSourceType { EventSourceTypeId = 4, EventSourceName = "IT Database change - supersede cancelled & end-dated submitted submissions", EventSourceDescription = "IT Database change - superseding automatically cancelled submissions (if previously submitted)", IsActive = true },
            new EventSourceType { EventSourceTypeId = 5, EventSourceName = "IT Database change - populate historical submitted dates", EventSourceDescription = "IT Database change - populate historical submitted dates in dbo.SubmittedDetail", IsActive = true });
    }
}

internal sealed class EventTypeConfiguration : IEntityTypeConfiguration<EventType>
{
    public void Configure(EntityTypeBuilder<EventType> builder)
    {
        builder.ToTable("EventType");
        builder.HasKey(e => e.EventTypeId).HasName("PK_EventType");
        builder.Property(e => e.EventTypeId).ValueGeneratedNever();
        builder.Property(e => e.EventTypeName).HasMaxLength(75);
        builder.Property(e => e.EventTypeDescription).HasMaxLength(200);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new EventType { EventTypeId = 1, EventTypeName = "SCHEME_VALUATION_SUBMISSION_STARTED", EventTypeDescription = "A new scheme valuation submission has been started", IsActive = true },
            new EventType { EventTypeId = 2, EventTypeName = "SCHEME_IN_DEFICIT_GUARD_QUESTION_ANSWERED", EventTypeDescription = "The is scheme in deficit guard question has been answered", IsActive = true },
            new EventType { EventTypeId = 3, EventTypeName = "STATEMENT_OF_STRATEGY_UPLOADED", EventTypeDescription = "The statement of strategy document has been uploaded", IsActive = true },
            new EventType { EventTypeId = 4, EventTypeName = "ACTUARIAL_VALUATION_UPLOADED", EventTypeDescription = "The actuarial valuation document has been uploaded", IsActive = true },
            new EventType { EventTypeId = 5, EventTypeName = "COMBINED_VALUATION_RECOVERY_CONTRIBUTIONS_SCHEDULE", EventTypeDescription = "The combined document containing actuarial valuation, recovery document and statement of contributions has been uploaded", IsActive = true },
            new EventType { EventTypeId = 6, EventTypeName = "SCHEME_VALUATION_SUBMITTED", EventTypeDescription = "Scheme valuation has been submitted", IsActive = true },
            new EventType { EventTypeId = 7, EventTypeName = "CASE_REFERENCE_RECEIVED", EventTypeDescription = "Case reference received", IsActive = true },
            new EventType { EventTypeId = 8, EventTypeName = "MAXIMUM_AFFORDABLE_CONTRIBUTIONS_UPLOADED", EventTypeDescription = "The trustees' analysis of maximum affordable contributions document has been uploaded", IsActive = true },
            new EventType { EventTypeId = 9, EventTypeName = "ASSESSMENT_OF_SUPPORTABLE_RISK_OVER_THE_RELIABILITY_PERIOD_UPLOADED", EventTypeDescription = "Assessment of supportable risk over the reliability period uploaded", IsActive = true },
            new EventType { EventTypeId = 10, EventTypeName = "STATEMENT_OF_STRATEGY_EXTRACTED", EventTypeDescription = "Statement of strategy extracted", IsActive = true },
            new EventType { EventTypeId = 11, EventTypeName = "CONFIRMATION_DATES_ADDED", EventTypeDescription = "Confirmation dates were added", IsActive = true },
            new EventType { EventTypeId = 12, EventTypeName = "SCHEME_VALUATION_SUPERSEDED", EventTypeDescription = "A scheme valuation was superseded by a submission with the same PSR and effective date", IsActive = true },
            new EventType { EventTypeId = 13, EventTypeName = "USER_UPLOADED_DOCUMENT_CANCELLED", EventTypeDescription = "A previoulsy uploaded document has been cancelled", IsActive = true },
            new EventType { EventTypeId = 14, EventTypeName = "USER_SAVED_SUBMISSION", EventTypeDescription = "The current submission has been saved as a draft, before submission", IsActive = true },
            new EventType { EventTypeId = 15, EventTypeName = "USER_CHANGED_SUBMISSION_STATUS", EventTypeDescription = "The submission status has been superseded by a user action", IsActive = true },
            new EventType { EventTypeId = 16, EventTypeName = "DYNAMIC_USER_JOURNEY_SAVED", EventTypeDescription = "The dynamic user journey has been saved", IsActive = true },
            new EventType { EventTypeId = 17, EventTypeName = "SPECIAL_UPDATE", EventTypeDescription = "Special database update", IsActive = true });
    }
}

internal sealed class FastTrackOrBespokeTypeConfiguration : IEntityTypeConfiguration<FastTrackOrBespokeType>
{
    public void Configure(EntityTypeBuilder<FastTrackOrBespokeType> builder)
    {
        builder.ToTable("FastTrackOrBespokeType");
        builder.HasKey(e => e.FastTrackOrBespokeTypeId).HasName("PK_FastTrackOrBespokeType");
        builder.Property(e => e.FastTrackOrBespokeTypeId).ValueGeneratedNever();
        builder.Property(e => e.FastTrackOrBespokeName).HasMaxLength(20);
        builder.Property(e => e.FastTrackOrBespokeDescription).HasMaxLength(100);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new FastTrackOrBespokeType { FastTrackOrBespokeTypeId = 0, FastTrackOrBespokeName = "FAST_TRACK", FastTrackOrBespokeDescription = "Fast-tracked valuation", IsActive = true },
            new FastTrackOrBespokeType { FastTrackOrBespokeTypeId = 1, FastTrackOrBespokeName = "BESPOKE", FastTrackOrBespokeDescription = "Bespoke valuation", IsActive = true });
    }
}

internal sealed class GuardQuestionConfiguration : IEntityTypeConfiguration<GuardQuestion>
{
    public void Configure(EntityTypeBuilder<GuardQuestion> builder)
    {
        builder.ToTable("GuardQuestion");
        builder.HasKey(e => e.GuardQuestionId).HasName("PK_GuardQuestion");
        builder.Property(e => e.GuardQuestionId).ValueGeneratedNever();
        builder.Property(e => e.GuardQuestionName).HasMaxLength(50);
        builder.Property(e => e.GuardQuestionDescription).HasMaxLength(200);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new GuardQuestion { GuardQuestionId = 1, GuardQuestionName = "IS_SCHEME_IN_DEFICIT", GuardQuestionDescription = "At the effective date was the scheme in deficit on a technical provisions basis?", IsActive = true });
    }
}

internal sealed class GuardQuestionAnswerConfiguration : IEntityTypeConfiguration<GuardQuestionAnswer>
{
    public void Configure(EntityTypeBuilder<GuardQuestionAnswer> builder)
    {
        builder.ToTable("GuardQuestionAnswer");
        builder.HasKey(e => e.GuardQuestionAnswerId).HasName("PK_GuardQuestionAnswer");
        builder.Property(e => e.GuardQuestionAnswerId).ValueGeneratedNever();
        builder.Property(e => e.GuardAnswerName).HasMaxLength(50);
        builder.Property(e => e.GuardAnswerDescription).HasMaxLength(200);

        builder.HasOne(e => e.GuardQuestion)
            .WithMany(q => q.GuardQuestionAnswers)
            .HasForeignKey(e => e.GuardQuestionId)
            .HasConstraintName("FK_GuardQuestionAnswer_GuardQuestion");

        builder.HasData(
            new GuardQuestionAnswer { GuardQuestionAnswerId = 1, GuardQuestionId = 1, GuardAnswerName = "DEFICIT", GuardAnswerDescription = "The scheme is in deficit" },
            new GuardQuestionAnswer { GuardQuestionAnswerId = 2, GuardQuestionId = 1, GuardAnswerName = "SURPLUS", GuardAnswerDescription = "The scheme is in surplus" });
    }
}

internal sealed class SubmissionStatusTypeConfiguration : IEntityTypeConfiguration<SubmissionStatusType>
{
    public void Configure(EntityTypeBuilder<SubmissionStatusType> builder)
    {
        builder.ToTable("SubmissionStatusType");
        builder.HasKey(e => e.SubmissionStatusTypeId).HasName("PK_SubmissionStatusType");
        builder.Property(e => e.SubmissionStatusTypeId).ValueGeneratedNever();
        builder.Property(e => e.SubmissionStatusName).HasMaxLength(16);
        builder.Property(e => e.SubmissionStatusDescription).HasMaxLength(100);
        builder.Property(e => e.IsActive).HasColumnDefault(true);

        builder.HasData(
            new SubmissionStatusType { SubmissionStatusTypeId = 1, SubmissionStatusName = "IN_PROGRESS", SubmissionStatusDescription = "In progress", IsActive = true },
            new SubmissionStatusType { SubmissionStatusTypeId = 2, SubmissionStatusName = "SUBMITTED", SubmissionStatusDescription = "Submitted", IsActive = true },
            new SubmissionStatusType { SubmissionStatusTypeId = 3, SubmissionStatusName = "CANCELLED", SubmissionStatusDescription = "Cancelled", IsActive = true },
            new SubmissionStatusType { SubmissionStatusTypeId = 4, SubmissionStatusName = "SUPERSEDED", SubmissionStatusDescription = "Superseded", IsActive = true });
    }
}
