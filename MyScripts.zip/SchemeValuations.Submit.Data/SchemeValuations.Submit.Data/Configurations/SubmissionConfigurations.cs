using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SchemeValuations.Submit.Data.Entities;

namespace SchemeValuations.Submit.Data.Configurations;

internal sealed class EventConfiguration : IEntityTypeConfiguration<Event>
{
    public void Configure(EntityTypeBuilder<Event> builder)
    {
        builder.ToTable("Event");
        builder.HasKey(e => e.EventReference).HasName("PK_Event");

        builder.Property(e => e.SchemeValuationSubmissionId).HasMaxLength(255);
        builder.Property(e => e.UserId).HasMaxLength(300);
        builder.Property(e => e.TransactionId).HasMaxLength(50);

        builder.Property(e => e.CreateDateTime)
            .HasDefaultValueSql("getdate()")
            .Metadata.SetDefaultConstraintName("DF_Event_CreateDateTime");

        builder.Property(e => e.EventSourceTypeId)
            .HasColumnDefault((short)0)
            .Metadata.SetDefaultConstraintName("DF_Event_EventSourceType");

        builder.HasOne(e => e.EventType)
            .WithMany()
            .HasForeignKey(e => e.EventTypeId)
            .HasConstraintName("FK_Event_EventType");

        builder.HasOne(e => e.EventSourceType)
            .WithMany()
            .HasForeignKey(e => e.EventSourceTypeId)
            .HasConstraintName("FK_Event_EventSourceType");

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.Events)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_Event_ValuationSubmission");
    }
}

internal sealed class ValuationSchemeConfiguration : IEntityTypeConfiguration<ValuationScheme>
{
    public void Configure(EntityTypeBuilder<ValuationScheme> builder)
    {
        builder.ToTable("ValuationScheme");
        builder.HasKey(e => e.ValuationSchemeId).HasName("PK_ValuationScheme");
        builder.Property(e => e.SchemeName).HasMaxLength(100);

        builder.HasIndex(e => e.PSRNumber, "IX_ValuationScheme_PSRNumber");

        builder.HasEventReferences("ValuationScheme");
    }
}

internal sealed class ValuationSubmissionConfiguration : IEntityTypeConfiguration<ValuationSubmission>
{
    public void Configure(EntityTypeBuilder<ValuationSubmission> builder)
    {
        builder.ToTable("ValuationSubmission");
        builder.HasKey(e => e.ValuationSubmissionId).HasName("PK_ValuationSubmission");
        builder.Property(e => e.SchemeValuationSubmissionId).HasMaxLength(255);
        builder.Property(e => e.IsExcludedSubmission).HasColumnDefault(false);

        builder.HasIndex(e => e.SchemeValuationSubmissionId, "UX_SchemeValuation").IsUnique();
        builder.HasIndex(e => new { e.ValuationSchemeId, e.EffectiveDate }, "IX_ValuationSubmission_ValuationSchemeId")
            .IncludeProperties(e => new { e.SchemeValuationSubmissionId, e.IsExcludedSubmission, e.StartEventReference, e.EndEventReference });

        builder.HasOne(e => e.ValuationScheme)
            .WithMany(s => s.ValuationSubmissions)
            .HasForeignKey(e => e.ValuationSchemeId)
            .HasConstraintName("FK_ValuationSubmission_ValuationScheme");

        builder.HasEventReferences("ValuationSubmission");
    }
}

internal sealed class DocumentConfiguration : IEntityTypeConfiguration<Document>
{
    public void Configure(EntityTypeBuilder<Document> builder)
    {
        builder.ToTable("Document");
        builder.HasKey(e => e.DocumentId).HasName("PK_Document");
        builder.Property(e => e.UploadedFileName).HasMaxLength(512);
        builder.Property(e => e.InternalFileName).HasMaxLength(512);
        builder.Property(e => e.FileHash).HasMaxLength(512);
        builder.Property(e => e.SagaUploadedFileCorrelationId)
            .HasDefaultValueSql("CAST(0x0 AS UNIQUEIDENTIFIER)")
            .ValueGeneratedNever();

        builder.HasIndex(e => e.ValuationSubmissionId, "IX_Document_ValuationSubmissionId")
            .IncludeProperties(e => new { e.UploadedFileName, e.InternalFileName, e.FileHash, e.FileSize, e.DocumentTypeId, e.EndEventReference, e.SagaUploadedFileCorrelationId });

        builder.HasOne(e => e.DocumentType)
            .WithMany()
            .HasForeignKey(e => e.DocumentTypeId)
            .HasConstraintName("FK_Document_DocumentType");

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.Documents)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_Document_ValuationSubmission");

        builder.HasEventReferences("Document");
    }
}

internal sealed class DocumentStatusConfiguration : IEntityTypeConfiguration<DocumentStatus>
{
    public void Configure(EntityTypeBuilder<DocumentStatus> builder)
    {
        builder.ToTable("DocumentStatus");
        builder.HasKey(e => e.DocumentStatusId).HasName("PK_DocumentStatus");

        builder.HasOne(e => e.Document)
            .WithMany(d => d.DocumentStatuses)
            .HasForeignKey(e => e.DocumentId)
            .HasConstraintName("FK_DocumentStatus_Document");

        builder.HasOne(e => e.DocumentStatusType)
            .WithMany()
            .HasForeignKey(e => e.DocumentStatusTypeId)
            .HasConstraintName("FK_DocumentStatus_DocumentStatusType");

        builder.HasEventReferences("DocumentStatus");
    }
}

internal sealed class DynamicUserJourneyConfiguration : IEntityTypeConfiguration<DynamicUserJourney>
{
    public void Configure(EntityTypeBuilder<DynamicUserJourney> builder)
    {
        builder.ToTable("DynamicUserJourney");
        builder.HasKey(e => e.DynamicUserJourneyId).HasName("PK_DynamicUserJourney");
        builder.Property(e => e.IsMultiDocUpload).HasColumnDefault(false);

        builder.HasOne(e => e.FastTrackOrBespokeType)
            .WithMany()
            .HasForeignKey(e => e.FastTrackOrBespokeTypeId)
            .HasConstraintName("FK_DynamicUserJourney_FastTrackOrBespokeType");

        builder.HasOne(e => e.DeficitOrSurplusType)
            .WithMany()
            .HasForeignKey(e => e.DeficitOrSurplusTypeId)
            .HasConstraintName("FK_DynamicUserJourney_DeficitOrSurplusType");

        builder.HasOne(e => e.AdditionalRequiredDocumentType)
            .WithMany()
            .HasForeignKey(e => e.AdditionalRequiredDocumentTypeId)
            .HasConstraintName("FK_DynamicUserJourney_AdditionalRequiredDocumentType");

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.DynamicUserJourneys)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_DynamicUserJourney_ValuationSubmission");

        builder.HasEventReferences("DynamicUserJourney");
    }
}

internal sealed class UserSavedSubmissionConfiguration : IEntityTypeConfiguration<UserSavedSubmission>
{
    public void Configure(EntityTypeBuilder<UserSavedSubmission> builder)
    {
        builder.ToTable("UserSavedSubmission");
        builder.HasKey(e => e.UserSavedSubmissionId).HasName("PK_UserSavedSubmission");
        builder.Property(e => e.LastPageData).HasMaxLength(1024).IsUnicode();

        builder.HasIndex(e => e.ValuationSubmissionId, "IX_UserSavedSubmission_ValuationSubmissionId");

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.UserSavedSubmissions)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_UserSavedSubmission_ValuationSubmission");

        builder.HasEventReferences("UserSavedSubmission");
    }
}

internal sealed class ValuationCaseConfiguration : IEntityTypeConfiguration<ValuationCase>
{
    public void Configure(EntityTypeBuilder<ValuationCase> builder)
    {
        builder.ToTable("ValuationCase");
        builder.HasKey(e => e.ValuationCaseId).HasName("PK_ValuationCase");
        builder.Property(e => e.CaseReference).HasMaxLength(50);

        builder.HasIndex(e => e.ValuationSubmissionId, "IX_ValuationCase_ValuationSubmissionId")
            .IncludeProperties(e => new { e.CaseReference, e.EndEventReference });

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.ValuationCases)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_ValuationCase_ValuationSubmission");

        builder.HasEventReferences("ValuationCase");
    }
}

internal sealed class ValuationSubmissionConfirmationDatesConfiguration : IEntityTypeConfiguration<ValuationSubmissionConfirmationDates>
{
    public void Configure(EntityTypeBuilder<ValuationSubmissionConfirmationDates> builder)
    {
        builder.ToTable("ValuationSubmissionConfirmationDates");
        builder.HasKey(e => e.ValuationSubmissionConfirmationDatesId).HasName("PK_ValuationSubmissionConfirmationDates");

        builder.HasIndex(e => e.ValuationSubmissionId, "IX_ValuationSubmissionConfirmationDates_ValuationSubmissionId")
            .IncludeProperties(e => new { e.DateFundingAndInvestmentStrategyWasFinalised, e.DateStatementOfStrategyWasSigned, e.EndEventReference });

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.ValuationSubmissionConfirmationDates)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_ValuationSubmissionConfirmationDates_ValuationSubmission");

        builder.HasEventReferences("ValuationSubmissionConfirmationDates");
    }
}

internal sealed class ValuationSubmissionDataConfiguration : IEntityTypeConfiguration<ValuationSubmissionData>
{
    public void Configure(EntityTypeBuilder<ValuationSubmissionData> builder)
    {
        builder.ToTable("ValuationSubmissionData");
        builder.HasKey(e => e.ValuationSubmissionDataId).HasName("PK_ValuationSubmissionData");

        // No max length: varchar(max).
        builder.Property(e => e.QuestionsAndResponses);

        builder.HasIndex(e => e.DocumentId, "IX_ValuationSubmissionData_DocumentId")
            .IncludeProperties(e => e.EndEventReference);

        builder.HasOne(e => e.Document)
            .WithMany(d => d.ValuationSubmissionData)
            .HasForeignKey(e => e.DocumentId)
            .HasConstraintName("FK_ValuationSubmissionData_Document");

        builder.HasEventReferences("ValuationSubmissionData");
    }
}

internal sealed class ValuationSubmissionGuardQuestionAnswerConfiguration : IEntityTypeConfiguration<ValuationSubmissionGuardQuestionAnswer>
{
    public void Configure(EntityTypeBuilder<ValuationSubmissionGuardQuestionAnswer> builder)
    {
        builder.ToTable("ValuationSubmissionGuardQuestionAnswer");
        builder.HasKey(e => e.ValuationSubmissionGuardQuestionAnswerId).HasName("PK_ValuationSubmissionGuardQuestionAnswer");

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.ValuationSubmissionGuardQuestionAnswers)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_ValuationSubmissionGuardQuestionAnswer_ValuationSubmission");

        builder.HasOne(e => e.GuardQuestionAnswer)
            .WithMany()
            .HasForeignKey(e => e.GuardQuestionAnswerId)
            .HasConstraintName("FK_ValuationSubmissionGuardQuestionAnswer_GuardQuestionAnswer");

        builder.HasEventReferences("ValuationSubmissionGuardQuestionAnswer");
    }
}

internal sealed class ValuationSubmissionStatusConfiguration : IEntityTypeConfiguration<ValuationSubmissionStatus>
{
    public void Configure(EntityTypeBuilder<ValuationSubmissionStatus> builder)
    {
        builder.ToTable("ValuationSubmissionStatus");
        builder.HasKey(e => e.ValuationSubmissionStatusId).HasName("PK_ValuationSubmissionStatus");

        builder.HasIndex(e => e.ValuationSubmissionId, "IX_ValuationSubmissionStatus_ValuationSubmissionId")
            .IncludeProperties(e => new { e.SubmissionStatusTypeId, e.EndEventReference });

        builder.HasOne(e => e.SubmissionStatusType)
            .WithMany()
            .HasForeignKey(e => e.SubmissionStatusTypeId)
            .HasConstraintName("FK_ValuationSubmissionStatus_SubmissionStatusType");

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.ValuationSubmissionStatuses)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_ValuationSubmissionStatus_ValuationSubmission");

        // The database project also declares FK_ValuationSubmissionStatus_Event on EndEventReference, a
        // duplicate of FK_ValuationSubmissionStatus_Event_End. EF allows one relationship per column set, so it is dropped.
        builder.HasEventReferences("ValuationSubmissionStatus");
    }
}

internal sealed class ValuationSubmittedDetailConfiguration : IEntityTypeConfiguration<ValuationSubmittedDetail>
{
    public void Configure(EntityTypeBuilder<ValuationSubmittedDetail> builder)
    {
        builder.ToTable("ValuationSubmittedDetail");
        builder.HasKey(e => e.ValuationSubmittedDetailId).HasName("PK_ValuationSubmittedDetail");

        builder.HasIndex(e => e.ValuationSubmissionId, "IX_ValuationSubmittedDetail_ValuationSubmissionId")
            .IncludeProperties(e => new { e.SubmittedDateTime, e.StartEventReference, e.EndEventReference });

        builder.HasOne(e => e.ValuationSubmission)
            .WithMany(s => s.ValuationSubmittedDetails)
            .HasForeignKey(e => e.ValuationSubmissionId)
            .HasConstraintName("FK_ValuationSubmittedDetail_ValuationSubmission");

        builder.HasEventReferences("ValuationSubmittedDetail");
    }
}
