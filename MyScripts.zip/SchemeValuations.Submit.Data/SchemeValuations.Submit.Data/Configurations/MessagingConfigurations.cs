using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SchemeValuations.Submit.Data.Entities.Messaging;

namespace SchemeValuations.Submit.Data.Configurations;

// NServiceBus persistence tables. NServiceBus owns their contents; they are mapped so the
// migrations create the same schema as the database project.

internal abstract class OutboxDataConfiguration<T> : IEntityTypeConfiguration<T>
    where T : OutboxData
{
    protected abstract string Schema { get; }

    public void Configure(EntityTypeBuilder<T> builder)
    {
        builder.ToTable("OutboxData", Schema);
        builder.HasKey(e => e.MessageId).IsClustered(false);

        builder.Property(e => e.MessageId).HasMaxLength(200).IsUnicode();
        builder.Property(e => e.Dispatched).HasColumnDefault(false);
        builder.Property(e => e.DispatchedAt).HasColumnType("datetime");
        builder.Property(e => e.PersistenceVersion).HasMaxLength(23);
        builder.Property(e => e.Operations).IsUnicode();

        builder.HasIndex(e => e.DispatchedAt, "Index_DispatchedAt").HasFilter("([Dispatched]=(1))");
    }
}

internal sealed class SharePointEndpointOutboxDataConfiguration : OutboxDataConfiguration<SharePointEndpointOutboxData>
{
    protected override string Schema => "SharePointEndpoint";
}

internal sealed class WebEndpointOutboxDataConfiguration : OutboxDataConfiguration<WebEndpointOutboxData>
{
    protected override string Schema => "WebEndpoint";
}

internal sealed class WebSagaEndpointOutboxDataConfiguration : OutboxDataConfiguration<WebSagaEndpointOutboxData>
{
    protected override string Schema => "WebSagaEndpoint";
}

internal sealed class SubmitSchemeValuationSagaConfiguration : IEntityTypeConfiguration<SubmitSchemeValuationSaga>
{
    public void Configure(EntityTypeBuilder<SubmitSchemeValuationSaga> builder)
    {
        builder.ToTable("SubmitSchemeValuationSaga", "WebSagaEndpoint");
        builder.HasKey(e => e.Id);
        builder.Property(e => e.Id).ValueGeneratedNever();

        builder.Property(e => e.Metadata).IsUnicode();
        builder.Property(e => e.Data).IsUnicode();
        builder.Property(e => e.PersistenceVersion).HasMaxLength(23);
        builder.Property(e => e.SagaTypeVersion).HasMaxLength(23);
        builder.Property(e => e.CorrelationSchemeValuationSubmissionId)
            .HasColumnName("Correlation_SchemeValuationSubmissionId")
            .HasMaxLength(255)
            .IsUnicode();

        builder.HasIndex(e => e.CorrelationSchemeValuationSubmissionId, "Index_Correlation_SchemeValuationSubmissionId")
            .IsUnique()
            .HasFilter("([Correlation_SchemeValuationSubmissionId] IS NOT NULL)");
    }
}
