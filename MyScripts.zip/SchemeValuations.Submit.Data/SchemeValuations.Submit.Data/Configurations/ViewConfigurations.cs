using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SchemeValuations.Submit.Data.Entities.Views;

namespace SchemeValuations.Submit.Data.Configurations;

// Keyless, read-only mappings over the database views. Migrations never create or alter
// entity types mapped with ToView; the view definitions live in Sql/Views and are applied
// by the AddViewsAndStoredProcedures migration.

internal sealed class DocumentCurrentViewConfiguration : IEntityTypeConfiguration<DocumentCurrentView>
{
    public void Configure(EntityTypeBuilder<DocumentCurrentView> builder)
        => builder.HasNoKey().ToView("uvw_Documents_Current", "dbo");
}

internal sealed class SchemeValuationSubmissionViewConfiguration : IEntityTypeConfiguration<SchemeValuationSubmissionView>
{
    public void Configure(EntityTypeBuilder<SchemeValuationSubmissionView> builder)
        => builder.HasNoKey().ToView("uvw_SchemeValuationSubmissions", "dbo");
}

internal sealed class SchemeValuationSubmissionCurrentViewConfiguration : IEntityTypeConfiguration<SchemeValuationSubmissionCurrentView>
{
    public void Configure(EntityTypeBuilder<SchemeValuationSubmissionCurrentView> builder)
        => builder.HasNoKey().ToView("uvw_SchemeValuationSubmissions_Current", "dbo");
}

internal sealed class UserSavedSubmissionCurrentViewConfiguration : IEntityTypeConfiguration<UserSavedSubmissionCurrentView>
{
    public void Configure(EntityTypeBuilder<UserSavedSubmissionCurrentView> builder)
    {
        builder.HasNoKey().ToView("uvw_UserSavedSubmissions_Current", "dbo");
        builder.Property(e => e.LastPageData).IsUnicode();
    }
}

internal sealed class ValuationCaseViewConfiguration : IEntityTypeConfiguration<ValuationCaseView>
{
    public void Configure(EntityTypeBuilder<ValuationCaseView> builder)
        => builder.HasNoKey().ToView("uvw_ValuationCase", "dbo");
}

internal sealed class ValuationSubmissionDataCurrentViewConfiguration : IEntityTypeConfiguration<ValuationSubmissionDataCurrentView>
{
    public void Configure(EntityTypeBuilder<ValuationSubmissionDataCurrentView> builder)
        => builder.HasNoKey().ToView("uvw_ValuationSubmissionData_Current", "dbo");
}

internal sealed class ValuationSubmissionGuardQuestionAnswerCurrentViewConfiguration : IEntityTypeConfiguration<ValuationSubmissionGuardQuestionAnswerCurrentView>
{
    public void Configure(EntityTypeBuilder<ValuationSubmissionGuardQuestionAnswerCurrentView> builder)
        => builder.HasNoKey().ToView("uvw_ValuationSubmissionGuardQuestionAnswers_Current", "dbo");
}
