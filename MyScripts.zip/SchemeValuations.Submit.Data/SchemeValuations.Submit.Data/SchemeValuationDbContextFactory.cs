using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace SchemeValuations.Submit.Data;

/// <summary>
/// Used by the dotnet-ef tools (migrations add / database update / migrations script).
/// Set SCHEMEVALUATION_CONNECTIONSTRING to target a database other than the LocalDB default.
/// </summary>
internal sealed class SchemeValuationDbContextFactory : IDesignTimeDbContextFactory<SchemeValuationDbContext>
{
    private const string DefaultConnectionString =
        @"Server=(localdb)\MSSQLLocalDB;Database=SchemeValuation;Trusted_Connection=True;TrustServerCertificate=True";

    public SchemeValuationDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("SCHEMEVALUATION_CONNECTIONSTRING") ?? DefaultConnectionString;

        var options = new DbContextOptionsBuilder<SchemeValuationDbContext>()
            .UseSqlServer(connectionString)
            .Options;

        return new SchemeValuationDbContext(options);
    }
}
