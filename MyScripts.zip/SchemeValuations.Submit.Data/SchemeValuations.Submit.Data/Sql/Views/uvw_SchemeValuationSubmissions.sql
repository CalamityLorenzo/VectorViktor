CREATE OR ALTER VIEW [dbo].[uvw_SchemeValuationSubmissions]
AS
/*
-------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Date: 			01/10/2024
Reason:			Return details of all valuation submissions and their related schemes, including PSR number
-------------------------------------------------------------------------------------------------------------------
*/
	SELECT 
		sch.ValuationSchemeId,
		sch.PSRNumber,
		sch.SchemeName,
		sub.ValuationSubmissionId,
		sub.SchemeValuationSubmissionId,
		sub.EffectiveDate,
		confirmationDates.DateFundingAndInvestmentStrategyWasFinalised,
		confirmationDates.DateStatementOfStrategyWasSigned,
		sta.ValuationSubmissionStatusId,
		sta.SubmissionStatusTypeId,
		sub.IsExcludedSubmission,
		sub.StartEventReference, 
		sub.EndEventReference, 
		e.CreateDateTime,
		e.UserId, 
		submitDet.SubmittedDateTime,
		submitEvent.UserId as SubmittedUserId
	FROM 
		dbo.ValuationSubmission sub
	INNER JOIN
		dbo.ValuationScheme sch
	ON  sch.ValuationSchemeId = sub.ValuationSchemeId
	LEFT JOIN
		[dbo].[ValuationSubmissionConfirmationDates] confirmationDates
	ON  sub.ValuationSubmissionId = confirmationDates.ValuationSubmissionId
	AND confirmationDates.EndEventReference IS NULL
	INNER JOIN
		dbo.[Event] e
	ON e.EventReference = sub.StartEventReference
	LEFT JOIN 
		dbo.ValuationSubmissionStatus sta
	ON sub.ValuationSubmissionId = sta.ValuationSubmissionId
	AND sta.EndEventReference IS NULL
	LEFT JOIN 
		dbo.ValuationSubmittedDetail submitDet
	ON sub.ValuationSubmissionId = submitDet.ValuationSubmissionId
	AND submitDet.EndEventReference IS NULL
	LEFT JOIN 
		dbo.[Event] submitEvent
	ON submitEvent.EventReference = submitDet.StartEventReference
