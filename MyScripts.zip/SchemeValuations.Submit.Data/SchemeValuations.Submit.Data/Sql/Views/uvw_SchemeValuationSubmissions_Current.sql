CREATE OR ALTER VIEW [dbo].[uvw_SchemeValuationSubmissions_Current]
AS
/*
---------------------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Date: 			31/07/2024
Reason:			Return details of all CURRENT valuation submissions and their related schemes, including PSR number
				We should only ever have 1 row returned per ValuationSubmissionId / ValuationSchemeId because we're joining  
				the CURRENT submissions, schemes & statuses, excluding all that have been end-dated
---------------------------------------------------------------------------------------------------------------------------------
*/
	SELECT 
		sub.ValuationSchemeId,
		sub.PSRNumber,
		sub.SchemeName,
		sub.ValuationSubmissionId,
		sub.SchemeValuationSubmissionId,
		sub.EffectiveDate,
		sub.DateFundingAndInvestmentStrategyWasFinalised,
		sub.DateStatementOfStrategyWasSigned,
		sub.ValuationSubmissionStatusId,
		sub.SubmissionStatusTypeId,
		sub.IsExcludedSubmission,
		sub.StartEventReference, 
		sub.EndEventReference, 
		sub.CreateDateTime,
		sub.UserId, 
		sub.SubmittedDateTime,
		sub.SubmittedUserId
	FROM 
		dbo.uvw_SchemeValuationSubmissions sub
	WHERE 
		sub.EndEventReference IS NULL
