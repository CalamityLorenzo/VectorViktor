CREATE OR ALTER VIEW [dbo].[uvw_ValuationCase]
AS
/*
-------------------------------------------------------------------------------------------------------------	
Created by: 	Denise Groves
Date: 			10/09/2024
Reason:			Return details of ALL (past AND current) ValuationCase rows, for CURRENT ValuationSubmissions
				
-------------------------------------------------------------------------------------------------------------
*/

SELECT DISTINCT 
				vc.ValuationCaseId, 
				s.ValuationSchemeId,
				s.PSRNumber,
				s.SchemeName,
				vc.ValuationSubmissionId, 
				vc.CaseReference, 
				vc.StartEventReference, 
				e.CreateDateTime, 
				e.UserId AS StartEventUser, 
				e.NotificationDate, 
				vc.EndEventReference, 
				ee.CreateDateTime AS EndEventDateTime, 
				ee.UserId AS EndEventUser,
				et.EventTypeDescription,
				s.SchemeValuationSubmissionId,
				s.EffectiveDate
FROM 
	dbo.ValuationCase vc
INNER JOIN dbo.Event e
	ON vc.StartEventReference = e.EventReference
INNER JOIN dbo.uvw_SchemeValuationSubmissions_Current s
	ON s.ValuationSubmissionId = vc.ValuationSubmissionId
LEFT OUTER JOIN dbo.Event ee
	ON vc.EndEventReference = ee.EventReference
LEFT OUTER JOIN dbo.EventType et
	ON e.EventTypeId = et.EventTypeId
