CREATE OR ALTER VIEW [dbo].[uvw_UserSavedSubmissions_Current]
AS
/*
-------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Date: 			27/05/2026
Reason:			Return current (i.e. not soft-deleted) user-saved submissions and their statuses
-------------------------------------------------------------------------------------------------------------------
*/

SELECT  u.[UserSavedSubmissionId],
        sch.PSRNumber,
		vs.[SchemeValuationSubmissionId],
        vs.[EffectiveDate],
		vc.CaseReference,
        u.[LastUpdated],
        u.[LastActionPageId],
        u.[LastPageData],
        u.[StartEventReference] AS UserSavedSubmissionStartEventReference,

        sch.SchemeName, 
        vs.ValuationSchemeId,

		sta.SubmissionStatusTypeId,
		sst.SubmissionStatusDescription,

        e.CreateDateTime AS ValuationSubmissionCreateDateTime,
		vs.ValuationSubmissionId,
		confirmationDates.DateFundingAndInvestmentStrategyWasFinalised,
		confirmationDates.DateStatementOfStrategyWasSigned,
		vs.IsExcludedSubmission,
		vs.StartEventReference, 
		vs.EndEventReference, 
		e.CreateDateTime,
		e.UserId as ValuationSubmissionUserId,					

		dyn.DynamicUserJourneyId,
		dyn.AdditionalRequiredDocumentTypeId, 
		docT.AdditionalRequiredDocumentDescription,
		dyn.FastTrackOrBespokeTypeId,
		fOrB.FastTrackOrBespokeDescription,
		dyn.DeficitOrSurplusTypeId,
		defSur.DeficitOrSurplusDescription,
		dyn.IsMultiDocUpload
FROM 
	[dbo].[UserSavedSubmission] u

INNER JOIN 
	dbo.ValuationSubmission vs
ON vs.ValuationSubmissionId = u.ValuationSubmissionId
AND vs.EndEventReference IS NULL

INNER JOIN 
		dbo.ValuationSubmissionStatus sta
ON vs.ValuationSubmissionId = sta.ValuationSubmissionId
AND sta.EndEventReference IS NULL

INNER JOIN
	dbo.SubmissionStatusType sst
ON sst.SubmissionStatusTypeId = sta.SubmissionStatusTypeId

LEFT OUTER JOIN 
	dbo.DynamicUserJourney dyn
ON dyn.ValuationSubmissionId = vs.ValuationSubmissionId
AND dyn.EndEventReference IS NULL	

LEFT OUTER JOIN
	dbo.ValuationCase vc
ON dyn.ValuationSubmissionId = vc.ValuationSubmissionId 
AND vc.EndEventReference IS NULL

INNER JOIN
	dbo.ValuationScheme sch
ON  sch.ValuationSchemeId = vs.ValuationSchemeId

LEFT JOIN
	[dbo].[ValuationSubmissionConfirmationDates] confirmationDates
ON  vs.ValuationSubmissionId = confirmationDates.ValuationSubmissionId
AND confirmationDates.EndEventReference IS NULL

INNER JOIN
	dbo.[Event] e
ON e.EventReference = vs.StartEventReference

LEFT OUTER JOIN
	dbo.AdditionalRequiredDocumentType docT
ON docT.AdditionalRequiredDocumentTypeId = dyn.AdditionalRequiredDocumentTypeId

LEFT OUTER JOIN
	dbo.FastTrackOrBespokeType fOrB
ON fOrB.FastTrackOrBespokeTypeId = dyn.FastTrackOrBespokeTypeId

LEFT OUTER JOIN
	dbo.DeficitOrSurplusType defSur
ON defSur.DeficitOrSurplusTypeId = dyn.DeficitOrSurplusTypeId

WHERE 
    u.EndEventReference IS NULL
