using Microsoft.EntityFrameworkCore;
using SchemeValuations.Submit.Data.Entities;

namespace SchemeValuations.Submit.Data.Services;

/// <summary>
/// Write operations that replace the database's usp_Write_* and usp_Create_EventById stored procedures.
/// </summary>
/// <remarks>
/// <para>
/// Every change is audited: an <see cref="Event"/> row is created and becomes the StartEventReference of new rows
/// and the EndEventReference of the rows they replace (soft delete). Each public method runs in one transaction,
/// or joins the context's current transaction if one is open.
/// </para>
/// <para>
/// Methods call SaveChanges, so any unsaved changes already tracked by the context are saved with them.
/// Rows inserted here are detached afterwards and are not left in the change tracker.
/// String comparisons (scheme names, case references, file names) run in SQL, so they use the database
/// collation (case-insensitive), as the stored procedures did.
/// </para>
/// Business rule failures throw <see cref="SchemeValuationDataException"/>.
/// </remarks>
public sealed class SchemeValuationCommands(SchemeValuationDbContext db)
{
    private readonly SchemeValuationQueries _queries = new(db);

    /// <summary>Creates an <see cref="Event"/> row and returns its EventReference. Was usp_Create_EventById.</summary>
    public Task<int> CreateEventByIdAsync(
        short eventTypeId,
        string schemeValuationSubmissionId,
        string userId,
        short eventSourceTypeId,
        int? valuationSubmissionId = null,
        string? transactionId = null,
        DateTime? notificationDate = null,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(
            () => CreateEventAsync(eventTypeId, schemeValuationSubmissionId, userId, eventSourceTypeId, valuationSubmissionId, transactionId, notificationDate, cancellationToken),
            cancellationToken);

    /// <summary>
    /// End-events the current document of the given type. Returns its DocumentId, or null when there was no
    /// current document of that type. Was usp_Write_CancelDocument.
    /// </summary>
    public Task<int?> WriteCancelDocumentAsync(string schemeValuationSubmissionId, short documentType, string userId, CancellationToken cancellationToken = default)
        => InTransactionAsync<int?>(async () =>
        {
            RequireSchemeValuationSubmissionId(schemeValuationSubmissionId);
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            var documentId = await db.Documents
                .Where(d => d.DocumentTypeId == documentType && d.ValuationSubmissionId == valuationSubmissionId && d.EndEventReference == null)
                .Select(d => (int?)d.DocumentId)
                .FirstOrDefaultAsync(cancellationToken);

            if (documentId is null)
            {
                return null;
            }

            var eventReference = await CreateEventAsync(
                EventTypeIds.UserUploadedDocumentCancelled, schemeValuationSubmissionId, userId, EventSourceTypeIds.SchemeValuationSubmission,
                valuationSubmissionId, null, null, cancellationToken);

            await EndCurrentAsync(db.Documents.Where(d => d.DocumentId == documentId), eventReference, cancellationToken);

            return documentId;
        }, cancellationToken);

    /// <summary>
    /// Adds a document and sets its initial status, end-eventing any current document of the same type.
    /// If an identical current document already exists (the user went back and forward again), returns it and only
    /// updates its status if that changed. Was usp_Write_Document.
    /// </summary>
    public Task<int> WriteDocumentAsync(
        string schemeValuationSubmissionId,
        string userId,
        short eventSourceType,
        short eventType,
        string uploadedFileName,
        string internalFileName,
        string fileHash,
        long? fileSize,
        Guid sagaUploadedFileCorrelationId,
        short documentType,
        short documentStatusType,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            if (fileSize is null)
            {
                throw new SchemeValuationDataException(
                    $"Filesize cannot be null for filename \"{uploadedFileName}\" and SubmissionId \"{schemeValuationSubmissionId} and DocumentType {documentType}\".");
            }

            RequireSchemeValuationSubmissionId(schemeValuationSubmissionId);

            if (sagaUploadedFileCorrelationId == Guid.Empty)
            {
                throw new SchemeValuationDataException("SagaUploadedFileCorrelationId cannot be the default GUID value.");
            }

            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            // Query syntax; the second "from" is a SelectMany. The equivalent in method syntax:
            //
            //   db.Documents
            //       .Where(d => d.ValuationSubmissionId == valuationSubmissionId
            //           && d.UploadedFileName == uploadedFileName
            //           && d.InternalFileName == internalFileName
            //           && d.FileHash == fileHash
            //           && d.SagaUploadedFileCorrelationId == sagaUploadedFileCorrelationId
            //           && d.DocumentTypeId == documentType
            //           && d.EndEventReference == null)
            //       .SelectMany(d => d.DocumentStatuses)
            //       .OrderBy(s => s.EndEventReference == null ? 0 : 1) // current status first
            //       .Select(s => new { s.DocumentId, s.DocumentStatusTypeId })
            //       .FirstOrDefaultAsync(cancellationToken);
            var existing = await (
                from d in db.Documents
                where d.ValuationSubmissionId == valuationSubmissionId
                    && d.UploadedFileName == uploadedFileName
                    && d.InternalFileName == internalFileName
                    && d.FileHash == fileHash
                    && d.SagaUploadedFileCorrelationId == sagaUploadedFileCorrelationId
                    && d.DocumentTypeId == documentType
                    && d.EndEventReference == null
                from status in d.DocumentStatuses
                orderby status.EndEventReference == null ? 0 : 1
                select new { d.DocumentId, status.DocumentStatusTypeId })
                .FirstOrDefaultAsync(cancellationToken);

            if (existing is not null)
            {
                if (existing.DocumentStatusTypeId != documentStatusType)
                {
                    await WriteDocumentStatusCoreAsync(
                        schemeValuationSubmissionId, documentStatusType, existing.DocumentId, null, userId, eventSourceType, eventType, cancellationToken);
                }

                return existing.DocumentId;
            }

            var eventReference = await CreateEventAsync(eventType, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            // Only one current document of each type per submission.
            await EndCurrentAsync(
                db.Documents.Where(d => d.ValuationSubmissionId == valuationSubmissionId && d.DocumentTypeId == documentType),
                eventReference,
                cancellationToken);

            var document = await InsertAsync(new Document
            {
                ValuationSubmissionId = valuationSubmissionId,
                UploadedFileName = uploadedFileName,
                InternalFileName = internalFileName,
                FileHash = fileHash,
                FileSize = fileSize,
                SagaUploadedFileCorrelationId = sagaUploadedFileCorrelationId,
                DocumentTypeId = documentType,
                StartEventReference = eventReference,
            }, cancellationToken);

            await WriteDocumentStatusCoreAsync(
                schemeValuationSubmissionId, documentStatusType, document.DocumentId, eventReference, null, null, null, cancellationToken);

            return document.DocumentId;
        }, cancellationToken);

    /// <summary>
    /// Sets a document's status, end-eventing its current status. Returns the existing row when the document already has
    /// that status. Pass <paramref name="eventReference"/> when part of an existing event; otherwise pass
    /// <paramref name="userId"/>, <paramref name="eventSourceType"/> and <paramref name="eventTypeId"/> to create one.
    /// Was usp_Write_DocumentStatus.
    /// </summary>
    public Task<int> WriteDocumentStatusAsync(
        string schemeValuationSubmissionId,
        short documentStatusTypeId,
        int documentId,
        int? eventReference = null,
        string? userId = null,
        short? eventSourceType = null,
        short? eventTypeId = null,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(
            () => WriteDocumentStatusCoreAsync(schemeValuationSubmissionId, documentStatusTypeId, documentId, eventReference, userId, eventSourceType, eventTypeId, cancellationToken),
            cancellationToken);

    /// <summary>
    /// Records the dynamic user journey choices for a submission, replacing the current ones.
    /// Returns the current row unchanged when the choices are the same. Was usp_Write_DynamicUserJourney.
    /// </summary>
    public Task<int> WriteDynamicUserJourneyAsync(
        string schemeValuationSubmissionId,
        short fastTrackOrBespokeType,
        short deficitOrSurplusType,
        short additionalRequiredDocumentType,
        string userId,
        short eventSourceType,
        bool isMultiDocUpload = false,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            RequireSchemeValuationSubmissionId(schemeValuationSubmissionId);
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            var current = await db.DynamicUserJourneys
                .Where(j => j.ValuationSubmissionId == valuationSubmissionId && j.EndEventReference == null)
                .Select(j => new { j.DynamicUserJourneyId, j.FastTrackOrBespokeTypeId, j.DeficitOrSurplusTypeId, j.AdditionalRequiredDocumentTypeId, j.IsMultiDocUpload })
                .FirstOrDefaultAsync(cancellationToken);

            if (current is not null
                && current.FastTrackOrBespokeTypeId == fastTrackOrBespokeType
                && current.DeficitOrSurplusTypeId == deficitOrSurplusType
                && current.AdditionalRequiredDocumentTypeId == additionalRequiredDocumentType
                && current.IsMultiDocUpload == isMultiDocUpload)
            {
                return current.DynamicUserJourneyId;
            }

            var eventReference = await CreateEventAsync(EventTypeIds.DynamicUserJourneySaved, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            await EndCurrentAsync(db.DynamicUserJourneys.Where(j => j.ValuationSubmissionId == valuationSubmissionId), eventReference, cancellationToken);

            var journey = await InsertAsync(new DynamicUserJourney
            {
                ValuationSubmissionId = valuationSubmissionId,
                FastTrackOrBespokeTypeId = fastTrackOrBespokeType,
                DeficitOrSurplusTypeId = deficitOrSurplusType,
                AdditionalRequiredDocumentTypeId = additionalRequiredDocumentType,
                IsMultiDocUpload = isMultiDocUpload,
                StartEventReference = eventReference,
            }, cancellationToken);

            return journey.DynamicUserJourneyId;
        }, cancellationToken);

    /// <summary>
    /// Saves the user's progress on a submission as a new row and closes any previous open row for it.
    /// Was usp_Write_UserSavedSubmission.
    /// </summary>
    public Task<int> WriteUserSavedSubmissionAsync(
        string schemeValuationSubmissionId,
        string userId,
        short eventSourceTypeId,
        Guid lastActionPageId,
        string lastPageData,
        DateTime lastUpdated,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            RequireSchemeValuationSubmissionId(schemeValuationSubmissionId);
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            var eventReference = await CreateEventAsync(EventTypeIds.UserSavedSubmission, schemeValuationSubmissionId, userId, eventSourceTypeId, cancellationToken);

            var saved = await InsertAsync(new UserSavedSubmission
            {
                ValuationSubmissionId = valuationSubmissionId,
                LastUpdated = lastUpdated,
                LastActionPageId = lastActionPageId,
                LastPageData = lastPageData,
                StartEventReference = eventReference,
            }, cancellationToken);

            await EndCurrentAsync(
                db.UserSavedSubmissions.Where(u => u.ValuationSubmissionId == valuationSubmissionId && u.UserSavedSubmissionId != saved.UserSavedSubmissionId),
                eventReference,
                cancellationToken);

            return saved.UserSavedSubmissionId;
        }, cancellationToken);

    /// <summary>
    /// Assigns a D365 case reference to a submission, replacing the current one. Returns the current row unchanged
    /// when it already has this case reference. Was usp_Write_ValuationCase.
    /// </summary>
    public Task<int> WriteValuationCaseAsync(
        string schemeValuationSubmissionId,
        string caseReference,
        string userId,
        short eventType,
        short eventSourceType,
        DateTime? notificationDate = null,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            var sameCaseId = await db.ValuationCases
                .Where(c => c.ValuationSubmissionId == valuationSubmissionId && c.EndEventReference == null && c.CaseReference == caseReference)
                .Select(c => (int?)c.ValuationCaseId)
                .FirstOrDefaultAsync(cancellationToken);

            if (sameCaseId is not null)
            {
                return sameCaseId.Value;
            }

            var eventReference = await CreateEventAsync(eventType, schemeValuationSubmissionId, userId, eventSourceType, null, null, notificationDate, cancellationToken);

            await EndCurrentAsync(db.ValuationCases.Where(c => c.ValuationSubmissionId == valuationSubmissionId), eventReference, cancellationToken);

            var valuationCase = await InsertAsync(new ValuationCase
            {
                ValuationSubmissionId = valuationSubmissionId,
                CaseReference = caseReference,
                StartEventReference = eventReference,
            }, cancellationToken);

            return valuationCase.ValuationCaseId;
        }, cancellationToken);

    /// <summary>
    /// Adds a scheme for a PSR number, or a new version of it when the name has changed. Returns the current row
    /// when the name is unchanged. Was usp_Write_ValuationScheme.
    /// </summary>
    public Task<int> WriteValuationSchemeAsync(int psrNumber, string schemeName, int eventReference, CancellationToken cancellationToken = default)
        => InTransactionAsync(() => WriteValuationSchemeCoreAsync(psrNumber, schemeName, eventReference, cancellationToken), cancellationToken);

    /// <summary>
    /// Starts a new valuation submission with status In Progress. An existing Submitted submission for the same PSR and
    /// effective date becomes Superseded; an In Progress one becomes Cancelled. Was usp_Write_ValuationSubmission.
    /// </summary>
    public Task<int> WriteValuationSubmissionAsync(
        string schemeValuationSubmissionId,
        int psrNumber,
        string schemeName,
        DateOnly effectiveDate,
        string userId,
        short eventSourceType,
        bool isExcludedSubmission = false,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            if (effectiveDate == default || effectiveDate == new DateOnly(1900, 1, 1))
            {
                throw new SchemeValuationDataException("EffectiveDate cannot be blank.");
            }

            var previous = await db.SchemeValuationSubmissionsCurrent
                .Where(s => s.PSRNumber == psrNumber
                    && s.EffectiveDate == effectiveDate
                    && (s.SubmissionStatusTypeId == SubmissionStatusTypeIds.Submitted || s.SubmissionStatusTypeId == SubmissionStatusTypeIds.InProgress))
                .Select(s => new { s.SchemeValuationSubmissionId, s.SubmissionStatusTypeId })
                .FirstOrDefaultAsync(cancellationToken);

            if (previous is not null)
            {
                // The previous submission gets its own event; the ValuationSubmission row itself is not end-evented.
                var replacementStatus = previous.SubmissionStatusTypeId == SubmissionStatusTypeIds.Submitted
                    ? SubmissionStatusTypeIds.Superseded
                    : SubmissionStatusTypeIds.Cancelled;

                var supersededEventReference = await CreateEventAsync(
                    EventTypeIds.SchemeValuationSuperseded, previous.SchemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

                await WriteValuationSubmissionStatusCoreAsync(
                    previous.SchemeValuationSubmissionId, replacementStatus, userId, 0, 0, supersededEventReference, cancellationToken);
            }

            var startedEventReference = await CreateEventAsync(
                EventTypeIds.SchemeValuationSubmissionStarted, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            var valuationSchemeId = await db.ValuationSchemes
                .Where(s => s.PSRNumber == psrNumber && s.SchemeName == schemeName && s.EndEventReference == null)
                .Select(s => (int?)s.ValuationSchemeId)
                .FirstOrDefaultAsync(cancellationToken)
                ?? await WriteValuationSchemeCoreAsync(psrNumber, schemeName, startedEventReference, cancellationToken);

            var submission = await InsertAsync(new ValuationSubmission
            {
                SchemeValuationSubmissionId = schemeValuationSubmissionId,
                ValuationSchemeId = valuationSchemeId,
                EffectiveDate = effectiveDate,
                IsExcludedSubmission = isExcludedSubmission,
                StartEventReference = startedEventReference,
            }, cancellationToken);

            await WriteValuationSubmissionStatusCoreAsync(
                schemeValuationSubmissionId, SubmissionStatusTypeIds.InProgress, userId, 0, 0, startedEventReference, cancellationToken);

            return submission.ValuationSubmissionId;
        }, cancellationToken);

    /// <summary>
    /// Records the confirmation dates provided by the user, replacing the current ones.
    /// Was usp_Write_ValuationSubmissionConfirmationDates.
    /// </summary>
    public Task<int> WriteValuationSubmissionConfirmationDatesAsync(
        string schemeValuationSubmissionId,
        DateOnly dateFundingAndInvestmentStrategyWasFinalised,
        DateOnly dateStatementOfStrategyWasSigned,
        string userId,
        short eventSourceType,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);
            var eventReference = await CreateEventAsync(EventTypeIds.ConfirmationDatesAdded, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            await EndCurrentAsync(db.ValuationSubmissionConfirmationDates.Where(d => d.ValuationSubmissionId == valuationSubmissionId), eventReference, cancellationToken);

            var dates = await InsertAsync(new ValuationSubmissionConfirmationDates
            {
                ValuationSubmissionId = valuationSubmissionId,
                DateFundingAndInvestmentStrategyWasFinalised = dateFundingAndInvestmentStrategyWasFinalised,
                DateStatementOfStrategyWasSigned = dateStatementOfStrategyWasSigned,
                StartEventReference = eventReference,
            }, cancellationToken);

            return dates.ValuationSubmissionConfirmationDatesId;
        }, cancellationToken);

    /// <summary>
    /// Records the data extracted from an uploaded Statement of Strategy, replacing the current data for that document.
    /// Was usp_Write_ValuationSubmissionData.
    /// </summary>
    /// <remarks>
    /// The stored procedure end-evented the current row but only inserted when there was no current row, so re-extracting
    /// a document left it with no current data. This always inserts the new data.
    /// </remarks>
    public Task<int> WriteValuationSubmissionDataAsync(
        string questionsAndResponses,
        int documentId,
        string userId,
        string schemeValuationSubmissionId,
        short eventSourceType,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            var eventReference = await CreateEventAsync(EventTypeIds.StatementOfStrategyExtracted, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            await EndCurrentAsync(db.ValuationSubmissionData.Where(d => d.DocumentId == documentId), eventReference, cancellationToken);

            var data = await InsertAsync(new ValuationSubmissionData
            {
                QuestionsAndResponses = questionsAndResponses,
                DocumentId = documentId,
                StartEventReference = eventReference,
            }, cancellationToken);

            return data.ValuationSubmissionDataId;
        }, cancellationToken);

    /// <summary>
    /// Records a guard question answer, replacing any current answer to the same question. Returns the existing row
    /// when this answer is already current. Was usp_Write_ValuationSubmissionGuardQuestionAnswer.
    /// </summary>
    public Task<int> WriteValuationSubmissionGuardQuestionAnswerAsync(
        string schemeValuationSubmissionId,
        int guardQuestionAnswerId,
        string userId,
        short eventSourceType,
        short eventType,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            var existingId = await db.ValuationSubmissionGuardQuestionAnswersCurrent
                .Where(a => a.ValuationSubmissionId == valuationSubmissionId && a.GuardQuestionAnswerId == guardQuestionAnswerId)
                .Select(a => (int?)a.ValuationSubmissionGuardQuestionAnswerId)
                .FirstOrDefaultAsync(cancellationToken);

            if (existingId is not null)
            {
                return existingId.Value;
            }

            var eventReference = await CreateEventAsync(eventType, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            var guardQuestionId = await db.GuardQuestionAnswers
                .Where(a => a.GuardQuestionAnswerId == guardQuestionAnswerId)
                .Select(a => (int?)a.GuardQuestionId)
                .FirstOrDefaultAsync(cancellationToken);

            await EndCurrentAsync(
                db.ValuationSubmissionGuardQuestionAnswers.Where(a => a.ValuationSubmissionId == valuationSubmissionId && a.GuardQuestionAnswer.GuardQuestionId == guardQuestionId),
                eventReference,
                cancellationToken);

            var answer = await InsertAsync(new ValuationSubmissionGuardQuestionAnswer
            {
                ValuationSubmissionId = valuationSubmissionId,
                GuardQuestionAnswerId = guardQuestionAnswerId,
                StartEventReference = eventReference,
            }, cancellationToken);

            return answer.ValuationSubmissionGuardQuestionAnswerId;
        }, cancellationToken);

    /// <summary>
    /// Sets a submission's status, end-eventing the current one. Returns the current row when the status is unchanged.
    /// Pass <paramref name="currentEventReference"/> when part of an existing event; when it is 0 a new event is created
    /// from <paramref name="eventSourceType"/> and <paramref name="eventType"/>. Was usp_Write_ValuationSubmissionStatus.
    /// </summary>
    public Task<int> WriteValuationSubmissionStatusAsync(
        string schemeValuationSubmissionId,
        short submissionStatusType,
        string userId,
        short eventSourceType = 0,
        short eventType = 0,
        int currentEventReference = 0,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(
            () => WriteValuationSubmissionStatusCoreAsync(schemeValuationSubmissionId, submissionStatusType, userId, eventSourceType, eventType, currentEventReference, cancellationToken),
            cancellationToken);

    /// <summary>
    /// Records when a submission was submitted and sets its status to Submitted, both under the same event.
    /// Fails if the submission has been cancelled or superseded. Was usp_Write_ValuationSubmittedDetail.
    /// </summary>
    public Task<int> WriteValuationSubmittedDetailAsync(
        string schemeValuationSubmissionId,
        DateTime submittedDateTime,
        string userId,
        short eventSourceType,
        short eventType = EventTypeIds.SchemeValuationSubmitted,
        CancellationToken cancellationToken = default)
        => InTransactionAsync(async () =>
        {
            RequireSchemeValuationSubmissionId(schemeValuationSubmissionId);
            var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

            var currentStatus = await db.ValuationSubmissionStatuses
                .Where(s => s.ValuationSubmissionId == valuationSubmissionId && s.EndEventReference == null)
                .Select(s => (short?)s.SubmissionStatusTypeId)
                .FirstOrDefaultAsync(cancellationToken);

            if (currentStatus == SubmissionStatusTypeIds.Cancelled)
            {
                throw new SchemeValuationDataException(
                    $"Unable to submit because the submission has already been cancelled! @SchemeValuationSubmissionId: {schemeValuationSubmissionId}.");
            }

            if (currentStatus == SubmissionStatusTypeIds.Superseded)
            {
                throw new SchemeValuationDataException(
                    $"Unable to submit because the submission has already been superseded! @SchemeValuationSubmissionId: {schemeValuationSubmissionId}.");
            }

            var eventReference = await CreateEventAsync(eventType, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);

            await EndCurrentAsync(db.ValuationSubmittedDetails.Where(d => d.ValuationSubmissionId == valuationSubmissionId), eventReference, cancellationToken);

            await WriteValuationSubmissionStatusCoreAsync(
                schemeValuationSubmissionId, SubmissionStatusTypeIds.Submitted, userId, 0, 0, eventReference, cancellationToken);

            var detail = await InsertAsync(new ValuationSubmittedDetail
            {
                ValuationSubmissionId = valuationSubmissionId,
                SubmittedDateTime = submittedDateTime,
                StartEventReference = eventReference,
            }, cancellationToken);

            return detail.ValuationSubmittedDetailId;
        }, cancellationToken);

    private async Task<int> WriteDocumentStatusCoreAsync(
        string schemeValuationSubmissionId,
        short documentStatusTypeId,
        int documentId,
        int? eventReference,
        string? userId,
        short? eventSourceType,
        short? eventTypeId,
        CancellationToken cancellationToken)
    {
        var existingId = await db.DocumentStatuses
            .Where(s => s.DocumentStatusTypeId == documentStatusTypeId && s.DocumentId == documentId && s.EndEventReference == null)
            .Select(s => (int?)s.DocumentStatusId)
            .FirstOrDefaultAsync(cancellationToken);

        if (existingId is not null)
        {
            return existingId.Value;
        }

        if (eventReference is null)
        {
            if (eventTypeId is null)
            {
                throw new SchemeValuationDataException("@EventTypeId cannot be NULL");
            }

            if (eventSourceType is null)
            {
                throw new SchemeValuationDataException("EventSourceType cannot be null when no EventReference is supplied.");
            }

            eventReference = await CreateEventAsync(eventTypeId.Value, schemeValuationSubmissionId, userId, eventSourceType.Value, cancellationToken);
        }

        // Only one current status per document.
        await EndCurrentAsync(db.DocumentStatuses.Where(s => s.DocumentId == documentId), eventReference.Value, cancellationToken);

        var status = await InsertAsync(new DocumentStatus
        {
            DocumentStatusTypeId = documentStatusTypeId,
            DocumentId = documentId,
            StartEventReference = eventReference.Value,
        }, cancellationToken);

        return status.DocumentStatusId;
    }

    private async Task<int> WriteValuationSchemeCoreAsync(int psrNumber, string schemeName, int eventReference, CancellationToken cancellationToken)
    {
        var current = await db.ValuationSchemes
            .Where(s => s.PSRNumber == psrNumber && s.EndEventReference == null)
            .Select(s => new { s.ValuationSchemeId, NameUnchanged = s.SchemeName == schemeName })
            .FirstOrDefaultAsync(cancellationToken);

        if (current is { NameUnchanged: true })
        {
            return current.ValuationSchemeId;
        }

        // Only one current scheme per PSR number.
        await EndCurrentAsync(db.ValuationSchemes.Where(s => s.PSRNumber == psrNumber), eventReference, cancellationToken);

        var scheme = await InsertAsync(new ValuationScheme
        {
            PSRNumber = psrNumber,
            SchemeName = schemeName,
            StartEventReference = eventReference,
        }, cancellationToken);

        return scheme.ValuationSchemeId;
    }

    private async Task<int> WriteValuationSubmissionStatusCoreAsync(
        string schemeValuationSubmissionId,
        short submissionStatusType,
        string userId,
        short eventSourceType,
        short eventType,
        int currentEventReference,
        CancellationToken cancellationToken)
    {
        var valuationSubmissionId = await _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId, cancellationToken);

        var current = await db.ValuationSubmissionStatuses
            .Where(s => s.ValuationSubmissionId == valuationSubmissionId && s.EndEventReference == null)
            .Select(s => new { s.ValuationSubmissionStatusId, s.SubmissionStatusTypeId })
            .FirstOrDefaultAsync(cancellationToken);

        if (current?.SubmissionStatusTypeId == submissionStatusType)
        {
            return current.ValuationSubmissionStatusId;
        }

        if (currentEventReference == 0)
        {
            currentEventReference = await CreateEventAsync(eventType, schemeValuationSubmissionId, userId, eventSourceType, cancellationToken);
        }
        else if (!await db.Events.AnyAsync(e => e.EventReference == currentEventReference, cancellationToken))
        {
            throw new SchemeValuationDataException($"CurrentEventReference {currentEventReference} does not exist in dbo.Event");
        }

        // Only one current status per submission.
        await EndCurrentAsync(db.ValuationSubmissionStatuses.Where(s => s.ValuationSubmissionId == valuationSubmissionId), currentEventReference, cancellationToken);

        var status = await InsertAsync(new ValuationSubmissionStatus
        {
            SubmissionStatusTypeId = submissionStatusType,
            ValuationSubmissionId = valuationSubmissionId,
            StartEventReference = currentEventReference,
        }, cancellationToken);

        return status.ValuationSubmissionStatusId;
    }

    private Task<int> CreateEventAsync(short eventTypeId, string? schemeValuationSubmissionId, string? userId, short eventSourceTypeId, CancellationToken cancellationToken)
        => CreateEventAsync(eventTypeId, schemeValuationSubmissionId, userId, eventSourceTypeId, null, null, null, cancellationToken);

    private async Task<int> CreateEventAsync(
        short eventTypeId,
        string? schemeValuationSubmissionId,
        string? userId,
        short eventSourceTypeId,
        int? valuationSubmissionId,
        string? transactionId,
        DateTime? notificationDate,
        CancellationToken cancellationToken)
    {
        var isActive = await db.EventTypes
            .Where(t => t.EventTypeId == eventTypeId)
            .Select(t => (bool?)t.IsActive)
            .FirstOrDefaultAsync(cancellationToken);

        if (isActive is null)
        {
            throw new SchemeValuationDataException($"EventTypeId {eventTypeId} does not exist in dbo.EventType");
        }

        if (IsBlank(userId))
        {
            throw new SchemeValuationDataException("UserId cannot be null or empty.");
        }

        if (IsBlank(schemeValuationSubmissionId))
        {
            throw new SchemeValuationDataException("SchemeValuationSubmissionId cannot be null or empty.");
        }

        if (isActive == false)
        {
            throw new SchemeValuationDataException($"EventTypeId {eventTypeId} is not active, so no Event was created.");
        }

        var created = await InsertAsync(new Event
        {
            EventTypeId = eventTypeId,
            ValuationSubmissionId = valuationSubmissionId,
            SchemeValuationSubmissionId = schemeValuationSubmissionId,
            UserId = userId!,
            TransactionId = transactionId,
            NotificationDate = notificationDate,
            EventSourceTypeId = eventSourceTypeId,
        }, cancellationToken);

        return created.EventReference;
    }

    /// <summary>
    /// Soft-deletes the rows of <paramref name="rows"/> that are still current, by setting their EndEventReference to
    /// <paramref name="eventReference"/>. Every end-dating in this class goes through here, so this is the one place to
    /// hook in auditing, logging or events for these updates.
    /// </summary>
    /// <remarks>
    /// Runs a single set-based UPDATE (ExecuteUpdate), which bypasses the change tracker and SaveChanges, and so is not
    /// seen by SaveChanges interceptors.
    /// </remarks>
    private Task<int> EndCurrentAsync<T>(IQueryable<T> rows, int eventReference, CancellationToken cancellationToken)
        where T : class, IEventTracked
        => rows
            .Where(r => r.EndEventReference == null)
            .ExecuteUpdateAsync(s => s.SetProperty(r => r.EndEventReference, eventReference), cancellationToken);

    /// <summary>Inserts one row, then detaches it so later bulk updates cannot leave a stale copy in the change tracker.</summary>
    private async Task<T> InsertAsync<T>(T entity, CancellationToken cancellationToken)
        where T : class
    {
        var entry = db.Add(entity);
        try
        {
            await db.SaveChangesAsync(cancellationToken);
        }
        finally
        {
            entry.State = EntityState.Detached;
        }

        return entity;
    }

    /// <summary>
    /// Runs <paramref name="operation"/> in a transaction, joining the context's current transaction if there is one.
    /// Uses the configured execution strategy, so it also works with EnableRetryOnFailure.
    /// </summary>
    private async Task<T> InTransactionAsync<T>(Func<Task<T>> operation, CancellationToken cancellationToken)
    {
        if (db.Database.CurrentTransaction is not null)
        {
            return await operation();
        }

        var strategy = db.Database.CreateExecutionStrategy();
        return await strategy.ExecuteAsync(async ct =>
        {
            await using var transaction = await db.Database.BeginTransactionAsync(ct);
            var result = await operation();
            await transaction.CommitAsync(ct);
            return result;
        }, cancellationToken);
    }

    private static void RequireSchemeValuationSubmissionId(string? schemeValuationSubmissionId)
    {
        if (schemeValuationSubmissionId is null)
        {
            throw new SchemeValuationDataException("SchemeValuationSubmissionId cannot be null.");
        }
    }

    // SQL Server ignores trailing spaces when comparing, so the procedures treated '   ' as ''.
    private static bool IsBlank(string? value) => value is null || value.TrimEnd(' ').Length == 0;
}
