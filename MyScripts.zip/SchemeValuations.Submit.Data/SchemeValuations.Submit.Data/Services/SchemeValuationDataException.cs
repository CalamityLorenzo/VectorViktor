namespace SchemeValuations.Submit.Data.Services;

/// <summary>
/// A business rule failure raised by <see cref="SchemeValuationCommands"/> or <see cref="SchemeValuationQueries"/>.
/// Replaces the stored procedures' <c>THROW 50005</c> errors and keeps their messages.
/// </summary>
public class SchemeValuationDataException(string message) : Exception(message);
