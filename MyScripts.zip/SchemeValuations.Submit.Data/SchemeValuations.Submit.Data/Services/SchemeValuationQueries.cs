using Microsoft.EntityFrameworkCore;
using SchemeValuations.Submit.Data.Entities;
using SchemeValuations.Submit.Data.Entities.Views;

namespace SchemeValuations.Submit.Data.Services;

/// <summary>
/// Read operations that replace the database's usp_Read_* and usp_Report_* stored procedures.
/// All queries are no-tracking.
/// </summary>
public sealed class SchemeValuationQueries(SchemeValuationDbContext db)
{
    /// <summary>All (past and current) case references for a submission. Was usp_Read_CaseReferenceData.</summary>
    public Task<List<CaseReferenceDataResult>> ReadCaseReferenceDataAsync(string schemeValuationSubmissionId, CancellationToken cancellationToken = default)
        => db.ValuationCasesView
            .Where(c => c.SchemeValuationSubmissionId == schemeValuationSubmissionId)
            .Select(c => new CaseReferenceDataResult
            {
                ValuationCaseId = c.ValuationCaseId,
                ValuationSchemeId = c.ValuationSchemeId,
                PSRNumber = c.PSRNumber,
                SchemeName = c.SchemeName,
                ValuationSubmissionId = c.ValuationSubmissionId,
                CaseReference = c.CaseReference,
                SchemeValuationSubmissionId = c.SchemeValuationSubmissionId,
                EffectiveDate = c.EffectiveDate,
            })
            .ToListAsync(cancellationToken);

    /// <summary>
    /// Current documents for a submission, optionally only when the submission has the given status.
    /// Was usp_Read_DocumentMetadata.
    /// </summary>
    public Task<List<DocumentMetadataResult>> ReadDocumentMetadataAsync(string schemeValuationSubmissionId, short? submissionStatusType = null, CancellationToken cancellationToken = default)
        => (from submission in db.SchemeValuationSubmissionsView
            join document in db.DocumentsCurrent on submission.ValuationSubmissionId equals document.ValuationSubmissionId
            where submission.SchemeValuationSubmissionId == schemeValuationSubmissionId
                && (submissionStatusType == null || submission.SubmissionStatusTypeId == submissionStatusType)
            select new DocumentMetadataResult
            {
                ValuationSchemeId = submission.ValuationSchemeId,
                PSRNumber = submission.PSRNumber,
                ValuationSubmissionId = submission.ValuationSubmissionId,
                SchemeValuationSubmissionId = submission.SchemeValuationSubmissionId,
                ValuationSubmissionStatusId = submission.ValuationSubmissionStatusId,
                SubmissionStatusTypeId = submission.SubmissionStatusTypeId,
                UploadedFileName = document.UploadedFileName,
                InternalFileName = document.InternalFileName,
                FileHash = document.FileHash,
                FileSize = document.FileSize,
                SagaUploadedFileCorrelationId = document.SagaUploadedFileCorrelationId,
                DocumentType = document.DocumentTypeId,
                DocumentTypeDescription = document.DocumentTypeDescription,
                DocumentStatusId = document.DocumentStatusId,
                DocumentStatusTypeId = document.DocumentStatusTypeId,
                DocumentStatusName = document.DocumentStatusName,
                DocumentStatusDescription = document.DocumentStatusDescription,
            })
            .Distinct()
            .ToListAsync(cancellationToken);

    /// <summary>The current dynamic user journey rows for a submission. Was usp_Read_DynamicUserJourney.</summary>
    public Task<List<DynamicUserJourney>> ReadDynamicUserJourneyAsync(string schemeValuationSubmissionId, CancellationToken cancellationToken = default)
        => db.DynamicUserJourneys
            .AsNoTracking()
            .Where(j => j.EndEventReference == null && j.ValuationSubmission.SchemeValuationSubmissionId == schemeValuationSubmissionId)
            .ToListAsync(cancellationToken);

    /// <summary>
    /// The submission behind a user-saved submission that is still open, or null when it does not exist or has been closed.
    /// Was usp_Read_IsUserSubmissionInProgress.
    /// </summary>
    public Task<UserSubmissionInProgressResult?> ReadIsUserSubmissionInProgressAsync(int userSavedSubmissionId, CancellationToken cancellationToken = default)
        => db.UserSavedSubmissions
            .Where(u => u.UserSavedSubmissionId == userSavedSubmissionId && u.EndEventReference == null)
            .Select(u => new UserSubmissionInProgressResult
            {
                SchemeValuationSubmissionId = u.ValuationSubmission.SchemeValuationSubmissionId,
                EffectiveDate = u.ValuationSubmission.EffectiveDate,
            })
            .FirstOrDefaultAsync(cancellationToken);

    /// <summary>
    /// Whether the scheme has an open user-saved submission whose current status is In Progress.
    /// Was usp_Read_PsrHasUserSubmissionInProgress.
    /// </summary>
    public Task<bool> ReadPsrHasUserSubmissionInProgressAsync(int psrNumber, CancellationToken cancellationToken = default)
    {
        if (psrNumber == 0)
        {
            return Task.FromResult(false);
        }

        return db.UserSavedSubmissions.AnyAsync(
            u => u.EndEventReference == null
                && u.ValuationSubmission.ValuationScheme.PSRNumber == psrNumber
                && u.ValuationSubmission.ValuationSubmissionStatuses.Any(s =>
                    s.EndEventReference == null && s.SubmissionStatusTypeId == SubmissionStatusTypeIds.InProgress),
            cancellationToken);
    }

    /// <summary>Submission details, optionally only when the submission has the given status. Was usp_Read_Submission.</summary>
    public Task<List<SubmissionResult>> ReadSubmissionAsync(string schemeValuationSubmissionId, short? submissionStatusTypeId = null, CancellationToken cancellationToken = default)
        => db.SchemeValuationSubmissionsView
            .Where(s => s.SchemeValuationSubmissionId == schemeValuationSubmissionId
                && (submissionStatusTypeId == null || s.SubmissionStatusTypeId == submissionStatusTypeId))
            .Select(s => new SubmissionResult
            {
                SchemeValuationSubmissionId = s.SchemeValuationSubmissionId,
                ValuationSubmissionId = s.ValuationSubmissionId,
                SchemeName = s.SchemeName,
                SubmissionStatusTypeId = s.SubmissionStatusTypeId,
                EffectiveDate = s.EffectiveDate,
                DateFundingAndInvestmentStrategyWasFinalised = s.DateFundingAndInvestmentStrategyWasFinalised,
                DateStatementOfStrategyWasSigned = s.DateStatementOfStrategyWasSigned,
                CreateDateTime = s.CreateDateTime,
                IsExcludedSubmission = s.IsExcludedSubmission,
                SubmittedDateTime = s.SubmittedDateTime,
                UserId = s.UserId,
            })
            .ToListAsync(cancellationToken);

    /// <summary>
    /// Key data for a submission in Submitted status, used when the Statement of Strategy is sent for publishing.
    /// Throws <see cref="SchemeValuationDataException"/> when the submission is missing or not in Submitted status.
    /// Was usp_Read_SubmittedSubmission.
    /// </summary>
    public async Task<SubmittedSubmissionResult> ReadSubmittedSubmissionAsync(string schemeValuationSubmissionId, CancellationToken cancellationToken = default)
    {
        var submission = await db.SchemeValuationSubmissionsView
            .Where(s => s.SchemeValuationSubmissionId == schemeValuationSubmissionId)
            .Select(s => new
            {
                s.ValuationSubmissionId,
                s.SubmissionStatusTypeId,
                s.EffectiveDate,
                s.DateFundingAndInvestmentStrategyWasFinalised,
                s.DateStatementOfStrategyWasSigned,
                DateSubmitted = s.SubmittedDateTime ?? s.CreateDateTime, // old submissions have no SubmittedDateTime
            })
            .FirstOrDefaultAsync(cancellationToken);

        switch (submission?.SubmissionStatusTypeId)
        {
            case null:
                throw new SchemeValuationDataException($"Cannot find \"{schemeValuationSubmissionId}\" status.");
            case SubmissionStatusTypeIds.Cancelled:
                throw new SchemeValuationDataException($"Scheme Cancelled \"{schemeValuationSubmissionId}\".");
            case SubmissionStatusTypeIds.InProgress:
                throw new SchemeValuationDataException($"Scheme not submitted \"{schemeValuationSubmissionId}\".");
            case SubmissionStatusTypeIds.Superseded:
                throw new SchemeValuationDataException($"Scheme superseded \"{schemeValuationSubmissionId}\".");
        }

        return new SubmittedSubmissionResult
        {
            SchemeValuationSubmissionId = schemeValuationSubmissionId,
            ValuationSubmissionId = submission.ValuationSubmissionId,
            SubmissionStatusTypeId = submission.SubmissionStatusTypeId.Value,
            EffectiveDate = submission.EffectiveDate,
            DateFundingAndInvestmentStrategyWasFinalised = submission.DateFundingAndInvestmentStrategyWasFinalised,
            DateStatementOfStrategyWasSigned = submission.DateStatementOfStrategyWasSigned,
            DateSubmitted = submission.DateSubmitted,
        };
    }

    /// <summary>
    /// In-progress user-saved submissions for a scheme, with their related submission data, newest first.
    /// Was usp_Read_UserSavedAndValuationSubmission.
    /// </summary>
    public Task<List<UserSavedSubmissionCurrentView>> ReadUserSavedAndValuationSubmissionAsync(int psrNumber, CancellationToken cancellationToken = default)
        => db.UserSavedSubmissionsCurrent
            .Where(u => u.PSRNumber == psrNumber && u.SubmissionStatusTypeId == SubmissionStatusTypeIds.InProgress)
            .OrderByDescending(u => u.UserSavedSubmissionId)
            .ToListAsync(cancellationToken);

    /// <summary>Open user-saved submissions for a scheme, most recently updated first. Was usp_Read_UserSavedSubmission.</summary>
    public Task<List<UserSavedSubmissionResult>> ReadUserSavedSubmissionAsync(int psrNumber, CancellationToken cancellationToken = default)
        => (from saved in db.UserSavedSubmissions
            where saved.EndEventReference == null
            let submission = saved.ValuationSubmission
            where submission.EndEventReference == null && submission.ValuationScheme.PSRNumber == psrNumber
            from status in submission.ValuationSubmissionStatuses.Where(s => s.EndEventReference == null)
            from valuationCase in submission.ValuationCases.Where(c => c.EndEventReference == null).DefaultIfEmpty()
            orderby saved.LastUpdated descending
            select new UserSavedSubmissionResult
            {
                UserSavedSubmissionId = saved.UserSavedSubmissionId,
                PSRNumber = submission.ValuationScheme.PSRNumber,
                SchemeValuationSubmissionId = submission.SchemeValuationSubmissionId,
                EffectiveDate = submission.EffectiveDate,
                LastActionPageId = saved.LastActionPageId,
                LastPageData = saved.LastPageData,
                LastUpdated = saved.LastUpdated,
                SubmissionStatusTypeId = status.SubmissionStatusTypeId,
                SubmissionStatusDescription = status.SubmissionStatusType.SubmissionStatusDescription,
                CaseReference = valuationCase.CaseReference,
            })
            .ToListAsync(cancellationToken);

    /// <summary>
    /// The ValuationSubmissionId (current or end-dated) for a SchemeValuationSubmissionId.
    /// Throws <see cref="SchemeValuationDataException"/> when there is none. Was usp_Read_ValuationSubmissionId.
    /// </summary>
    public async Task<int> ReadValuationSubmissionIdAsync(string? schemeValuationSubmissionId, CancellationToken cancellationToken = default)
    {
        var id = await db.ValuationSubmissions
            .Where(v => v.SchemeValuationSubmissionId == schemeValuationSubmissionId)
            .Select(v => (int?)v.ValuationSubmissionId)
            .FirstOrDefaultAsync(cancellationToken);

        return id ?? throw new SchemeValuationDataException(
            $"@SchemeValuationSubmissionId:{schemeValuationSubmissionId ?? "NULL"} is not a valid SchemeValuationSubmissionId ");
    }

    /// <summary>
    /// Daily report: every event created on <paramref name="createdDate"/>, and the submissions and documents
    /// whose rows were started or ended by one of those events. Was usp_Report_Recent_Submissions_By_Date.
    /// </summary>
    public async Task<RecentSubmissionsReport> ReportRecentSubmissionsByDateAsync(DateOnly createdDate, CancellationToken cancellationToken = default)
    {
        var from = createdDate.ToDateTime(TimeOnly.MinValue);
        var to = from.AddDays(1);
        var recentEventReferences = db.Events
            .Where(e => e.CreateDateTime >= from && e.CreateDateTime < to)
            .Select(e => e.EventReference);

        var events = await db.Events
            .Where(e => e.CreateDateTime >= from && e.CreateDateTime < to)
            .OrderBy(e => e.CreateDateTime)
            .Select(e => new RecentEventRow
            {
                EventType = e.EventType.EventTypeDescription,
                EventSource = e.EventSourceType.EventSourceDescription,
                EventReference = e.EventReference,
                SchemeValuationSubmissionId = e.SchemeValuationSubmissionId,
                UserId = e.UserId,
                CreateDateTime = e.CreateDateTime,
                NotificationDate = e.NotificationDate,
            })
            .ToListAsync(cancellationToken);

        var submissions = await (
            from scheme in db.ValuationSchemes
            from submission in scheme.ValuationSubmissions
            from dates in submission.ValuationSubmissionConfirmationDates.DefaultIfEmpty()
            from status in submission.ValuationSubmissionStatuses.DefaultIfEmpty()
            from statusType in db.SubmissionStatusTypes.Where(t => t.SubmissionStatusTypeId == status.SubmissionStatusTypeId).DefaultIfEmpty()
            where recentEventReferences.Any(r =>
                r == scheme.StartEventReference || r == scheme.EndEventReference
                || r == submission.StartEventReference || r == submission.EndEventReference
                || r == (int?)dates.StartEventReference || r == dates.EndEventReference
                || r == (int?)status.StartEventReference || r == status.EndEventReference)
            select new RecentSubmissionRow
            {
                PSRNumber = scheme.PSRNumber,
                SchemeName = scheme.SchemeName,
                SchemeStartEvent = scheme.StartEventReference,
                SchemeEndEvent = scheme.EndEventReference,
                SchemeValuationSubmissionId = submission.SchemeValuationSubmissionId,
                SubmissionEffectiveDate = submission.EffectiveDate,
                SubmissionStartEvent = submission.StartEventReference,
                SubmissionEndEvent = submission.EndEventReference,
                DateFundingAndInvestmentStrategyWasFinalised = (DateOnly?)dates.DateFundingAndInvestmentStrategyWasFinalised,
                DateStatementOfStrategyWasSigned = (DateOnly?)dates.DateStatementOfStrategyWasSigned,
                ConfirmationDatesStartEvent = (int?)dates.StartEventReference,
                ConfirmationDatesEndEvent = dates.EndEventReference,
                SubmissionStatusStartEvent = (int?)status.StartEventReference,
                SubmissionStatusEndEvent = status.EndEventReference,
                SubmissionStatusName = statusType.SubmissionStatusName,
                SubmissionStatusDescription = statusType.SubmissionStatusDescription,
                IsActive = (bool?)statusType.IsActive,
            })
            .ToListAsync(cancellationToken);

        var documents = await (
            from document in db.Documents
            from documentType in db.DocumentTypes.Where(t => t.DocumentTypeId == document.DocumentTypeId).DefaultIfEmpty()
            from status in document.DocumentStatuses.DefaultIfEmpty()
            from statusType in db.DocumentStatusTypes.Where(t => t.DocumentStatusTypeId == status.DocumentStatusTypeId).DefaultIfEmpty()
            from data in document.ValuationSubmissionData.DefaultIfEmpty()
            where recentEventReferences.Any(r =>
                r == document.StartEventReference || r == document.EndEventReference
                || r == (int?)status.StartEventReference || r == status.EndEventReference
                || r == (int?)data.StartEventReference || r == data.EndEventReference)
            select new RecentDocumentRow
            {
                UploadedFileName = document.UploadedFileName,
                InternalFileName = document.InternalFileName,
                FileHash = document.FileHash,
                StartEventReference = document.StartEventReference,
                EndEventReference = document.EndEventReference,
                DocumentTypeName = documentType.DocumentTypeName,
                DocumentTypeDescription = documentType.DocumentTypeDescription,
                DocumentTypeIsActive = (bool?)documentType.IsActive,
                DocumentStatusName = statusType.DocumentStatusName,
                DocumentStatusDescription = statusType.DocumentStatusDescription,
                DocumentStatusIsActive = (bool?)statusType.IsActive,
            })
            .ToListAsync(cancellationToken);

        return new RecentSubmissionsReport { Events = events, Submissions = submissions, Documents = documents };
    }
}
