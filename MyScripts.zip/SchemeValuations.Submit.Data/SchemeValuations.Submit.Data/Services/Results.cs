namespace SchemeValuations.Submit.Data.Services;

// Result shapes returned by SchemeValuationQueries. Property names match the columns
// the original stored procedures returned.

/// <summary>A case reference for a submission (was usp_Read_CaseReferenceData).</summary>
public class CaseReferenceDataResult
{
    public int ValuationCaseId { get; set; }
    public int ValuationSchemeId { get; set; }
    public int PSRNumber { get; set; }
    public string SchemeName { get; set; } = null!;
    public int ValuationSubmissionId { get; set; }
    public string CaseReference { get; set; } = null!;
    public string SchemeValuationSubmissionId { get; set; } = null!;
    public DateOnly EffectiveDate { get; set; }
}

/// <summary>A current document with its submission and status (was usp_Read_DocumentMetadata).</summary>
public record DocumentMetadataResult
{
    public int ValuationSchemeId { get; init; }
    public int PSRNumber { get; init; }
    public int ValuationSubmissionId { get; init; }
    public string SchemeValuationSubmissionId { get; init; } = null!;
    public int? ValuationSubmissionStatusId { get; init; }
    public short? SubmissionStatusTypeId { get; init; }
    public string UploadedFileName { get; init; } = null!;
    public string InternalFileName { get; init; } = null!;
    public string FileHash { get; init; } = null!;
    public long? FileSize { get; init; }
    public Guid SagaUploadedFileCorrelationId { get; init; }
    public short DocumentType { get; init; }
    public string DocumentTypeDescription { get; init; } = null!;
    public int? DocumentStatusId { get; init; }
    public short? DocumentStatusTypeId { get; init; }
    public string? DocumentStatusName { get; init; }
    public string? DocumentStatusDescription { get; init; }
}

/// <summary>The submission behind an open user-saved submission (was usp_Read_IsUserSubmissionInProgress).</summary>
public class UserSubmissionInProgressResult
{
    public string SchemeValuationSubmissionId { get; set; } = null!;
    public DateOnly EffectiveDate { get; set; }
}

/// <summary>Submission details (was usp_Read_Submission).</summary>
public class SubmissionResult
{
    public string SchemeValuationSubmissionId { get; set; } = null!;
    public int ValuationSubmissionId { get; set; }
    public string SchemeName { get; set; } = null!;
    public short? SubmissionStatusTypeId { get; set; }
    public DateOnly EffectiveDate { get; set; }
    public DateOnly? DateFundingAndInvestmentStrategyWasFinalised { get; set; }
    public DateOnly? DateStatementOfStrategyWasSigned { get; set; }
    public DateTime CreateDateTime { get; set; }
    public bool IsExcludedSubmission { get; set; }
    public DateTime? SubmittedDateTime { get; set; }
    public string UserId { get; set; } = null!;
}

/// <summary>Key data for a submitted submission (was usp_Read_SubmittedSubmission).</summary>
public class SubmittedSubmissionResult
{
    public string SchemeValuationSubmissionId { get; set; } = null!;
    public int ValuationSubmissionId { get; set; }
    public short SubmissionStatusTypeId { get; set; }
    public DateOnly EffectiveDate { get; set; }
    public DateOnly? DateFundingAndInvestmentStrategyWasFinalised { get; set; }
    public DateOnly? DateStatementOfStrategyWasSigned { get; set; }

    /// <summary>The submitted date/time, or the creation date/time for old submissions that have none.</summary>
    public DateTime DateSubmitted { get; set; }
}

/// <summary>An open user-saved submission (was usp_Read_UserSavedSubmission).</summary>
public class UserSavedSubmissionResult
{
    public int UserSavedSubmissionId { get; set; }
    public int PSRNumber { get; set; }
    public string SchemeValuationSubmissionId { get; set; } = null!;
    public DateOnly EffectiveDate { get; set; }
    public Guid LastActionPageId { get; set; }
    public string LastPageData { get; set; } = null!;
    public DateTime LastUpdated { get; set; }
    public short SubmissionStatusTypeId { get; set; }
    public string SubmissionStatusDescription { get; set; } = null!;
    public string? CaseReference { get; set; }
}

/// <summary>Everything touched on a given date (was usp_Report_Recent_Submissions_By_Date).</summary>
public class RecentSubmissionsReport
{
    public List<RecentEventRow> Events { get; init; } = [];
    public List<RecentSubmissionRow> Submissions { get; init; } = [];
    public List<RecentDocumentRow> Documents { get; init; } = [];
}

public class RecentEventRow
{
    public string EventType { get; set; } = null!;
    public string EventSource { get; set; } = null!;
    public int EventReference { get; set; }
    public string? SchemeValuationSubmissionId { get; set; }
    public string UserId { get; set; } = null!;
    public DateTime CreateDateTime { get; set; }
    public DateTime? NotificationDate { get; set; }
}

public class RecentSubmissionRow
{
    public int PSRNumber { get; set; }
    public string SchemeName { get; set; } = null!;
    public int SchemeStartEvent { get; set; }
    public int? SchemeEndEvent { get; set; }
    public string SchemeValuationSubmissionId { get; set; } = null!;
    public DateOnly SubmissionEffectiveDate { get; set; }
    public int SubmissionStartEvent { get; set; }
    public int? SubmissionEndEvent { get; set; }
    public DateOnly? DateFundingAndInvestmentStrategyWasFinalised { get; set; }
    public DateOnly? DateStatementOfStrategyWasSigned { get; set; }
    public int? ConfirmationDatesStartEvent { get; set; }
    public int? ConfirmationDatesEndEvent { get; set; }
    public int? SubmissionStatusStartEvent { get; set; }
    public int? SubmissionStatusEndEvent { get; set; }
    public string? SubmissionStatusName { get; set; }
    public string? SubmissionStatusDescription { get; set; }
    public bool? IsActive { get; set; }
}

public class RecentDocumentRow
{
    public string UploadedFileName { get; set; } = null!;
    public string InternalFileName { get; set; } = null!;
    public string FileHash { get; set; } = null!;
    public int StartEventReference { get; set; }
    public int? EndEventReference { get; set; }
    public string? DocumentTypeName { get; set; }
    public string? DocumentTypeDescription { get; set; }
    public bool? DocumentTypeIsActive { get; set; }
    public string? DocumentStatusName { get; set; }
    public string? DocumentStatusDescription { get; set; }
    public bool? DocumentStatusIsActive { get; set; }
}
