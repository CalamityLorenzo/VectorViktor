using SchemeValuations.Submit.Data.Tests.Infrastructure;
using static SchemeValuations.Submit.Data.Tests.Given;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>
/// The intentional behaviour changes listed under "Behaviour changes from the stored procedures" in the
/// SchemeValuations.Submit.Data README. Each test shows the old and new behaviour side by side, and shows that
/// apart from the documented step or table, both runs are still identical.
/// </summary>
[Collection(nameof(ParityCollection))]
public class DocumentedDifferenceTests(ParityFixture fixture)
{
    /// <summary>
    /// README: "WriteValuationSubmissionDataAsync fixes a data-loss bug. When a document already had extracted data,
    /// the procedure end-dated that row but never inserted the new one, so re-extracting a document left it with no
    /// current data. The new code always inserts the new data."
    /// </summary>
    [Fact]
    public async Task Re_extracting_a_document_keeps_its_data_only_in_EF_Core()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            var documentId = await api.StatementOfStrategy(t, Svs1);
            await t.Step("extract", () => api.WriteValuationSubmissionData("{\"version\":1}", documentId, User, Svs1, Source));
            await t.Step("re-extract", () => api.WriteValuationSubmissionData("{\"version\":2}", documentId, User, Svs1, Source));
        });

        // Everything else, including the "re-extract" Event row, is the same.
        result.AssertIdenticalExcept(steps: ["re-extract"], tables: ["dbo.ValuationSubmissionData"]);

        // The procedure returns the id of the row it has just end-dated, and inserts nothing.
        Assert.Equal("1", result.Legacy["re-extract"]);
        var legacyRow = Assert.Single(result.LegacyDatabase.Tables["dbo.ValuationSubmissionData"].Records());
        Assert.Equal("{\"version\":1}", legacyRow["QuestionsAndResponses"]);
        Assert.Equal(4L, legacyRow["EndEventReference"]); // end-dated by the re-extract event: the document has no current data

        // The service end-dates the old row and inserts the new data as the current row.
        Assert.Equal("2", result.EfCore["re-extract"]);
        var efCoreRows = result.EfCoreDatabase.Tables["dbo.ValuationSubmissionData"].Records().OrderBy(r => r["ValuationSubmissionDataId"]).ToList();
        Assert.Equal(2, efCoreRows.Count);
        Assert.Equal("{\"version\":1}", efCoreRows[0]["QuestionsAndResponses"]);
        Assert.Equal(4L, efCoreRows[0]["EndEventReference"]);
        Assert.Equal("{\"version\":2}", efCoreRows[1]["QuestionsAndResponses"]);
        Assert.Equal(4L, efCoreRows[1]["StartEventReference"]);
        Assert.Null(efCoreRows[1]["EndEventReference"]);
    }

    /// <summary>
    /// README: "ReadSubmittedSubmissionAsync now throws when the submission is not in Submitted status. The procedure's
    /// status checks could never fire, so for an in-progress, cancelled, superseded or unknown submission it returned a
    /// row of nulls. The new code throws SchemeValuationDataException, using the procedure's intended messages."
    /// </summary>
    [Fact]
    public async Task Reading_a_submission_that_is_not_submitted_throws_only_in_EF_Core()
    {
        const string cancelled = "SCHEMEVALUATION-10000835-20260331-0001";
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.Submitted(t, Svs1);
            await api.Submission(t, Svs2); // Svs1 superseded, Svs2 in progress
            await api.Submission(t, cancelled, effectiveDate: new DateOnly(2026, 3, 31));
            await t.Step("cancel", () => api.WriteValuationSubmissionStatus(cancelled, SubmissionStatusTypeIds.Cancelled, User, Source, EventTypeIds.UserChangedSubmissionStatus));

            await t.Step("in progress", () => api.ReadSubmittedSubmission(Svs2));
            await t.Step("cancelled", () => api.ReadSubmittedSubmission(cancelled));
            await t.Step("superseded", () => api.ReadSubmittedSubmission(Svs1));
            await t.Step("unknown", () => api.ReadSubmittedSubmission(Unknown));
        });

        string[] differing = ["in progress", "cancelled", "superseded", "unknown"];
        result.AssertIdenticalExcept(steps: differing, tables: []);

        // The procedure returns one row: the id it was given, status 2 (Submitted) and nulls.
        foreach (var (step, svsId) in differing.Zip([Svs2, cancelled, Svs1, Unknown]))
        {
            Assert.EndsWith($"'{svsId}', NULL, 2, NULL, NULL, NULL, NULL", result.Legacy[step]);
        }

        Assert.Equal($"ERROR Scheme not submitted \"{Svs2}\".", result.EfCore["in progress"]);
        Assert.Equal($"ERROR Scheme Cancelled \"{cancelled}\".", result.EfCore["cancelled"]);
        Assert.Equal($"ERROR Scheme superseded \"{Svs1}\".", result.EfCore["superseded"]);
        Assert.Equal($"ERROR Cannot find \"{Unknown}\" status.", result.EfCore["unknown"]);
    }

    /// <summary>
    /// README (also listed): "User ids are no longer truncated. The procedures declared @UserId VARCHAR(50), which
    /// silently cut longer ids to 50 characters even though Event.UserId is varchar(300)."
    /// </summary>
    [Fact]
    public async Task User_ids_longer_than_50_characters_are_truncated_only_by_the_procedures()
    {
        var longUserId = new string('u', 40) + "@example.com"; // 52 characters
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await t.Step("event", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, longUserId, Source));
        });

        result.AssertIdenticalExcept(steps: [], tables: ["dbo.Event"]);
        Assert.Equal(longUserId[..50], Assert.Single(result.LegacyDatabase.Tables["dbo.Event"].Records())["UserId"]);
        Assert.Equal(longUserId, Assert.Single(result.EfCoreDatabase.Tables["dbo.Event"].Records())["UserId"]);
    }
}
