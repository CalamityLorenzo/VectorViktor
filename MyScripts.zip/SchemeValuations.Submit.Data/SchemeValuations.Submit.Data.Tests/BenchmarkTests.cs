using System.Diagnostics;
using System.Globalization;
using System.Text;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SchemeValuations.Submit.Data.Tests.Infrastructure;
using Xunit.Abstractions;
using static SchemeValuations.Submit.Data.Tests.Given;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>
/// Side-by-side timings and server round trips for each operation, stored procedure versus EF Core.
/// Opt-in, as it takes a while: set SCHEMEVALUATION_BENCHMARK=1, then run
/// <c>dotnet test -c Release --filter Category=Benchmark --logger "console;verbosity=detailed"</c>.
/// The table is also written to benchmark-results.md in the test output folder.
/// </summary>
[Collection(nameof(ParityCollection))]
public class BenchmarkTests(ParityFixture fixture, ITestOutputHelper output)
{
    private const int WarmupJourneys = 20;
    private const int MeasuredJourneys = 200;

    // Round trips are priced at this latency in the "projected" columns, as a typical figure for an app and
    // database in the same cloud region. LocalDB round trips are almost free, so the measured times understate
    // the cost of extra round trips over a network.
    private const double ProjectedLatencyMs = 1.0;

    [Fact]
    [Trait("Category", "Benchmark")]
    public async Task Stored_procedures_versus_EF_Core()
    {
        if (Environment.GetEnvironmentVariable("SCHEMEVALUATION_BENCHMARK") != "1")
        {
            output.WriteLine("Skipped: set SCHEMEVALUATION_BENCHMARK=1 to run the benchmark.");
            return;
        }

        await fixture.ResetAsync();

        long legacyRoundTrips = 0;
        var legacy = new OperationTimer(() => legacyRoundTrips = 0, () => legacyRoundTrips);
        var legacyApi = new StoredProcedureApi(fixture.LegacyConnectionString, n => legacyRoundTrips += n);

        await using var db = DatabaseBuilder.CreateContext(fixture.EfCoreConnectionString);
        var efConnection = (SqlConnection)db.Database.GetDbConnection();
        efConnection.StatisticsEnabled = true;
        var efCore = new OperationTimer(efConnection.ResetStatistics, () => (long)efConnection.RetrieveStatistics()["ServerRoundtrips"]!);
        var efCoreApi = new EfCoreApi(db);

        // Alternate between the two so that both see the same conditions (caches, disk, other load) over the run.
        for (var journey = 0; journey < WarmupJourneys + MeasuredJourneys; journey++)
        {
            legacy.Recording = efCore.Recording = journey >= WarmupJourneys;
            await RunJourneyAsync(legacyApi, legacy, journey);
            await RunJourneyAsync(efCoreApi, efCore, journey);
        }

        var report = Report(legacy, efCore);
        output.WriteLine(report);
        await File.WriteAllTextAsync(Path.Combine(AppContext.BaseDirectory, "benchmark-results.md"), report);
    }

    /// <summary>One submission's journey, on its own PSR, touching every procedure along the way.</summary>
    private static async Task RunJourneyAsync(ISchemeValuationApi api, OperationTimer time, int journey)
    {
        var psr = 30000000 + journey;
        var svsId = $"SCHEMEVALUATION-{psr}-20250331-BENCH";
        var submitted = SubmittedAt.AddMinutes(journey);

        await time.Run("WriteValuationSubmission", () => api.WriteValuationSubmission(svsId, psr, $"Scheme {psr}", EffectiveDate, User, Source));
        await time.Run("WriteDynamicUserJourney", () => api.WriteDynamicUserJourney(svsId, 1, 1, 1, User, Source));
        await time.Run("WriteValuationSubmissionGuardQuestionAnswer", () => api.WriteValuationSubmissionGuardQuestionAnswer(svsId, 1, User, Source, EventTypeIds.SchemeInDeficitGuardQuestionAnswered));
        var documentId = await time.Run("WriteDocument (new)", () => WriteSos(api, svsId));
        await time.Run("WriteDocument (unchanged repeat)", () => WriteSos(api, svsId));
        await time.Run("WriteDocumentStatus", () => api.WriteDocumentStatus(svsId, DocumentStatusTypeIds.VirusScanFailed, documentId, userId: User,
            eventSourceType: Source, eventTypeId: EventTypeIds.StatementOfStrategyUploaded));
        await time.Run("WriteValuationSubmissionData", () => api.WriteValuationSubmissionData("{\"q1\":\"yes\"}", documentId, User, svsId, Source));
        await time.Run("WriteValuationSubmissionConfirmationDates", () => api.WriteValuationSubmissionConfirmationDates(svsId, new DateOnly(2025, 4, 1), new DateOnly(2025, 4, 2), User, Source));
        await time.Run("WriteUserSavedSubmission", () => api.WriteUserSavedSubmission(svsId, User, Source, Page, "{\"step\":1}", submitted));
        await time.Run("ReadUserSavedSubmission", () => api.ReadUserSavedSubmission(psr));
        await time.Run("ReadUserSavedAndValuationSubmission", () => api.ReadUserSavedAndValuationSubmission(psr));
        await time.Run("ReadPsrHasUserSubmissionInProgress", () => api.ReadPsrHasUserSubmissionInProgress(psr));
        await time.Run("ReadDocumentMetadata", () => api.ReadDocumentMetadata(svsId));
        await time.Run("ReadDynamicUserJourney", () => api.ReadDynamicUserJourney(svsId));
        await time.Run("WriteValuationSubmittedDetail", () => api.WriteValuationSubmittedDetail(svsId, submitted, User, Source));
        await time.Run("WriteValuationCase", () => api.WriteValuationCase(svsId, $"CAS-{psr}", User, EventTypeIds.CaseReferenceReceived, Source));
        await time.Run("ReadSubmission", () => api.ReadSubmission(svsId));
        await time.Run("ReadSubmittedSubmission", () => api.ReadSubmittedSubmission(svsId));
        await time.Run("ReadCaseReferenceData", () => api.ReadCaseReferenceData(svsId));
        await time.Run("ReadValuationSubmissionId", () => api.ReadValuationSubmissionId(svsId));
        await time.Run("WriteCancelDocument", () => api.WriteCancelDocument(svsId, DocumentTypeIds.StatementOfStrategy, User));
        await time.Run("CreateEventById", () => api.CreateEventById(EventTypeIds.SpecialUpdate, svsId, User, Source));
    }

    private static Task<int> WriteSos(ISchemeValuationApi api, string svsId)
        => api.WriteDocument(svsId, User, Source, EventTypeIds.StatementOfStrategyUploaded, "sos.xlsx", "internal/sos.xlsx", "hash-sos",
            2048, Saga1, DocumentTypeIds.StatementOfStrategy, DocumentStatusTypeIds.VirusScanSuccessful);

    private static string Report(OperationTimer legacy, OperationTimer efCore)
    {
        static string Ms(double value) => value.ToString("0.00", CultureInfo.InvariantCulture);
        static string Trips(double value) => value.ToString("0.#", CultureInfo.InvariantCulture);

        var builder = new StringBuilder()
            .AppendLine($"# Stored procedures vs EF Core ({MeasuredJourneys} journeys after {WarmupJourneys} warm-up, {DateTime.Now:yyyy-MM-dd HH:mm})")
            .AppendLine()
            .AppendLine($"Times are medians in ms on this machine. \"Projected\" adds {ProjectedLatencyMs} ms per round trip, to approximate a networked database.")
            .AppendLine()
            .AppendLine("| Operation | SP ms | EF ms | EF / SP | SP round trips | EF round trips | Projected SP ms | Projected EF ms |")
            .AppendLine("|---|--:|--:|--:|--:|--:|--:|--:|");

        double totalLegacy = 0, totalEfCore = 0, totalLegacyTrips = 0, totalEfCoreTrips = 0;
        foreach (var name in legacy.Operations)
        {
            var (spMs, spTrips) = legacy.Summary(name);
            var (efMs, efTrips) = efCore.Summary(name);
            totalLegacy += spMs;
            totalEfCore += efMs;
            totalLegacyTrips += spTrips;
            totalEfCoreTrips += efTrips;
            builder.AppendLine($"| {name} | {Ms(spMs)} | {Ms(efMs)} | {efMs / spMs:0.0}x | {Trips(spTrips)} | {Trips(efTrips)} | " +
                $"{Ms(spMs + spTrips * ProjectedLatencyMs)} | {Ms(efMs + efTrips * ProjectedLatencyMs)} |");
        }

        builder.AppendLine($"| **Whole journey** | **{Ms(totalLegacy)}** | **{Ms(totalEfCore)}** | **{totalEfCore / totalLegacy:0.0}x** | " +
            $"**{Trips(totalLegacyTrips)}** | **{Trips(totalEfCoreTrips)}** | **{Ms(totalLegacy + totalLegacyTrips * ProjectedLatencyMs)}** | " +
            $"**{Ms(totalEfCore + totalEfCoreTrips * ProjectedLatencyMs)}** |");

        return builder.ToString();
    }

    /// <summary>Times each call and records the server round trips it made.</summary>
    private sealed class OperationTimer(Action resetRoundTrips, Func<long> readRoundTrips)
    {
        private readonly Dictionary<string, List<(double Ms, long RoundTrips)>> _samples = [];

        public List<string> Operations { get; } = [];

        public bool Recording { get; set; }

        public async Task<T> Run<T>(string operation, Func<Task<T>> call)
        {
            resetRoundTrips();
            var stopwatch = Stopwatch.StartNew();
            var result = await call();
            stopwatch.Stop();
            var roundTrips = readRoundTrips();

            if (Recording)
            {
                if (!_samples.TryGetValue(operation, out var samples))
                {
                    _samples[operation] = samples = [];
                    Operations.Add(operation);
                }

                samples.Add((stopwatch.Elapsed.TotalMilliseconds, roundTrips));
            }

            return result;
        }

        /// <summary>Median time, and mean round trips (which are the same on every call of a given operation).</summary>
        public (double MedianMs, double RoundTrips) Summary(string operation)
        {
            var samples = _samples[operation];
            var times = samples.Select(s => s.Ms).Order().ToList();
            var median = times.Count % 2 == 1 ? times[times.Count / 2] : (times[times.Count / 2 - 1] + times[times.Count / 2]) / 2;
            return (median, samples.Average(s => s.RoundTrips));
        }
    }
}
