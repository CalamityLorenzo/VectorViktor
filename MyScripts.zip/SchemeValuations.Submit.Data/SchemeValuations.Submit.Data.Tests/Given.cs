using SchemeValuations.Submit.Data.Tests.Infrastructure;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>Common inputs and setup steps shared by the scenarios. Every step is recorded in the transcript.</summary>
internal static class Given
{
    public const string User = "jane.doe@example.com";
    public const short Source = EventSourceTypeIds.SchemeValuationSubmission;
    public const int Psr = 10000835;
    public const string SchemeName = "Acme Pension Scheme";
    public const string Svs1 = "SCHEMEVALUATION-10000835-20250331-0001";
    public const string Svs2 = "SCHEMEVALUATION-10000835-20250331-0002";
    public const string Svs3 = "SCHEMEVALUATION-10000835-20250331-0003";
    public const string Unknown = "SCHEMEVALUATION-DOES-NOT-EXIST";

    public static readonly DateOnly EffectiveDate = new(2025, 3, 31);
    public static readonly DateTime SubmittedAt = new(2025, 6, 30, 14, 15, 16, 123);
    public static readonly Guid Saga1 = Guid.Parse("11111111-1111-1111-1111-111111111111");
    public static readonly Guid Saga2 = Guid.Parse("22222222-2222-2222-2222-222222222222");
    public static readonly Guid Page = Guid.Parse("33333333-3333-3333-3333-333333333333");

    public static Task<int> Submission(this ISchemeValuationApi api, Transcript t, string svsId, int psr = Psr, string schemeName = SchemeName, DateOnly? effectiveDate = null)
        => t.Step($"start {svsId}", () => api.WriteValuationSubmission(svsId, psr, schemeName, effectiveDate ?? EffectiveDate, User, Source));

    public static Task<int> Submitted(this ISchemeValuationApi api, Transcript t, string svsId)
        => t.Step($"submit {svsId}", () => api.WriteValuationSubmittedDetail(svsId, SubmittedAt, User, Source));

    public static Task<int> StatementOfStrategy(this ISchemeValuationApi api, Transcript t, string svsId, string fileName = "sos.xlsx", Guid? saga = null,
        short status = DocumentStatusTypeIds.VirusScanSuccessful)
        => t.Step($"upload {fileName} to {svsId} with status {status}", () => api.WriteDocument(svsId, User, Source, EventTypeIds.StatementOfStrategyUploaded,
            fileName, $"internal/{fileName}", $"hash-{fileName}", 2048, saga ?? Saga1, DocumentTypeIds.StatementOfStrategy, status));
}
