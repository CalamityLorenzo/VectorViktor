# SchemeValuations.Submit.Data.Tests

Parity tests that show the EF Core services behave the same as the original stored procedures in `myscripts`.

## How it works

At the start of a run, the fixture creates two databases on the same SQL Server instance:

| Database | Built from |
|---|---|
| `SchemeValuationParity_Legacy` | The original SSDT project. A dacpac is built in-process with DacFx from the `Build` items in the `.sqlproj`, and deployed. The project's pre- and post-deployment scripts then run, which load the reference data. |
| `SchemeValuationParity_EfCore` | The EF Core migrations. The database is created with the project's collation (`Latin1_General_CI_AS`) so that both databases compare strings the same way. |

Each test is a scenario, a sequence of calls written once against `ISchemeValuationApi`. For each scenario, the fixture does the following:

1. Empties both databases, keeping the reference data, and reseeds their identities.
2. Runs the scenario through `StoredProcedureApi` (ADO.NET calls to the procedures), then through `EfCoreApi` (`SchemeValuationCommands` and `SchemeValuationQueries`).
3. Compares the two runs:
   - **Every call:** the return value or result set, or the error message, must be the same. Result sets are compared column by column and row by row, in order where the procedure has an `ORDER BY`.
   - **Every table in both databases afterwards:** the rows must match, reference data and identity values included.

The only values that are masked are timestamps that the database clock fills in (`Event.CreateDateTime` and the view columns derived from it). Error messages are compared as text, because the procedures raise `SqlException` and the services raise `SchemeValuationDataException`.

## Tests

| Class | What it shows |
|---|---|
| `CommandParityTests` | Every write procedure: new rows, idempotent repeats, replacements, and error paths. |
| `QueryParityTests` | Every read procedure, over data in every submission status. |
| `EndToEndParityTests` | Whole journeys that use every procedure together. |
| `DocumentedDifferenceTests` | The behaviour changes listed in the main README: re-extracting a document (`WriteValuationSubmissionDataAsync`), reading a submission that is not in Submitted status (`ReadSubmittedSubmissionAsync`), and user ids longer than 50 characters. Each test asserts the old and the new behaviour, and that nothing else differs. |
| `UndocumentedDifferenceTests` | Two error paths where only the message differs: an inactive event type, and `WriteDocumentStatus` with an event type but no event source. |
| `BenchmarkTests` | Opt-in. Runs the same journey through both implementations and reports the median time and server round trips for each operation. See below. |

## Benchmark

```powershell
$env:SCHEMEVALUATION_BENCHMARK = "1"
dotnet test -c Release --filter Category=Benchmark --logger "console;verbosity=detailed"
```

The results table is also written to `bin/Release/net10.0/benchmark-results.md`. Round trips come from SqlClient's connection statistics, so the counts are real for both implementations.

LocalDB round trips cost almost nothing, so the table also shows projected times at 1 ms per round trip. That approximates an app talking to its database over a network. Without the environment variable, the test passes immediately without running.

## Running

```powershell
dotnet test
```

The tests need SQL Server. They use `(localdb)\MSSQLLocalDB` by default. To use another server, set `SCHEMEVALUATION_TEST_SERVER` to a server-level connection string. The two databases are dropped and recreated at the start of each run, and left in place afterwards so you can inspect them.
