using SchemeValuations.Submit.Data.Tests.Infrastructure;
using static SchemeValuations.Submit.Data.Tests.Given;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>Whole user journeys that use every procedure together, with reads in between, as the application would.</summary>
[Collection(nameof(ParityCollection))]
public class EndToEndParityTests(ParityFixture fixture)
{
    [Fact]
    public async Task Submit_resubmit_and_publish_a_valuation()
    {
        var today = DateOnly.FromDateTime(DateTime.Now);
        var result = await fixture.RunAsync(async (api, t) =>
        {
            // First submission: answers the guard question, uploads, saves progress, goes back and forward, submits.
            await api.Submission(t, Svs1);
            await t.Step("has in-progress save (none yet)", () => api.ReadPsrHasUserSubmissionInProgress(Psr));
            var saved = await t.Step("save 1", () => api.WriteUserSavedSubmission(Svs1, User, Source, Page, "{\"step\":\"guard\"}", new DateTime(2025, 5, 1, 9, 0, 0)));
            await t.Step("guard: deficit", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 1, User, Source, EventTypeIds.SchemeInDeficitGuardQuestionAnswered));
            await t.Step("journey", () => api.WriteDynamicUserJourney(Svs1, 1, 1, 1, User, Source));
            var sos = await api.StatementOfStrategy(t, Svs1);
            await t.Step("virus scan failed", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, sos, userId: User, eventSourceType: Source, eventTypeId: EventTypeIds.StatementOfStrategyUploaded));
            await t.Step("cancel SoS", () => api.WriteCancelDocument(Svs1, DocumentTypeIds.StatementOfStrategy, User));
            sos = await api.StatementOfStrategy(t, Svs1, fileName: "sos-fixed.xlsx", saga: Saga2);
            await api.StatementOfStrategy(t, Svs1, fileName: "sos-fixed.xlsx", saga: Saga2); // back, then next
            await t.Step("extract SoS", () => api.WriteValuationSubmissionData("{\"q1\":\"yes\"}", sos, User, Svs1, Source));
            await t.Step("actuarial valuation", () => api.WriteDocument(Svs1, User, Source, EventTypeIds.ActuarialValuationUploaded,
                "av.pdf", "internal/av.pdf", "hash-av", 10_485_760, Saga1, DocumentTypeIds.ActuarialValuation, DocumentStatusTypeIds.VirusScanSuccessful));
            await t.Step("guard: surplus", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 2, User, Source, EventTypeIds.SchemeInDeficitGuardQuestionAnswered));
            await t.Step("journey changed", () => api.WriteDynamicUserJourney(Svs1, 2, 2, 1, User, Source, isMultiDocUpload: true));
            await t.Step("dates", () => api.WriteValuationSubmissionConfirmationDates(Svs1, new DateOnly(2025, 4, 1), new DateOnly(2025, 4, 15), User, Source));
            await t.Step("save 2", () => api.WriteUserSavedSubmission(Svs1, User, Source, Page, "{\"step\":\"check\"}", new DateTime(2025, 5, 1, 10, 0, 0)));
            await t.Step("is save 1 in progress", () => api.ReadIsUserSubmissionInProgress(saved));
            await t.Step("is save 2 in progress", () => api.ReadIsUserSubmissionInProgress(saved + 1));
            await t.Step("has in-progress save", () => api.ReadPsrHasUserSubmissionInProgress(Psr));
            await t.Step("saved and valuation submission", () => api.ReadUserSavedAndValuationSubmission(Psr));
            await t.Step("saved submissions", () => api.ReadUserSavedSubmission(Psr));
            await t.Step("journey", () => api.ReadDynamicUserJourney(Svs1));
            await t.Step("documents", () => api.ReadDocumentMetadata(Svs1, SubmissionStatusTypeIds.InProgress));
            await api.Submitted(t, Svs1);

            // Case management and publishing.
            await t.Step("case", () => api.WriteValuationCase(Svs1, "CAS-10001", "crm-service", EventTypeIds.CaseReferenceReceived,
                EventSourceTypeIds.SchemeValuationSubmissionEventMessaging, new DateTime(2025, 7, 1, 8, 0, 0)));
            await t.Step("case again", () => api.WriteValuationCase(Svs1, "CAS-10001", "crm-service", EventTypeIds.CaseReferenceReceived,
                EventSourceTypeIds.SchemeValuationSubmissionEventMessaging, new DateTime(2025, 7, 1, 8, 5, 0)));
            await t.Step("submitted submission", () => api.ReadSubmittedSubmission(Svs1));
            await t.Step("case references", () => api.ReadCaseReferenceData(Svs1));
            await t.Step("has in-progress save after submit", () => api.ReadPsrHasUserSubmissionInProgress(Psr));

            // A resubmission for the same PSR and effective date supersedes it, under a renamed scheme.
            await api.Submission(t, Svs2, schemeName: "Acme Pension Scheme 2025");
            await t.Step("Svs2 id", () => api.ReadValuationSubmissionId(Svs2));
            await t.Step("submit superseded", () => api.WriteValuationSubmittedDetail(Svs1, SubmittedAt, User, Source));
            await t.Step("Svs2 SoS", () => api.WriteDocument(Svs2, User, Source, EventTypeIds.StatementOfStrategyUploaded,
                "sos-2.xlsx", "internal/sos-2.xlsx", "hash-sos-2", 4096, Saga1, DocumentTypeIds.StatementOfStrategy, DocumentStatusTypeIds.VirusScanSuccessful));
            await t.Step("Svs2 save", () => api.WriteUserSavedSubmission(Svs2, User, Source, Page, "{}", new DateTime(2025, 8, 1, 9, 0, 0)));
            await t.Step("Svs2 withdrawn", () => api.WriteValuationSubmissionStatus(Svs2, SubmissionStatusTypeIds.Cancelled, User, Source, EventTypeIds.UserChangedSubmissionStatus));
            await t.Step("submit cancelled", () => api.WriteValuationSubmittedDetail(Svs2, SubmittedAt, User, Source));

            // A third attempt: the cancelled one is not replaced again, as it is neither in progress nor submitted.
            await api.Submission(t, Svs3, schemeName: "Acme Pension Scheme 2025");
            await api.Submitted(t, Svs3);

            foreach (var svsId in new[] { Svs1, Svs2, Svs3 })
            {
                await t.Step($"read {svsId}", () => api.ReadSubmission(svsId));
                await t.Step($"documents {svsId}", () => api.ReadDocumentMetadata(svsId));
            }

            await t.Step("saved and valuation submission at end", () => api.ReadUserSavedAndValuationSubmission(Psr));
            await t.Step("saved submissions at end", () => api.ReadUserSavedSubmission(Psr));
            await t.Step("report", () => api.ReportRecentSubmissionsByDate(today));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task Many_schemes_and_submissions()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            for (var scheme = 1; scheme <= 5; scheme++)
            {
                var psr = 20000000 + scheme;
                for (var year = 2023; year <= 2025; year++)
                {
                    var svsId = $"SCHEMEVALUATION-{psr}-{year}0331-{scheme:0000}";
                    await api.Submission(t, svsId, psr: psr, schemeName: year == 2025 && scheme % 2 == 0 ? $"Scheme {scheme} (renamed)" : $"Scheme {scheme}",
                        effectiveDate: new DateOnly(year, 3, 31));
                    await t.Step($"{svsId} save", () => api.WriteUserSavedSubmission(svsId, User, Source, Page, $"{{\"year\":{year}}}", new DateTime(year, 5, scheme, 9, 0, 0)));
                    await api.StatementOfStrategy(t, svsId, fileName: $"sos-{psr}-{year}.xlsx");
                    if (year < 2025 || scheme % 3 == 0)
                    {
                        await api.Submitted(t, svsId);
                    }
                }

                // Resubmit the 2024 valuation.
                await api.Submission(t, $"SCHEMEVALUATION-{psr}-20240331-R{scheme:000}", psr: psr, schemeName: $"Scheme {scheme}", effectiveDate: new DateOnly(2024, 3, 31));
                await t.Step($"{psr} in progress", () => api.ReadPsrHasUserSubmissionInProgress(psr));
                await t.Step($"{psr} saved", () => api.ReadUserSavedSubmission(psr));
                await t.Step($"{psr} saved and valuation", () => api.ReadUserSavedAndValuationSubmission(psr));
            }
        });

        result.AssertIdentical();
    }
}
