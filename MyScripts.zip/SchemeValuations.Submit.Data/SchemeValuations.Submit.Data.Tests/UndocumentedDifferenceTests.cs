using SchemeValuations.Submit.Data.Tests.Infrastructure;
using static SchemeValuations.Submit.Data.Tests.Given;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>
/// Differences found by these tests that the README does not list. In both, the call fails either way and the database is
/// left unchanged; only the error message differs. These tests pin down the current behaviour of each side.
/// </summary>
[Collection(nameof(ParityCollection))]
public class UndocumentedDifferenceTests(ParityFixture fixture)
{
    /// <summary>
    /// usp_Create_EventById inserts only when the event type is active, then fails on the row count. The service checks
    /// IsActive first and gives a clearer message. No seeded event type is inactive, so this needs arranging.
    /// </summary>
    [Fact]
    public async Task Inactive_event_type_fails_with_a_different_message()
    {
        var result = await fixture.RunAsync(
            async (api, t) => await t.Step("inactive", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, Source)),
            arrangeSql: $"UPDATE dbo.EventType SET IsActive = 0 WHERE EventTypeId = {EventTypeIds.SpecialUpdate}");

        result.AssertIdenticalExcept(steps: ["inactive"], tables: []);
        Assert.Equal("ERROR Insert to dbo.Event created 0 row(s) instead of 1", result.Legacy["inactive"]);
        Assert.Equal("ERROR EventTypeId 17 is not active, so no Event was created.", result.EfCore["inactive"]);
    }

    /// <summary>
    /// usp_Write_DocumentStatus passes a NULL @EventSourceType on to usp_Create_EventById, whose INSERT then fails on the
    /// NOT NULL column. The service checks for it up front.
    /// </summary>
    [Fact]
    public async Task WriteDocumentStatus_without_an_event_source_fails_with_a_different_message()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            var documentId = await api.StatementOfStrategy(t, Svs1);
            await t.Step("no event source", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, documentId,
                userId: User, eventTypeId: EventTypeIds.SpecialUpdate));
        });

        result.AssertIdenticalExcept(steps: ["no event source"], tables: []);
        Assert.Equal("ERROR Cannot insert the value NULL into column 'EventSourceTypeId', table '<database>.dbo.Event'; column does not allow nulls. INSERT fails.",
            result.Legacy["no event source"]);
        Assert.Equal("ERROR EventSourceType cannot be null when no EventReference is supplied.", result.EfCore["no event source"]);
    }
}
