using SchemeValuations.Submit.Data.Tests.Infrastructure;
using static SchemeValuations.Submit.Data.Tests.Given;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>
/// Each write procedure against its EF Core replacement. Every scenario is run once through the stored procedures and
/// once through <c>SchemeValuationCommands</c>; the return values, error messages and the final contents of every table
/// (identity values included) must be identical.
/// </summary>
[Collection(nameof(ParityCollection))]
public class CommandParityTests(ParityFixture fixture)
{
    private static readonly DateTime NotifiedAt = new(2025, 7, 1, 9, 30, 0, 500);

    [Fact]
    public async Task CreateEventById_creates_events()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            var valuationSubmissionId = await api.Submission(t, Svs1);
            await t.Step("minimal", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, Source));
            await t.Step("all optional values", () => api.CreateEventById(EventTypeIds.CaseReferenceReceived, Svs1, User,
                EventSourceTypeIds.SchemeValuationSubmissionEventMessaging, valuationSubmissionId, "message-123", NotifiedAt));
            await t.Step("svs id not in ValuationSubmission", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Unknown, User, Source));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task CreateEventById_rejects_invalid_input()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await t.Step("unknown event type", () => api.CreateEventById(99, Svs1, User, Source));
            await t.Step("null user", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, null, Source));
            await t.Step("empty user", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, "", Source));
            await t.Step("whitespace user", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, "   ", Source));
            await t.Step("null svs id", () => api.CreateEventById(EventTypeIds.SpecialUpdate, null, User, Source));
            await t.Step("empty svs id", () => api.CreateEventById(EventTypeIds.SpecialUpdate, "", User, Source));
            await t.Step("unknown event source", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, 99));
            await t.Step("unknown valuation submission", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, Source, valuationSubmissionId: 999));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmission_creates_schemes_and_submissions()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.Submission(t, "SCHEMEVALUATION-10000835-20260331-0001", effectiveDate: new DateOnly(2026, 3, 31));
            await api.Submission(t, "SCHEMEVALUATION-10000835-20270331-0001", schemeName: SchemeName.ToUpperInvariant(), effectiveDate: new DateOnly(2027, 3, 31));
            await api.Submission(t, "SCHEMEVALUATION-10000835-20280331-0001", schemeName: "Acme Pension Scheme (renamed)", effectiveDate: new DateOnly(2028, 3, 31));
            await api.Submission(t, "SCHEMEVALUATION-10000835-20290331-0001", effectiveDate: new DateOnly(2029, 3, 31));
            await api.Submission(t, "SCHEMEVALUATION-12345678-20250331-0001", psr: 12345678, schemeName: "Other Scheme");
            await t.Step("excluded submission", () => api.WriteValuationSubmission("SCHEMEVALUATION-99999999-20250331-0001", 99999999, "Test Scheme",
                EffectiveDate, User, Source, isExcludedSubmission: true));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmission_cancels_an_in_progress_submission_and_supersedes_a_submitted_one()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.Submission(t, Svs2); // Svs1 was In Progress: cancelled
            await api.Submitted(t, Svs2);
            await api.Submission(t, Svs3); // Svs2 was Submitted: superseded
            await api.Submission(t, "SCHEMEVALUATION-10000835-20250331-0004");
            await t.Step("read Svs1", () => api.ReadSubmission(Svs1));
            await t.Step("read Svs2", () => api.ReadSubmission(Svs2));
            await t.Step("read Svs3", () => api.ReadSubmission(Svs3));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmission_rejects_invalid_input()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("blank effective date", () => api.WriteValuationSubmission(Svs2, Psr, SchemeName, new DateOnly(1900, 1, 1), User, Source));
            await t.Step("duplicate svs id", () => api.WriteValuationSubmission(Svs1, Psr, SchemeName, new DateOnly(2026, 3, 31), User, Source));
            await t.Step("duplicate svs id, same PSR and date", () => api.WriteValuationSubmission(Svs1, Psr, SchemeName, EffectiveDate, User, Source));
            await t.Step("empty user", () => api.WriteValuationSubmission(Svs2, Psr, SchemeName, EffectiveDate, "", Source));
            await t.Step("unknown event source", () => api.WriteValuationSubmission(Svs2, Psr, SchemeName, EffectiveDate, User, 99));
            await t.Step("read Svs1", () => api.ReadSubmission(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationScheme_adds_versions_of_a_scheme()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            var eventReference = await t.Step("event", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, Source));
            await t.Step("new PSR", () => api.WriteValuationScheme(Psr, SchemeName, eventReference));
            await t.Step("same name", () => api.WriteValuationScheme(Psr, SchemeName, eventReference));
            await t.Step("same name, different case", () => api.WriteValuationScheme(Psr, SchemeName.ToLowerInvariant(), eventReference));
            await t.Step("renamed", () => api.WriteValuationScheme(Psr, "Acme Pension Scheme (renamed)", eventReference));
            await t.Step("renamed back", () => api.WriteValuationScheme(Psr, SchemeName, eventReference));
            await t.Step("another PSR", () => api.WriteValuationScheme(12345678, "Other Scheme", eventReference));
            await t.Step("unknown event reference", () => api.WriteValuationScheme(55555555, "Unknown Event Scheme", 999));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmissionStatus_changes_status()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("unchanged", () => api.WriteValuationSubmissionStatus(Svs1, SubmissionStatusTypeIds.InProgress, User, Source, EventTypeIds.UserChangedSubmissionStatus));
            await t.Step("new event", () => api.WriteValuationSubmissionStatus(Svs1, SubmissionStatusTypeIds.Submitted, User, Source, EventTypeIds.UserChangedSubmissionStatus));
            var eventReference = await t.Step("event", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, Source));
            await t.Step("existing event", () => api.WriteValuationSubmissionStatus(Svs1, SubmissionStatusTypeIds.Cancelled, User, currentEventReference: eventReference));
            await t.Step("read", () => api.ReadSubmission(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmissionStatus_rejects_invalid_input()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("unknown svs id", () => api.WriteValuationSubmissionStatus(Unknown, SubmissionStatusTypeIds.Cancelled, User, Source, EventTypeIds.UserChangedSubmissionStatus));
            await t.Step("unknown event reference", () => api.WriteValuationSubmissionStatus(Svs1, SubmissionStatusTypeIds.Cancelled, User, currentEventReference: 999));
            await t.Step("no event type or reference", () => api.WriteValuationSubmissionStatus(Svs1, SubmissionStatusTypeIds.Cancelled, User));
            await t.Step("unknown status type", () => api.WriteValuationSubmissionStatus(Svs1, 99, User, Source, EventTypeIds.UserChangedSubmissionStatus));
            await t.Step("read", () => api.ReadSubmission(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmittedDetail_submits()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.Submitted(t, Svs1);
            await t.Step("submit again", () => api.WriteValuationSubmittedDetail(Svs1, SubmittedAt.AddHours(1), User, Source));
            await t.Step("custom event type", () => api.WriteValuationSubmittedDetail(Svs1, SubmittedAt.AddHours(2), User, Source, EventTypeIds.SpecialUpdate));
            await t.Step("read", () => api.ReadSubmission(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmittedDetail_rejects_cancelled_superseded_and_unknown_submissions()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.Submitted(t, Svs1);
            await api.Submission(t, Svs2); // supersedes Svs1
            await t.Step("cancel Svs2", () => api.WriteValuationSubmissionStatus(Svs2, SubmissionStatusTypeIds.Cancelled, User, Source, EventTypeIds.UserChangedSubmissionStatus));
            await t.Step("submit superseded", () => api.WriteValuationSubmittedDetail(Svs1, SubmittedAt, User, Source));
            await t.Step("submit cancelled", () => api.WriteValuationSubmittedDetail(Svs2, SubmittedAt, User, Source));
            await t.Step("submit unknown", () => api.WriteValuationSubmittedDetail(Unknown, SubmittedAt, User, Source));
            await t.Step("submit null", () => api.WriteValuationSubmittedDetail(null, SubmittedAt, User, Source));
            await t.Step("empty user", () => api.WriteValuationSubmittedDetail(Svs1 + "-x", SubmittedAt, "", Source));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationCase_assigns_and_replaces_case_references()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("first", () => api.WriteValuationCase(Svs1, "CAS-00001", User, EventTypeIds.CaseReferenceReceived, EventSourceTypeIds.SchemeValuationSubmissionEventMessaging));
            await t.Step("same", () => api.WriteValuationCase(Svs1, "CAS-00001", User, EventTypeIds.CaseReferenceReceived, EventSourceTypeIds.SchemeValuationSubmissionEventMessaging));
            await t.Step("same, different case", () => api.WriteValuationCase(Svs1, "cas-00001", User, EventTypeIds.CaseReferenceReceived, EventSourceTypeIds.SchemeValuationSubmissionEventMessaging));
            await t.Step("replaced", () => api.WriteValuationCase(Svs1, "CAS-00002", User, EventTypeIds.CaseReferenceReceived, EventSourceTypeIds.SchemeValuationSubmissionEventMessaging, NotifiedAt));
            await t.Step("unknown svs id", () => api.WriteValuationCase(Unknown, "CAS-00003", User, EventTypeIds.CaseReferenceReceived, Source));
            await t.Step("unknown event type", () => api.WriteValuationCase(Svs1, "CAS-00004", User, 99, Source));
            await t.Step("read", () => api.ReadCaseReferenceData(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteDocument_adds_repeats_and_replaces_documents()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.StatementOfStrategy(t, Svs1);
            await api.StatementOfStrategy(t, Svs1); // back and forward again: same document
            await api.StatementOfStrategy(t, Svs1, status: DocumentStatusTypeIds.VirusScanFailed); // same document, new status
            await api.StatementOfStrategy(t, Svs1, status: DocumentStatusTypeIds.VirusScanSuccessful); // and back
            await api.StatementOfStrategy(t, Svs1, fileName: "SOS.XLSX"); // same file, different case
            await api.StatementOfStrategy(t, Svs1, fileName: "sos-v2.xlsx", saga: Saga2); // replaces the current one
            await t.Step("actuarial valuation", () => api.WriteDocument(Svs1, User, Source, EventTypeIds.ActuarialValuationUploaded,
                "av.pdf", "internal/av.pdf", "hash-av", 4096, Saga1, DocumentTypeIds.ActuarialValuation, DocumentStatusTypeIds.VirusScanSuccessful));
            await t.Step("read", () => api.ReadDocumentMetadata(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteDocument_rejects_invalid_input()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            Task<int> Write(string? svsId, long? fileSize = 1, Guid? saga = null, short documentType = DocumentTypeIds.StatementOfStrategy,
                short eventType = EventTypeIds.StatementOfStrategyUploaded, short status = DocumentStatusTypeIds.VirusScanSuccessful, string user = User)
                => api.WriteDocument(svsId, user, Source, eventType, "f.xlsx", "internal/f.xlsx", "hash", fileSize, saga ?? Saga1, documentType, status);

            await t.Step("null file size", () => Write(Svs1, fileSize: null));
            await t.Step("null svs id", () => Write(null));
            await t.Step("default saga id", () => Write(Svs1, saga: Guid.Empty));
            await t.Step("unknown svs id", () => Write(Unknown));
            await t.Step("unknown document type", () => Write(Svs1, documentType: 99));
            await t.Step("unknown event type", () => Write(Svs1, eventType: 99));
            await t.Step("unknown status type", () => Write(Svs1, status: 99));
            await t.Step("empty user", () => Write(Svs1, user: ""));
            await t.Step("read", () => api.ReadDocumentMetadata(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteDocumentStatus_sets_document_status()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            var documentId = await api.StatementOfStrategy(t, Svs1);
            await t.Step("unchanged", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanSuccessful, documentId));
            await t.Step("new event", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, documentId, userId: User,
                eventSourceType: Source, eventTypeId: EventTypeIds.StatementOfStrategyUploaded));
            var eventReference = await t.Step("event", () => api.CreateEventById(EventTypeIds.SpecialUpdate, Svs1, User, Source));
            await t.Step("existing event", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanSuccessful, documentId, eventReference));
            await t.Step("read", () => api.ReadDocumentMetadata(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteDocumentStatus_rejects_invalid_input()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            var documentId = await api.StatementOfStrategy(t, Svs1);
            await t.Step("no event type or reference", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, documentId, userId: User, eventSourceType: Source));
            await t.Step("unknown event type", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, documentId, userId: User, eventSourceType: Source, eventTypeId: 99));
            await t.Step("no user", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, documentId, eventSourceType: Source, eventTypeId: EventTypeIds.SpecialUpdate));
            await t.Step("unknown document", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, 999, userId: User, eventSourceType: Source, eventTypeId: EventTypeIds.SpecialUpdate));
            await t.Step("unknown event reference", () => api.WriteDocumentStatus(Svs1, DocumentStatusTypeIds.VirusScanFailed, documentId, eventReference: 999));
            await t.Step("unknown status type", () => api.WriteDocumentStatus(Svs1, 99, documentId, userId: User, eventSourceType: Source, eventTypeId: EventTypeIds.SpecialUpdate));
            await t.Step("read", () => api.ReadDocumentMetadata(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteCancelDocument_end_dates_the_current_document()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.StatementOfStrategy(t, Svs1);
            await t.Step("cancel", () => api.WriteCancelDocument(Svs1, DocumentTypeIds.StatementOfStrategy, User));
            await t.Step("cancel again", () => api.WriteCancelDocument(Svs1, DocumentTypeIds.StatementOfStrategy, User));
            await t.Step("cancel type never uploaded", () => api.WriteCancelDocument(Svs1, DocumentTypeIds.ActuarialValuation, User));
            await t.Step("unknown svs id", () => api.WriteCancelDocument(Unknown, DocumentTypeIds.StatementOfStrategy, User));
            await t.Step("null svs id", () => api.WriteCancelDocument(null, DocumentTypeIds.StatementOfStrategy, User));
            await api.StatementOfStrategy(t, Svs1, fileName: "sos-v2.xlsx", saga: Saga2);
            await t.Step("empty user", () => api.WriteCancelDocument(Svs1, DocumentTypeIds.StatementOfStrategy, ""));
            await t.Step("read", () => api.ReadDocumentMetadata(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteDynamicUserJourney_records_and_replaces_choices()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("first", () => api.WriteDynamicUserJourney(Svs1, 1, 1, 1, User, Source));
            await t.Step("same", () => api.WriteDynamicUserJourney(Svs1, 1, 1, 1, User, Source));
            await t.Step("multi-doc upload", () => api.WriteDynamicUserJourney(Svs1, 1, 1, 1, User, Source, isMultiDocUpload: true));
            await t.Step("same, multi-doc upload", () => api.WriteDynamicUserJourney(Svs1, 1, 1, 1, User, Source, isMultiDocUpload: true));
            await t.Step("changed", () => api.WriteDynamicUserJourney(Svs1, 2, 2, 2, User, Source));
            await t.Step("read", () => api.ReadDynamicUserJourney(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteDynamicUserJourney_rejects_invalid_input()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("null svs id", () => api.WriteDynamicUserJourney(null, 1, 1, 1, User, Source));
            await t.Step("unknown svs id", () => api.WriteDynamicUserJourney(Unknown, 1, 1, 1, User, Source));
            await t.Step("unknown fast track type", () => api.WriteDynamicUserJourney(Svs1, 99, 1, 1, User, Source));
            await t.Step("empty user", () => api.WriteDynamicUserJourney(Svs1, 1, 1, 1, "", Source));
            await t.Step("read", () => api.ReadDynamicUserJourney(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteUserSavedSubmission_saves_progress_and_closes_the_previous_save()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await api.Submission(t, "SCHEMEVALUATION-10000835-20260331-0001", effectiveDate: new DateOnly(2026, 3, 31));
            await t.Step("first", () => api.WriteUserSavedSubmission(Svs1, User, Source, Page, "{\"page\":1}", new DateTime(2025, 5, 1, 10, 0, 0)));
            await t.Step("second", () => api.WriteUserSavedSubmission(Svs1, User, Source, Page, "{\"page\":2}", new DateTime(2025, 5, 1, 11, 0, 0)));
            await t.Step("other submission", () => api.WriteUserSavedSubmission("SCHEMEVALUATION-10000835-20260331-0001", User, Source, Page, "{}", new DateTime(2025, 5, 2, 9, 0, 0)));
            await t.Step("unknown svs id", () => api.WriteUserSavedSubmission(Unknown, User, Source, Page, "{}", new DateTime(2025, 5, 3)));
            await t.Step("null svs id", () => api.WriteUserSavedSubmission(null, User, Source, Page, "{}", new DateTime(2025, 5, 3)));
            await t.Step("empty user", () => api.WriteUserSavedSubmission(Svs1, "", Source, Page, "{}", new DateTime(2025, 5, 3)));
            await t.Step("read", () => api.ReadUserSavedSubmission(Psr));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmissionConfirmationDates_records_and_replaces_dates()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            await t.Step("first", () => api.WriteValuationSubmissionConfirmationDates(Svs1, new DateOnly(2025, 4, 1), new DateOnly(2025, 4, 2), User, Source));
            await t.Step("same again", () => api.WriteValuationSubmissionConfirmationDates(Svs1, new DateOnly(2025, 4, 1), new DateOnly(2025, 4, 2), User, Source));
            await t.Step("changed", () => api.WriteValuationSubmissionConfirmationDates(Svs1, new DateOnly(2025, 5, 1), new DateOnly(2025, 5, 2), User, Source));
            await t.Step("unknown svs id", () => api.WriteValuationSubmissionConfirmationDates(Unknown, new DateOnly(2025, 5, 1), new DateOnly(2025, 5, 2), User, Source));
            await t.Step("empty user", () => api.WriteValuationSubmissionConfirmationDates(Svs1, new DateOnly(2025, 5, 1), new DateOnly(2025, 5, 2), "", Source));
            await t.Step("read", () => api.ReadSubmission(Svs1));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmissionData_records_first_extraction_of_each_document()
    {
        // Re-extracting a document is where the two differ: see DocumentedDifferenceTests.
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            var first = await api.StatementOfStrategy(t, Svs1);
            await t.Step("extract first document", () => api.WriteValuationSubmissionData("{\"q1\":\"a\"}", first, User, Svs1, Source));
            var second = await api.StatementOfStrategy(t, Svs1, fileName: "sos-v2.xlsx", saga: Saga2);
            await t.Step("extract second document", () => api.WriteValuationSubmissionData("{\"q1\":\"b\"}", second, User, Svs1, Source));
            await t.Step("unknown document", () => api.WriteValuationSubmissionData("{}", 999, User, Svs1, Source));
            await t.Step("empty user", () => api.WriteValuationSubmissionData("{}", 999, "", Svs1, Source));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task WriteValuationSubmissionGuardQuestionAnswer_records_and_replaces_answers()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await api.Submission(t, Svs1);
            const short answered = EventTypeIds.SchemeInDeficitGuardQuestionAnswered;
            await t.Step("deficit", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 1, User, Source, answered));
            await t.Step("deficit again", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 1, User, Source, answered));
            await t.Step("surplus", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 2, User, Source, answered));
            await t.Step("deficit once more", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 1, User, Source, answered));
            await t.Step("unknown answer", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 99, User, Source, answered));
            await t.Step("unknown svs id", () => api.WriteValuationSubmissionGuardQuestionAnswer(Unknown, 1, User, Source, answered));
            await t.Step("unknown event type", () => api.WriteValuationSubmissionGuardQuestionAnswer(Svs1, 2, User, Source, 99));
        });

        result.AssertIdentical();
    }
}
