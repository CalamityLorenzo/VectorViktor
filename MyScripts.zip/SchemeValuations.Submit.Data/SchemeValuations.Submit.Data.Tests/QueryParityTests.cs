using SchemeValuations.Submit.Data.Tests.Infrastructure;
using static SchemeValuations.Submit.Data.Tests.Given;

namespace SchemeValuations.Submit.Data.Tests;

/// <summary>
/// Each read procedure against its EF Core replacement, over data written through the matching write path. Result sets
/// are compared column by column and row by row (in order where the procedure has an ORDER BY).
/// </summary>
[Collection(nameof(ParityCollection))]
public class QueryParityTests(ParityFixture fixture)
{
    private const string NextYear = "SCHEMEVALUATION-10000835-20260331-0001";
    private const string OtherPsrSvs = "SCHEMEVALUATION-12345678-20250331-0001";
    private const int OtherPsr = 12345678;

    /// <summary>
    /// Two schemes with submissions in every status, documents, case references, confirmation dates, user journeys and saves.
    /// </summary>
    private static async Task ArrangeAsync(ISchemeValuationApi api, Transcript t)
    {
        await api.Submission(t, Svs1);
        await api.StatementOfStrategy(t, Svs1);
        await api.Submitted(t, Svs1);
        await api.Submission(t, Svs2); // supersedes Svs1
        await api.StatementOfStrategy(t, Svs2, saga: Saga2);
        await t.Step("Svs2 actuarial valuation", () => api.WriteDocument(Svs2, User, Source, EventTypeIds.ActuarialValuationUploaded,
            "av.pdf", "internal/av.pdf", "hash-av", 4096, Saga1, DocumentTypeIds.ActuarialValuation, DocumentStatusTypeIds.VirusScanFailed));
        await t.Step("Svs2 case", () => api.WriteValuationCase(Svs2, "CAS-00001", User, EventTypeIds.CaseReferenceReceived, Source));
        await t.Step("Svs2 case replaced", () => api.WriteValuationCase(Svs2, "CAS-00002", User, EventTypeIds.CaseReferenceReceived, Source));
        await t.Step("Svs2 dates", () => api.WriteValuationSubmissionConfirmationDates(Svs2, new DateOnly(2025, 4, 1), new DateOnly(2025, 4, 2), User, Source));
        await t.Step("Svs2 journey", () => api.WriteDynamicUserJourney(Svs2, 1, 2, 1, User, Source, isMultiDocUpload: true));
        await t.Step("Svs2 save 1", () => api.WriteUserSavedSubmission(Svs2, User, Source, Page, "{\"page\":1}", new DateTime(2025, 5, 1, 10, 0, 0)));
        await t.Step("Svs2 save 2", () => api.WriteUserSavedSubmission(Svs2, User, Source, Page, "{\"page\":2}", new DateTime(2025, 5, 1, 11, 0, 0)));

        await api.Submission(t, NextYear, effectiveDate: new DateOnly(2026, 3, 31));
        await t.Step("NextYear save", () => api.WriteUserSavedSubmission(NextYear, User, Source, Page, "{\"page\":3}", new DateTime(2025, 5, 2, 9, 0, 0)));
        await t.Step("NextYear cancelled", () => api.WriteValuationSubmissionStatus(NextYear, SubmissionStatusTypeIds.Cancelled, User, Source, EventTypeIds.UserChangedSubmissionStatus));

        await api.Submission(t, OtherPsrSvs, psr: OtherPsr, schemeName: "Other Scheme");
        await t.Step("OtherPsr save", () => api.WriteUserSavedSubmission(OtherPsrSvs, User, Source, Page, "{}", new DateTime(2025, 5, 3, 9, 0, 0)));
        await api.Submitted(t, OtherPsrSvs);
    }

    [Fact]
    public async Task ReadCaseReferenceData()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("with cases", () => api.ReadCaseReferenceData(Svs2));
            await t.Step("without cases", () => api.ReadCaseReferenceData(Svs1));
            await t.Step("unknown", () => api.ReadCaseReferenceData(Unknown));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadDocumentMetadata()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("Svs2", () => api.ReadDocumentMetadata(Svs2));
            await t.Step("Svs2 in progress", () => api.ReadDocumentMetadata(Svs2, SubmissionStatusTypeIds.InProgress));
            await t.Step("Svs2 submitted", () => api.ReadDocumentMetadata(Svs2, SubmissionStatusTypeIds.Submitted));
            await t.Step("Svs1 (superseded)", () => api.ReadDocumentMetadata(Svs1));
            await t.Step("Svs1 superseded", () => api.ReadDocumentMetadata(Svs1, SubmissionStatusTypeIds.Superseded));
            await t.Step("no documents", () => api.ReadDocumentMetadata(NextYear));
            await t.Step("unknown", () => api.ReadDocumentMetadata(Unknown));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadDynamicUserJourney()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("Svs2 journey replaced", () => api.WriteDynamicUserJourney(Svs2, 2, 1, 2, User, Source));
            await t.Step("with journey", () => api.ReadDynamicUserJourney(Svs2));
            await t.Step("without journey", () => api.ReadDynamicUserJourney(Svs1));
            await t.Step("unknown", () => api.ReadDynamicUserJourney(Unknown));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadIsUserSubmissionInProgress()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            for (var id = 0; id <= 5; id++)
            {
                var userSavedSubmissionId = id;
                await t.Step($"UserSavedSubmissionId {id}", () => api.ReadIsUserSubmissionInProgress(userSavedSubmissionId));
            }
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadPsrHasUserSubmissionInProgress()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("PSR with in-progress save", () => api.ReadPsrHasUserSubmissionInProgress(Psr));
            await t.Step("PSR whose save is submitted", () => api.ReadPsrHasUserSubmissionInProgress(OtherPsr));
            await t.Step("unknown PSR", () => api.ReadPsrHasUserSubmissionInProgress(99999999));
            await t.Step("PSR 0", () => api.ReadPsrHasUserSubmissionInProgress(0));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadSubmission()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            foreach (var svsId in new[] { Svs1, Svs2, NextYear, OtherPsrSvs, Unknown })
            {
                await t.Step($"{svsId}", () => api.ReadSubmission(svsId));
                foreach (var status in new short?[] { SubmissionStatusTypeIds.InProgress, SubmissionStatusTypeIds.Submitted, SubmissionStatusTypeIds.Cancelled, SubmissionStatusTypeIds.Superseded })
                {
                    await t.Step($"{svsId} status {status}", () => api.ReadSubmission(svsId, status));
                }
            }
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadSubmittedSubmission_for_a_submitted_submission()
    {
        // For submissions that are not in Submitted status the two differ: see DocumentedDifferenceTests.
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("OtherPsrSvs dates", () => api.WriteValuationSubmissionConfirmationDates(OtherPsrSvs, new DateOnly(2025, 4, 3), new DateOnly(2025, 4, 4), User, Source));
            await t.Step("submitted", () => api.ReadSubmittedSubmission(OtherPsrSvs));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadUserSavedAndValuationSubmission()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await api.Submission(t, "SCHEMEVALUATION-10000835-20270331-0001", effectiveDate: new DateOnly(2027, 3, 31));
            await t.Step("2027 save", () => api.WriteUserSavedSubmission("SCHEMEVALUATION-10000835-20270331-0001", User, Source, Page, "{}", new DateTime(2025, 4, 1)));
            await t.Step("PSR", () => api.ReadUserSavedAndValuationSubmission(Psr));
            await t.Step("PSR with only a submitted save", () => api.ReadUserSavedAndValuationSubmission(OtherPsr));
            await t.Step("unknown PSR", () => api.ReadUserSavedAndValuationSubmission(99999999));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadUserSavedSubmission()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("PSR", () => api.ReadUserSavedSubmission(Psr));
            await t.Step("other PSR", () => api.ReadUserSavedSubmission(OtherPsr));
            await t.Step("unknown PSR", () => api.ReadUserSavedSubmission(99999999));
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReadValuationSubmissionId()
    {
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            foreach (var svsId in new[] { Svs1, Svs2, NextYear, OtherPsrSvs, Svs1.ToLowerInvariant(), Unknown, "", null })
            {
                await t.Step($"'{svsId ?? "NULL"}'", () => api.ReadValuationSubmissionId(svsId));
            }
        });

        result.AssertIdentical();
    }

    [Fact]
    public async Task ReportRecentSubmissionsByDate()
    {
        var today = DateOnly.FromDateTime(DateTime.Now);
        var result = await fixture.RunAsync(async (api, t) =>
        {
            await ArrangeAsync(api, t);
            await t.Step("Svs2 SoS data", () => api.WriteValuationSubmissionData("{}", 2, User, Svs2, Source));
            await t.Step("cancel Svs2 SoS", () => api.WriteCancelDocument(Svs2, DocumentTypeIds.StatementOfStrategy, User));
            await t.Step("today", () => api.ReportRecentSubmissionsByDate(today));
            await t.Step("yesterday", () => api.ReportRecentSubmissionsByDate(today.AddDays(-1)));
        });

        result.AssertIdentical();
    }
}
