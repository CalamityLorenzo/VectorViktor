using Microsoft.Data.SqlClient;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>The full contents of every table (reference data included), for a row-by-row comparison of two databases.</summary>
public sealed class DatabaseSnapshot
{
    // Tables that belong to the deployment tooling rather than the schema.
    private static readonly HashSet<string> ToolingTables = new(StringComparer.OrdinalIgnoreCase) { "dbo.__EFMigrationsHistory", "dbo.__RefactorLog" };

    private DatabaseSnapshot(SortedDictionary<string, ResultSet> tables) => Tables = tables;

    public SortedDictionary<string, ResultSet> Tables { get; }

    public static async Task<DatabaseSnapshot> CaptureAsync(string connectionString)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync();

        var tables = new SortedDictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
        await using (var command = new SqlCommand(
            "SELECT TABLE_SCHEMA + '.' + TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS c WHERE OBJECTPROPERTY(OBJECT_ID(QUOTENAME(TABLE_SCHEMA) + '.' + QUOTENAME(TABLE_NAME)), 'IsUserTable') = 1",
            connection))
        await using (var reader = await command.ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                var table = reader.GetString(0);
                if (!ToolingTables.Contains(table))
                {
                    (tables.TryGetValue(table, out var columns) ? columns : tables[table] = []).Add(reader.GetString(1));
                }
            }
        }

        var snapshot = new SortedDictionary<string, ResultSet>(StringComparer.OrdinalIgnoreCase);
        foreach (var (table, columns) in tables)
        {
            // Columns sorted by name so that column order in the table definition does not matter.
            var columnList = string.Join(", ", columns.Order(StringComparer.OrdinalIgnoreCase).Select(c => $"[{c}]"));
            var parts = table.Split('.');
            await using var command = new SqlCommand($"SELECT {columnList} FROM [{parts[0]}].[{parts[1]}]", connection);
            await using var reader = await command.ExecuteReaderAsync();
            snapshot[table] = await ResultSet.FromReaderAsync(reader, ordered: false);
        }

        return new DatabaseSnapshot(snapshot);
    }
}
