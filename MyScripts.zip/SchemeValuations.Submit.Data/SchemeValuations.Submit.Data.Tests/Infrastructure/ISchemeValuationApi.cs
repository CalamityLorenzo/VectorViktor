namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>
/// One method per original stored procedure. <see cref="StoredProcedureApi"/> calls the procedure in the legacy
/// database; <see cref="EfCoreApi"/> calls the EF Core replacement. Scalar results are the procedure's OUTPUT
/// parameter (or the service's return value); result sets are normalised into a <see cref="ResultSet"/>.
/// </summary>
public interface ISchemeValuationApi
{
    Task<int> CreateEventById(short eventTypeId, string? schemeValuationSubmissionId, string? userId, short eventSourceTypeId,
        int? valuationSubmissionId = null, string? transactionId = null, DateTime? notificationDate = null);

    Task<int?> WriteCancelDocument(string? schemeValuationSubmissionId, short documentType, string userId);

    Task<int> WriteDocument(string? schemeValuationSubmissionId, string userId, short eventSourceType, short eventType,
        string uploadedFileName, string internalFileName, string fileHash, long? fileSize, Guid sagaUploadedFileCorrelationId,
        short documentType, short documentStatusType);

    Task<int> WriteDocumentStatus(string schemeValuationSubmissionId, short documentStatusTypeId, int documentId,
        int? eventReference = null, string? userId = null, short? eventSourceType = null, short? eventTypeId = null);

    Task<int> WriteDynamicUserJourney(string? schemeValuationSubmissionId, short fastTrackOrBespokeType, short deficitOrSurplusType,
        short additionalRequiredDocumentType, string userId, short eventSourceType, bool isMultiDocUpload = false);

    Task<int> WriteUserSavedSubmission(string? schemeValuationSubmissionId, string userId, short eventSourceTypeId,
        Guid lastActionPageId, string lastPageData, DateTime lastUpdated);

    Task<int> WriteValuationCase(string schemeValuationSubmissionId, string caseReference, string userId, short eventType,
        short eventSourceType, DateTime? notificationDate = null);

    Task<int> WriteValuationScheme(int psrNumber, string schemeName, int eventReference);

    Task<int> WriteValuationSubmission(string schemeValuationSubmissionId, int psrNumber, string schemeName, DateOnly effectiveDate,
        string userId, short eventSourceType, bool isExcludedSubmission = false);

    Task<int> WriteValuationSubmissionConfirmationDates(string schemeValuationSubmissionId, DateOnly dateFundingAndInvestmentStrategyWasFinalised,
        DateOnly dateStatementOfStrategyWasSigned, string userId, short eventSourceType);

    Task<int> WriteValuationSubmissionData(string questionsAndResponses, int documentId, string userId, string schemeValuationSubmissionId,
        short eventSourceType);

    Task<int> WriteValuationSubmissionGuardQuestionAnswer(string schemeValuationSubmissionId, int guardQuestionAnswerId, string userId,
        short eventSourceType, short eventType);

    Task<int> WriteValuationSubmissionStatus(string schemeValuationSubmissionId, short submissionStatusType, string userId,
        short eventSourceType = 0, short eventType = 0, int currentEventReference = 0);

    Task<int> WriteValuationSubmittedDetail(string? schemeValuationSubmissionId, DateTime submittedDateTime, string userId,
        short eventSourceType, short eventType = EventTypeIds.SchemeValuationSubmitted);

    Task<ResultSet> ReadCaseReferenceData(string schemeValuationSubmissionId);

    Task<ResultSet> ReadDocumentMetadata(string schemeValuationSubmissionId, short? submissionStatusType = null);

    Task<ResultSet> ReadDynamicUserJourney(string schemeValuationSubmissionId);

    Task<ResultSet> ReadIsUserSubmissionInProgress(int userSavedSubmissionId);

    Task<bool> ReadPsrHasUserSubmissionInProgress(int psrNumber);

    Task<ResultSet> ReadSubmission(string schemeValuationSubmissionId, short? submissionStatusTypeId = null);

    Task<ResultSet> ReadSubmittedSubmission(string schemeValuationSubmissionId);

    Task<ResultSet> ReadUserSavedAndValuationSubmission(int psrNumber);

    Task<ResultSet> ReadUserSavedSubmission(int psrNumber);

    Task<int> ReadValuationSubmissionId(string? schemeValuationSubmissionId);

    Task<ResultSet[]> ReportRecentSubmissionsByDate(DateOnly createdDate);
}
