using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>Minimal SQLCMD-style script handling: <c>:r</c> includes and <c>GO</c> batch separators.</summary>
internal static partial class SqlScript
{
    /// <summary>Reads a script, recursively inlining <c>:r .\file.sql</c> includes relative to the including file.</summary>
    public static string ReadExpanded(string path)
    {
        var builder = new StringBuilder();
        foreach (var line in File.ReadAllLines(path))
        {
            var include = IncludeLine().Match(line);
            if (include.Success)
            {
                var includedPath = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(path)!, include.Groups["path"].Value.Trim()));
                builder.AppendLine(ReadExpanded(includedPath));
                builder.AppendLine("GO");
            }
            else
            {
                builder.AppendLine(line);
            }
        }

        return builder.ToString();
    }

    public static IEnumerable<string> SplitBatches(string script)
        => BatchSeparator().Split(script).Where(batch => !string.IsNullOrWhiteSpace(batch));

    public static async Task ExecuteAsync(SqlConnection connection, string script)
    {
        foreach (var batch in SplitBatches(script))
        {
            await using var command = new SqlCommand(batch, connection) { CommandTimeout = 120 };
            await command.ExecuteNonQueryAsync();
        }
    }

    [GeneratedRegex(@"^\s*:r\s+(?<path>.+?)\s*$", RegexOptions.IgnoreCase)]
    private static partial Regex IncludeLine();

    // "GO", "GO;" and "GO " on a line of their own.
    [GeneratedRegex(@"^\s*GO\s*;?\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline)]
    private static partial Regex BatchSeparator();
}
