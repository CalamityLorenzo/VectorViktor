using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SchemeValuations.Submit.Data.Services;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>
/// Records what each call in a scenario returned, or the error it raised, so that the same scenario run against
/// both implementations can be compared line by line.
/// </summary>
/// <remarks>
/// Only the error <em>message</em> is recorded: the procedures raise a <see cref="SqlException"/> (THROW 50005)
/// where the services raise <see cref="SchemeValuationDataException"/>, and constraint violations arrive wrapped in a
/// <see cref="DbUpdateException"/> from EF. Database names in SQL Server messages are masked.
/// </remarks>
public sealed class Transcript(params string[] databaseNames)
{
    private readonly List<(string Step, string Outcome)> _entries = [];

    public IReadOnlyList<(string Step, string Outcome)> Entries => _entries;

    /// <summary>The recorded outcome of the named step.</summary>
    public string this[string step] => _entries.Single(e => e.Step == step).Outcome;

    /// <summary>Runs a call and records its outcome. Returns the result, or default when it failed.</summary>
    public async Task<T> Step<T>(string name, Func<Task<T>> call)
    {
        try
        {
            var result = await call();
            _entries.Add((name, Format(result)));
            return result;
        }
        catch (Exception ex)
        {
            _entries.Add((name, "ERROR " + Describe(ex)));
            return default!;
        }
    }

    public override string ToString() => string.Join(Environment.NewLine, _entries.Select(e => $"{e.Step} => {e.Outcome}"));

    private static string Format(object? value) => value switch
    {
        ResultSet set => Environment.NewLine + set,
        ResultSet[] sets => string.Concat(sets.Select((s, i) => $"{Environment.NewLine}  -- result set {i + 1}{Environment.NewLine}{s}")),
        _ => ResultSet.FormatValue(value),
    };

    private string Describe(Exception ex)
    {
        switch (ex)
        {
            case SchemeValuationDataException:
                return ex.Message;
            case DbUpdateException { InnerException: not null }:
                return Describe(ex.InnerException);
            case SqlException sql:
                // A procedure error can be followed by secondary errors (e.g. "Transaction count after EXECUTE...");
                // the business error is the THROW 50005, or else the first error.
                var error = sql.Errors.Cast<SqlError>().FirstOrDefault(e => e.Number == 50005) ?? sql.Errors[0];
                return databaseNames.Aggregate(error.Message, (message, db) => message.Replace(db, "<database>"));
            default:
                return $"{ex.GetType().Name}: {ex.Message}";
        }
    }
}
