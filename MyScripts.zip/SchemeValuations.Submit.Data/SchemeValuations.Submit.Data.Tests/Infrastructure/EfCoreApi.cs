using SchemeValuations.Submit.Data.Services;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>
/// Calls the EF Core replacements (<see cref="SchemeValuationCommands"/> and <see cref="SchemeValuationQueries"/>).
/// One context is shared by all calls, as it would be within a DI scope.
/// </summary>
public sealed class EfCoreApi(SchemeValuationDbContext db) : ISchemeValuationApi
{
    private readonly SchemeValuationCommands _commands = new(db);
    private readonly SchemeValuationQueries _queries = new(db);

    public Task<int> CreateEventById(short eventTypeId, string? schemeValuationSubmissionId, string? userId, short eventSourceTypeId,
        int? valuationSubmissionId = null, string? transactionId = null, DateTime? notificationDate = null)
        => _commands.CreateEventByIdAsync(eventTypeId, schemeValuationSubmissionId!, userId!, eventSourceTypeId, valuationSubmissionId, transactionId, notificationDate);

    public Task<int?> WriteCancelDocument(string? schemeValuationSubmissionId, short documentType, string userId)
        => _commands.WriteCancelDocumentAsync(schemeValuationSubmissionId!, documentType, userId);

    public Task<int> WriteDocument(string? schemeValuationSubmissionId, string userId, short eventSourceType, short eventType,
        string uploadedFileName, string internalFileName, string fileHash, long? fileSize, Guid sagaUploadedFileCorrelationId,
        short documentType, short documentStatusType)
        => _commands.WriteDocumentAsync(schemeValuationSubmissionId!, userId, eventSourceType, eventType, uploadedFileName, internalFileName,
            fileHash, fileSize, sagaUploadedFileCorrelationId, documentType, documentStatusType);

    public Task<int> WriteDocumentStatus(string schemeValuationSubmissionId, short documentStatusTypeId, int documentId,
        int? eventReference = null, string? userId = null, short? eventSourceType = null, short? eventTypeId = null)
        => _commands.WriteDocumentStatusAsync(schemeValuationSubmissionId, documentStatusTypeId, documentId, eventReference, userId, eventSourceType, eventTypeId);

    public Task<int> WriteDynamicUserJourney(string? schemeValuationSubmissionId, short fastTrackOrBespokeType, short deficitOrSurplusType,
        short additionalRequiredDocumentType, string userId, short eventSourceType, bool isMultiDocUpload = false)
        => _commands.WriteDynamicUserJourneyAsync(schemeValuationSubmissionId!, fastTrackOrBespokeType, deficitOrSurplusType,
            additionalRequiredDocumentType, userId, eventSourceType, isMultiDocUpload);

    public Task<int> WriteUserSavedSubmission(string? schemeValuationSubmissionId, string userId, short eventSourceTypeId,
        Guid lastActionPageId, string lastPageData, DateTime lastUpdated)
        => _commands.WriteUserSavedSubmissionAsync(schemeValuationSubmissionId!, userId, eventSourceTypeId, lastActionPageId, lastPageData, lastUpdated);

    public Task<int> WriteValuationCase(string schemeValuationSubmissionId, string caseReference, string userId, short eventType,
        short eventSourceType, DateTime? notificationDate = null)
        => _commands.WriteValuationCaseAsync(schemeValuationSubmissionId, caseReference, userId, eventType, eventSourceType, notificationDate);

    public Task<int> WriteValuationScheme(int psrNumber, string schemeName, int eventReference)
        => _commands.WriteValuationSchemeAsync(psrNumber, schemeName, eventReference);

    public Task<int> WriteValuationSubmission(string schemeValuationSubmissionId, int psrNumber, string schemeName, DateOnly effectiveDate,
        string userId, short eventSourceType, bool isExcludedSubmission = false)
        => _commands.WriteValuationSubmissionAsync(schemeValuationSubmissionId, psrNumber, schemeName, effectiveDate, userId, eventSourceType, isExcludedSubmission);

    public Task<int> WriteValuationSubmissionConfirmationDates(string schemeValuationSubmissionId, DateOnly dateFundingAndInvestmentStrategyWasFinalised,
        DateOnly dateStatementOfStrategyWasSigned, string userId, short eventSourceType)
        => _commands.WriteValuationSubmissionConfirmationDatesAsync(schemeValuationSubmissionId, dateFundingAndInvestmentStrategyWasFinalised,
            dateStatementOfStrategyWasSigned, userId, eventSourceType);

    public Task<int> WriteValuationSubmissionData(string questionsAndResponses, int documentId, string userId, string schemeValuationSubmissionId,
        short eventSourceType)
        => _commands.WriteValuationSubmissionDataAsync(questionsAndResponses, documentId, userId, schemeValuationSubmissionId, eventSourceType);

    public Task<int> WriteValuationSubmissionGuardQuestionAnswer(string schemeValuationSubmissionId, int guardQuestionAnswerId, string userId,
        short eventSourceType, short eventType)
        => _commands.WriteValuationSubmissionGuardQuestionAnswerAsync(schemeValuationSubmissionId, guardQuestionAnswerId, userId, eventSourceType, eventType);

    public Task<int> WriteValuationSubmissionStatus(string schemeValuationSubmissionId, short submissionStatusType, string userId,
        short eventSourceType = 0, short eventType = 0, int currentEventReference = 0)
        => _commands.WriteValuationSubmissionStatusAsync(schemeValuationSubmissionId, submissionStatusType, userId, eventSourceType, eventType, currentEventReference);

    public Task<int> WriteValuationSubmittedDetail(string? schemeValuationSubmissionId, DateTime submittedDateTime, string userId,
        short eventSourceType, short eventType = EventTypeIds.SchemeValuationSubmitted)
        => _commands.WriteValuationSubmittedDetailAsync(schemeValuationSubmissionId!, submittedDateTime, userId, eventSourceType, eventType);

    public async Task<ResultSet> ReadCaseReferenceData(string schemeValuationSubmissionId)
        => ResultSet.FromObjects(await _queries.ReadCaseReferenceDataAsync(schemeValuationSubmissionId));

    public async Task<ResultSet> ReadDocumentMetadata(string schemeValuationSubmissionId, short? submissionStatusType = null)
        => ResultSet.FromObjects(await _queries.ReadDocumentMetadataAsync(schemeValuationSubmissionId, submissionStatusType));

    public async Task<ResultSet> ReadDynamicUserJourney(string schemeValuationSubmissionId)
        => ResultSet.FromObjects(await _queries.ReadDynamicUserJourneyAsync(schemeValuationSubmissionId));

    public async Task<ResultSet> ReadIsUserSubmissionInProgress(int userSavedSubmissionId)
        => ResultSet.Single(await _queries.ReadIsUserSubmissionInProgressAsync(userSavedSubmissionId));

    public Task<bool> ReadPsrHasUserSubmissionInProgress(int psrNumber)
        => _queries.ReadPsrHasUserSubmissionInProgressAsync(psrNumber);

    public async Task<ResultSet> ReadSubmission(string schemeValuationSubmissionId, short? submissionStatusTypeId = null)
        => ResultSet.FromObjects(await _queries.ReadSubmissionAsync(schemeValuationSubmissionId, submissionStatusTypeId));

    public async Task<ResultSet> ReadSubmittedSubmission(string schemeValuationSubmissionId)
        => ResultSet.Single(await _queries.ReadSubmittedSubmissionAsync(schemeValuationSubmissionId));

    // The service returns the whole view row; the procedure selected these columns from it.
    public async Task<ResultSet> ReadUserSavedAndValuationSubmission(int psrNumber)
        => ResultSet.FromObjects(await _queries.ReadUserSavedAndValuationSubmissionAsync(psrNumber), ordered: true,
            "UserSavedSubmissionId", "PSRNumber", "SchemeValuationSubmissionId", "EffectiveDate", "LastUpdated", "LastActionPageId",
            "LastPageData", "UserSavedSubmissionStartEventReference", "SchemeName", "ValuationSchemeId", "SubmissionStatusTypeId",
            "ValuationSubmissionCreateDateTime", "ValuationSubmissionId", "DateFundingAndInvestmentStrategyWasFinalised",
            "DateStatementOfStrategyWasSigned", "IsExcludedSubmission", "StartEventReference", "EndEventReference", "CreateDateTime",
            "ValuationSubmissionUserId", "AdditionalRequiredDocumentTypeId", "AdditionalRequiredDocumentDescription", "DynamicUserJourneyId",
            "FastTrackOrBespokeTypeId", "FastTrackOrBespokeDescription", "DeficitOrSurplusTypeId", "DeficitOrSurplusDescription", "IsMultiDocUpload");

    public async Task<ResultSet> ReadUserSavedSubmission(int psrNumber)
        => ResultSet.FromObjects(await _queries.ReadUserSavedSubmissionAsync(psrNumber), ordered: true);

    public Task<int> ReadValuationSubmissionId(string? schemeValuationSubmissionId)
        => _queries.ReadValuationSubmissionIdAsync(schemeValuationSubmissionId);

    public async Task<ResultSet[]> ReportRecentSubmissionsByDate(DateOnly createdDate)
    {
        var report = await _queries.ReportRecentSubmissionsByDateAsync(createdDate);
        return
        [
            ResultSet.FromObjects(report.Events),
            ResultSet.FromObjects(report.Submissions),
            // The procedure's third result set has two columns both called IsActive.
            ResultSet.FromObjects(report.Documents, ordered: false,
                "UploadedFileName", "InternalFileName", "FileHash", "StartEventReference", "EndEventReference", "DocumentTypeName",
                "DocumentTypeDescription", "DocumentTypeIsActive AS IsActive", "DocumentStatusName", "DocumentStatusDescription",
                "DocumentStatusIsActive AS IsActive"),
        ];
    }
}
