using Microsoft.Data.SqlClient;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>
/// Owns the two databases: "legacy", deployed from the original SSDT project with its stored procedures, and
/// "EF Core", created by the migrations. Both are created once per test run on the same SQL Server instance
/// (LocalDB by default; set SCHEMEVALUATION_TEST_SERVER to a server-level connection string to use another).
/// </summary>
public sealed class ParityFixture : IAsyncLifetime
{
    public const string LegacyDatabaseName = "SchemeValuationParity_Legacy";
    public const string EfCoreDatabaseName = "SchemeValuationParity_EfCore";

    private const string DefaultServer = @"Server=(localdb)\MSSQLLocalDB;Integrated Security=True;TrustServerCertificate=True";

    // Seeded reference data, kept between scenarios.
    private static readonly string[] ReferenceTables =
    [
        "AdditionalRequiredDocumentType", "DeficitOrSurplusType", "DocumentStatusType", "DocumentType", "EventSourceType",
        "EventType", "FastTrackOrBespokeType", "GuardQuestion", "GuardQuestionAnswer", "SubmissionStatusType",
    ];

    private static readonly string Server = Environment.GetEnvironmentVariable("SCHEMEVALUATION_TEST_SERVER") ?? DefaultServer;

    public string LegacyConnectionString { get; } = DatabaseBuilder.WithDatabase(Server, LegacyDatabaseName);

    public string EfCoreConnectionString { get; } = DatabaseBuilder.WithDatabase(Server, EfCoreDatabaseName);

    public async Task InitializeAsync()
    {
        var legacyProject = Path.Combine(AppContext.BaseDirectory, "LegacyDatabase");
        await Task.WhenAll(
            Task.Run(() => DatabaseBuilder.CreateLegacyDatabaseAsync(Server, LegacyDatabaseName, legacyProject)),
            DatabaseBuilder.CreateEfCoreDatabaseAsync(Server, EfCoreDatabaseName));
    }

    // The databases are left in place so they can be inspected after a run; they are recreated on the next run.
    public Task DisposeAsync()
    {
        SqlConnection.ClearAllPools();
        return Task.CompletedTask;
    }

    /// <summary>
    /// Empties both databases (identity seeds included), runs the scenario against the stored procedures and then
    /// against the EF Core services, and captures both databases afterwards.
    /// </summary>
    /// <param name="scenario">The calls to make. It must make the same calls whichever implementation it is given.</param>
    /// <param name="arrangeSql">Optional SQL run against both databases after they are emptied.</param>
    public async Task<ParityResult> RunAsync(Func<ISchemeValuationApi, Transcript, Task> scenario, string? arrangeSql = null)
    {
        await Task.WhenAll(ResetAsync(LegacyConnectionString), ResetAsync(EfCoreConnectionString));
        if (arrangeSql is not null)
        {
            await ExecuteOnBothAsync(arrangeSql);
        }

        var legacy = new Transcript(LegacyDatabaseName, EfCoreDatabaseName);
        await scenario(new StoredProcedureApi(LegacyConnectionString), legacy);

        var efCore = new Transcript(LegacyDatabaseName, EfCoreDatabaseName);
        await using (var db = DatabaseBuilder.CreateContext(EfCoreConnectionString))
        {
            await scenario(new EfCoreApi(db), efCore);
        }

        return new ParityResult(
            legacy,
            efCore,
            await DatabaseSnapshot.CaptureAsync(LegacyConnectionString),
            await DatabaseSnapshot.CaptureAsync(EfCoreConnectionString));
    }

    /// <summary>Runs raw SQL against both databases, e.g. to set up a state the API cannot produce.</summary>
    public async Task ExecuteOnBothAsync(string sql)
    {
        foreach (var connectionString in new[] { LegacyConnectionString, EfCoreConnectionString })
        {
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            await SqlScript.ExecuteAsync(connection, sql);
        }
    }

    /// <summary>Empties both databases, keeping the reference data, and reseeds their identities.</summary>
    public Task ResetAsync() => Task.WhenAll(ResetAsync(LegacyConnectionString), ResetAsync(EfCoreConnectionString));

    private static async Task ResetAsync(string connectionString)
    {
        var keep = string.Join(", ", ReferenceTables.Append("__EFMigrationsHistory").Append("__RefactorLog").Select(t => $"'{t}'"));

        // Constraints are disabled while deleting because Event and ValuationSubmission reference each other.
        // Identities are reseeded so both databases hand out the same ids; a table that has never had a row keeps its
        // original seed (reseeding it to 0 would make its first id 0).
        var sql = $"""
            DECLARE @sql nvarchar(max) = N'';
            SELECT @sql += N'ALTER TABLE ' + QUOTENAME(SCHEMA_NAME(schema_id)) + N'.' + QUOTENAME(name) + N' NOCHECK CONSTRAINT ALL;' FROM sys.tables;
            EXEC (@sql);

            SET @sql = N'';
            SELECT @sql += N'DELETE FROM ' + QUOTENAME(SCHEMA_NAME(schema_id)) + N'.' + QUOTENAME(name) + N';' FROM sys.tables WHERE name NOT IN ({keep});
            EXEC (@sql);

            SET @sql = N'';
            SELECT @sql += N'DBCC CHECKIDENT (''' + QUOTENAME(SCHEMA_NAME(t.schema_id)) + N'.' + QUOTENAME(t.name) + N''', RESEED, 0) WITH NO_INFOMSGS;'
            FROM sys.identity_columns ic JOIN sys.tables t ON t.object_id = ic.object_id
            WHERE ic.last_value IS NOT NULL AND t.name NOT IN ({keep});
            EXEC (@sql);

            SET @sql = N'';
            SELECT @sql += N'ALTER TABLE ' + QUOTENAME(SCHEMA_NAME(schema_id)) + N'.' + QUOTENAME(name) + N' WITH CHECK CHECK CONSTRAINT ALL;' FROM sys.tables;
            EXEC (@sql);

            UPDATE dbo.EventType SET IsActive = 1 WHERE IsActive = 0;
            """;

        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync();
        await SqlScript.ExecuteAsync(connection, sql);
    }
}

[CollectionDefinition(nameof(ParityCollection))]
public sealed class ParityCollection : ICollectionFixture<ParityFixture>;
