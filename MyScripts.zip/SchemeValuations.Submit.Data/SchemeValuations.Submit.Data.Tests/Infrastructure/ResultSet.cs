using System.Data.Common;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>
/// A tabular result normalised so that a stored procedure's result set and the objects returned by the
/// EF Core services can be compared cell by cell: integers of any width compare equal, SQL <c>date</c> and
/// <see cref="DateOnly"/> compare equal, and timestamps set by <c>getdate()</c> are masked.
/// </summary>
public sealed class ResultSet
{
    // Filled in by the database clock (Event.CreateDateTime), so they differ between the two databases by design.
    private static readonly HashSet<string> ClockColumns = new(StringComparer.OrdinalIgnoreCase) { "CreateDateTime", "ValuationSubmissionCreateDateTime" };

    private ResultSet(IReadOnlyList<string> columns, IReadOnlyList<object?[]> rows, bool ordered)
    {
        Columns = columns;
        Rows = rows;
        Ordered = ordered;
    }

    public IReadOnlyList<string> Columns { get; }

    public IReadOnlyList<object?[]> Rows { get; }

    /// <summary>When false (no ORDER BY in the procedure), row order is ignored when comparing.</summary>
    public bool Ordered { get; }

    public static async Task<ResultSet> FromReaderAsync(DbDataReader reader, bool ordered)
    {
        var columns = Enumerable.Range(0, reader.FieldCount).Select(reader.GetName).ToList();
        var isDate = Enumerable.Range(0, reader.FieldCount).Select(i => reader.GetDataTypeName(i).Equals("date", StringComparison.OrdinalIgnoreCase)).ToArray();
        var rows = new List<object?[]>();
        while (await reader.ReadAsync())
        {
            var row = new object?[reader.FieldCount];
            for (var i = 0; i < row.Length; i++)
            {
                var value = reader.IsDBNull(i) ? null : reader.GetValue(i);
                row[i] = isDate[i] && value is DateTime date ? DateOnly.FromDateTime(date) : value;
            }

            rows.Add(row);
        }

        return Create(columns, rows, ordered);
    }

    /// <summary>
    /// Builds a result set from objects. By default every scalar property becomes a column, in declaration order.
    /// Pass <paramref name="columns"/> to pick columns explicitly; <c>"Property AS Column"</c> renames one.
    /// </summary>
    public static ResultSet FromObjects<T>(IEnumerable<T> items, bool ordered = false, params string[] columns)
    {
        var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => IsScalar(p.PropertyType))
            .OrderBy(p => p.MetadataToken)
            .ToList();

        var selected = columns.Length == 0
            ? properties.Select(p => (Property: p, Name: p.Name)).ToList()
            : columns.Select(spec =>
            {
                var parts = spec.Split(" AS ", StringSplitOptions.TrimEntries);
                var property = properties.SingleOrDefault(p => p.Name == parts[0])
                    ?? throw new ArgumentException($"{typeof(T).Name} has no scalar property {parts[0]}.");
                return (Property: property, Name: parts.Length > 1 ? parts[1] : parts[0]);
            }).ToList();

        var rows = items.Select(item => selected.Select(c => c.Property.GetValue(item)).ToArray()).ToList();
        return Create(selected.Select(c => c.Name).ToList(), rows, ordered);
    }

    public static ResultSet Single<T>(T? item, params string[] columns)
        => FromObjects(item is null ? [] : new[] { item }, ordered: false, columns);

    /// <summary>The rows as column name to (normalised) value maps.</summary>
    public IReadOnlyList<IReadOnlyDictionary<string, object?>> Records()
        => Rows.Select(row => (IReadOnlyDictionary<string, object?>)Columns.Zip(row).ToDictionary(c => c.First, c => c.Second, StringComparer.OrdinalIgnoreCase)).ToList();

    public override string ToString()
    {
        var builder = new StringBuilder();
        builder.Append("  [").Append(string.Join(", ", Columns)).Append(']');
        var lines = Rows.Select(row => "  " + string.Join(", ", row.Select(FormatValue))).ToList();
        if (!Ordered)
        {
            lines.Sort(StringComparer.Ordinal);
        }

        foreach (var line in lines)
        {
            builder.AppendLine().Append(line);
        }

        if (lines.Count == 0)
        {
            builder.AppendLine().Append("  (no rows)");
        }

        return builder.ToString();
    }

    public static string FormatValue(object? value) => value switch
    {
        null => "NULL",
        string s => $"'{s}'",
        bool b => b ? "true" : "false",
        DateOnly d => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
        DateTime dt => dt.ToString("yyyy-MM-dd HH:mm:ss.fffffff", CultureInfo.InvariantCulture),
        byte[] bytes => "0x" + Convert.ToHexString(bytes),
        ClockValue => "<getdate()>",
        IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
        _ => value.ToString() ?? "",
    };

    private static ResultSet Create(IReadOnlyList<string> columns, List<object?[]> rows, bool ordered)
    {
        foreach (var row in rows)
        {
            for (var i = 0; i < row.Length; i++)
            {
                row[i] = Normalise(row[i]);
                if (row[i] is not null && ClockColumns.Contains(columns[i]))
                {
                    row[i] = ClockValue.Instance;
                }
            }
        }

        return new ResultSet(columns, rows, ordered);
    }

    private static object? Normalise(object? value) => value switch
    {
        DBNull => null,
        byte or short or int or long => Convert.ToInt64(value, CultureInfo.InvariantCulture),
        _ => value,
    };

    private static bool IsScalar(Type type)
    {
        type = Nullable.GetUnderlyingType(type) ?? type;
        return type.IsPrimitive || type.IsEnum || type == typeof(string) || type == typeof(decimal) || type == typeof(Guid)
            || type == typeof(DateTime) || type == typeof(DateOnly) || type == typeof(DateTimeOffset) || type == typeof(byte[]);
    }

    private sealed class ClockValue
    {
        public static readonly ClockValue Instance = new();
    }
}
