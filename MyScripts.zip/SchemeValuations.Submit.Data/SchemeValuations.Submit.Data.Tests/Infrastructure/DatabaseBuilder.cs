using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.SqlServer.Dac;
using Microsoft.SqlServer.Dac.Model;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>Creates the two databases under test on the same SQL Server instance.</summary>
internal static class DatabaseBuilder
{
    private const string LegacyCollation = "Latin1_General_CI_AS";

    /// <summary>
    /// Builds a dacpac from the original SSDT project (the same <c>Build</c> items the .sqlproj compiles), deploys it,
    /// then runs the project's pre- and post-deployment scripts, which load the reference data.
    /// </summary>
    public static async Task CreateLegacyDatabaseAsync(string serverConnectionString, string databaseName, string projectDirectory)
    {
        await DropDatabaseAsync(serverConnectionString, databaseName);

        var projectFile = Directory.GetFiles(projectDirectory, "*.sqlproj").Single();
        var project = XDocument.Load(projectFile);
        var items = project.Descendants().Where(e => e.Attribute("Include") is not null).ToList();
        string ItemPath(XElement item) => Path.Combine(projectDirectory, item.Attribute("Include")!.Value.Replace('\\', Path.DirectorySeparatorChar));

        using var model = new TSqlModel(SqlServerVersion.Sql160, new TSqlModelOptions { Collation = LegacyCollation });
        foreach (var item in items.Where(i => i.Name.LocalName == "Build"))
        {
            var sql = File.ReadAllText(ItemPath(item));
            if (!string.IsNullOrWhiteSpace(sql))
            {
                model.AddObjects(sql);
            }
        }

        var errors = model.Validate().Where(m => m.MessageType == DacMessageType.Error).ToList();
        if (errors.Count > 0)
        {
            throw new InvalidOperationException("The legacy database model is invalid:" + Environment.NewLine + string.Join(Environment.NewLine, errors));
        }

        using (var packageStream = new MemoryStream())
        {
            DacPackageExtensions.BuildPackage(packageStream, model, new PackageMetadata { Name = "SchemeValuations.Submit.Databases.SchemeValuation" });
            packageStream.Position = 0;
            using var package = DacPackage.Load(packageStream);
            // The project targets SQL Server 2022 (Sql160); AllowIncompatiblePlatform lets it deploy to an older
            // LocalDB. None of its objects use 2022-only features.
            new DacServices(serverConnectionString).Deploy(package, databaseName, upgradeExisting: true,
                new DacDeployOptions { CreateNewDatabase = true, AllowIncompatiblePlatform = true });
        }

        // SSDT wraps the schema deployment between these two scripts. The schema-change parts are guarded and do nothing
        // on a fresh database; the post-deployment script also loads the reference data and commits the transaction
        // the pre-deployment script opened.
        var preDeploy = SqlScript.ReadExpanded(ItemPath(items.Single(i => i.Name.LocalName == "PreDeploy")));
        var postDeploy = SqlScript.ReadExpanded(ItemPath(items.Single(i => i.Name.LocalName == "PostDeploy")));

        await using var connection = new SqlConnection(WithDatabase(serverConnectionString, databaseName));
        await connection.OpenAsync();
        await SqlScript.ExecuteAsync(connection, preDeploy + Environment.NewLine + "GO" + Environment.NewLine + postDeploy);
    }

    /// <summary>Creates the database from the EF Core migrations, as <c>dotnet ef database update</c> would.</summary>
    /// <remarks>
    /// The EF model does not set a collation, so <c>dotnet ef database update</c> would use the server default, whereas the
    /// DACPAC creates the database as Latin1_General_CI_AS (the sqlproj's DefaultCollation). The database is created
    /// up front with that collation so both sides are compared under the same string rules.
    /// </remarks>
    public static async Task CreateEfCoreDatabaseAsync(string serverConnectionString, string databaseName)
    {
        await DropDatabaseAsync(serverConnectionString, databaseName);

        await using (var connection = new SqlConnection(WithDatabase(serverConnectionString, "master")))
        {
            await connection.OpenAsync();
            await using var command = new SqlCommand($"CREATE DATABASE [{databaseName}] COLLATE {LegacyCollation}", connection);
            await command.ExecuteNonQueryAsync();
        }

        await using var db = CreateContext(WithDatabase(serverConnectionString, databaseName));
        await db.Database.MigrateAsync();
    }

    public static SchemeValuationDbContext CreateContext(string connectionString)
        => new(new DbContextOptionsBuilder<SchemeValuationDbContext>().UseSqlServer(connectionString).Options);

    public static string WithDatabase(string serverConnectionString, string databaseName)
        => new SqlConnectionStringBuilder(serverConnectionString) { InitialCatalog = databaseName }.ConnectionString;

    private static async Task DropDatabaseAsync(string serverConnectionString, string databaseName)
    {
        await using var connection = new SqlConnection(WithDatabase(serverConnectionString, "master"));
        await connection.OpenAsync();
        await using var command = new SqlCommand(
            $"""
            IF DB_ID(@name) IS NOT NULL
            BEGIN
                ALTER DATABASE [{databaseName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                DROP DATABASE [{databaseName}];
            END
            """,
            connection);
        command.Parameters.AddWithValue("@name", databaseName);
        await command.ExecuteNonQueryAsync();
    }
}
