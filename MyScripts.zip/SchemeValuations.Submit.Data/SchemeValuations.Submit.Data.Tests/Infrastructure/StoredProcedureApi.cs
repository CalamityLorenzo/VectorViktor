using System.Data;
using Microsoft.Data.SqlClient;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>Calls the original stored procedures in the legacy (DACPAC-deployed) database.</summary>
/// <param name="connectionString">The legacy database.</param>
/// <param name="onRoundTrips">If given, called after each procedure call with the number of server round trips it made.</param>
public sealed class StoredProcedureApi(string connectionString, Action<long>? onRoundTrips = null) : ISchemeValuationApi
{
    public async Task<int> CreateEventById(short eventTypeId, string? schemeValuationSubmissionId, string? userId, short eventSourceTypeId,
        int? valuationSubmissionId = null, string? transactionId = null, DateTime? notificationDate = null)
        => Required(await ExecuteAsync("dbo.usp_Create_EventById", "@EventReference",
            ("@EventTypeId", eventTypeId),
            ("@ValuationSubmissionId", valuationSubmissionId),
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@UserId", userId),
            ("@TransactionId", transactionId),
            ("@EventSourceTypeId", eventSourceTypeId),
            ("@NotificationDate", notificationDate)));

    public Task<int?> WriteCancelDocument(string? schemeValuationSubmissionId, short documentType, string userId)
        => ExecuteAsync("dbo.usp_Write_CancelDocument", "@DocumentId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@DocumentType", documentType),
            ("@UserId", userId));

    public async Task<int> WriteDocument(string? schemeValuationSubmissionId, string userId, short eventSourceType, short eventType,
        string uploadedFileName, string internalFileName, string fileHash, long? fileSize, Guid sagaUploadedFileCorrelationId,
        short documentType, short documentStatusType)
        => Required(await ExecuteAsync("dbo.usp_Write_Document", "@DocumentId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType),
            ("@EventType", eventType),
            ("@UploadedFileName", uploadedFileName),
            ("@InternalFileName", internalFileName),
            ("@FileHash", fileHash),
            ("@FileSize", fileSize),
            ("@SagaUploadedFileCorrelationId", sagaUploadedFileCorrelationId),
            ("@DocumentType", documentType),
            ("@DocumentStatusType", documentStatusType)));

    public async Task<int> WriteDocumentStatus(string schemeValuationSubmissionId, short documentStatusTypeId, int documentId,
        int? eventReference = null, string? userId = null, short? eventSourceType = null, short? eventTypeId = null)
        => Required(await ExecuteAsync("dbo.usp_Write_DocumentStatus", "@DocumentStatusId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@DocumentStatusTypeId", documentStatusTypeId),
            ("@DocumentId", documentId),
            ("@EventReference", eventReference),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType),
            ("@EventTypeId", eventTypeId)));

    public async Task<int> WriteDynamicUserJourney(string? schemeValuationSubmissionId, short fastTrackOrBespokeType, short deficitOrSurplusType,
        short additionalRequiredDocumentType, string userId, short eventSourceType, bool isMultiDocUpload = false)
        => Required(await ExecuteAsync("dbo.usp_Write_DynamicUserJourney", "@DynamicUserJourneyId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@FastTrackOrBespokeType", fastTrackOrBespokeType),
            ("@DeficitOrSurplusType", deficitOrSurplusType),
            ("@AdditionalRequiredDocumentType", additionalRequiredDocumentType),
            ("@IsMultiDocUpload", isMultiDocUpload),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType)));

    public async Task<int> WriteUserSavedSubmission(string? schemeValuationSubmissionId, string userId, short eventSourceTypeId,
        Guid lastActionPageId, string lastPageData, DateTime lastUpdated)
        => Required(await ExecuteAsync("dbo.usp_Write_UserSavedSubmission", "@UserSavedSubmissionId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@UserId", userId),
            ("@EventSourceTypeId", eventSourceTypeId),
            ("@LastActionPageId", lastActionPageId),
            ("@LastPageData", lastPageData),
            ("@LastUpdated", lastUpdated)));

    public async Task<int> WriteValuationCase(string schemeValuationSubmissionId, string caseReference, string userId, short eventType,
        short eventSourceType, DateTime? notificationDate = null)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationCase", "@ValuationCaseId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@CaseReference", caseReference),
            ("@UserId", userId),
            ("@EventType", eventType),
            ("@EventSourceType", eventSourceType),
            ("@NotificationDate", notificationDate)));

    public async Task<int> WriteValuationScheme(int psrNumber, string schemeName, int eventReference)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationScheme", "@ValuationSchemeId",
            ("@PSRNumber", psrNumber),
            ("@SchemeName", schemeName),
            ("@EventReference", eventReference)));

    public async Task<int> WriteValuationSubmission(string schemeValuationSubmissionId, int psrNumber, string schemeName, DateOnly effectiveDate,
        string userId, short eventSourceType, bool isExcludedSubmission = false)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationSubmission", "@ValuationSubmissionId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@PSRNumber", psrNumber),
            ("@SchemeName", schemeName),
            ("@EffectiveDate", effectiveDate),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType),
            ("@IsExcludedSubmission", isExcludedSubmission)));

    public async Task<int> WriteValuationSubmissionConfirmationDates(string schemeValuationSubmissionId, DateOnly dateFundingAndInvestmentStrategyWasFinalised,
        DateOnly dateStatementOfStrategyWasSigned, string userId, short eventSourceType)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationSubmissionConfirmationDates", "@ValuationSubmissionConfirmationDatesId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@DateFundingAndInvestmentStrategyWasFinalised", dateFundingAndInvestmentStrategyWasFinalised),
            ("@DateStatementOfStrategyWasSigned", dateStatementOfStrategyWasSigned),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType)));

    public async Task<int> WriteValuationSubmissionData(string questionsAndResponses, int documentId, string userId, string schemeValuationSubmissionId,
        short eventSourceType)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationSubmissionData", "@ValuationSubmissionDataId",
            ("@QuestionsAndResponses", questionsAndResponses),
            ("@DocumentId", documentId),
            ("@UserId", userId),
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@EventSourceType", eventSourceType)));

    public async Task<int> WriteValuationSubmissionGuardQuestionAnswer(string schemeValuationSubmissionId, int guardQuestionAnswerId, string userId,
        short eventSourceType, short eventType)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationSubmissionGuardQuestionAnswer", "@ValuationSubmissionGuardQuestionAnswerId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@GuardQuestionAnswerId", guardQuestionAnswerId),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType),
            ("@EventType", eventType)));

    public async Task<int> WriteValuationSubmissionStatus(string schemeValuationSubmissionId, short submissionStatusType, string userId,
        short eventSourceType = 0, short eventType = 0, int currentEventReference = 0)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationSubmissionStatus", "@ValuationSubmissionStatusId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@SubmissionStatusType", submissionStatusType),
            ("@UserId", userId),
            ("@EventSourceType", eventSourceType),
            ("@EventType", eventType),
            ("@CurrentEventReference", currentEventReference)));

    public async Task<int> WriteValuationSubmittedDetail(string? schemeValuationSubmissionId, DateTime submittedDateTime, string userId,
        short eventSourceType, short eventType = EventTypeIds.SchemeValuationSubmitted)
        => Required(await ExecuteAsync("dbo.usp_Write_ValuationSubmittedDetail", "@ValuationSubmittedDetailId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@SubmittedDateTime", submittedDateTime),
            ("@UserId", userId),
            ("@EventType", eventType),
            ("@EventSourceType", eventSourceType)));

    public async Task<ResultSet> ReadCaseReferenceData(string schemeValuationSubmissionId)
        => (await QueryAsync("dbo.usp_Read_CaseReferenceData", ordered: false, ("@SchemeValuationSubmissionId", schemeValuationSubmissionId))).Single();

    public async Task<ResultSet> ReadDocumentMetadata(string schemeValuationSubmissionId, short? submissionStatusType = null)
        => (await QueryAsync("dbo.usp_Read_DocumentMetadata", ordered: false,
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@SubmissionStatusType", submissionStatusType))).Single();

    public async Task<ResultSet> ReadDynamicUserJourney(string schemeValuationSubmissionId)
        => (await QueryAsync("dbo.usp_Read_DynamicUserJourney", ordered: false, ("@SchemeValuationSubmissionId", schemeValuationSubmissionId))).Single();

    public async Task<ResultSet> ReadIsUserSubmissionInProgress(int userSavedSubmissionId)
        => (await QueryAsync("dbo.usp_Read_IsUserSubmissionInProgress", ordered: false, ("@UserSavedSubmissionId", userSavedSubmissionId))).Single();

    public async Task<bool> ReadPsrHasUserSubmissionInProgress(int psrNumber)
    {
        // For PSR 0 the procedure returns without a result set, which callers treat as "no".
        var results = await QueryAsync("dbo.usp_Read_PsrHasUserSubmissionInProgress", ordered: false, ("@PsrNumber", psrNumber));
        return results.Count == 1 && Convert.ToInt32(results[0].Rows.Single()[0]) == 1;
    }

    public async Task<ResultSet> ReadSubmission(string schemeValuationSubmissionId, short? submissionStatusTypeId = null)
        => (await QueryAsync("dbo.usp_Read_Submission", ordered: false,
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId),
            ("@SubmissionStatusTypeId", submissionStatusTypeId))).Single();

    public async Task<ResultSet> ReadSubmittedSubmission(string schemeValuationSubmissionId)
        => (await QueryAsync("dbo.usp_Read_SubmittedSubmission", ordered: false, ("@SchemeValuationSubmissionId", schemeValuationSubmissionId))).Single();

    public async Task<ResultSet> ReadUserSavedAndValuationSubmission(int psrNumber)
        => (await QueryAsync("dbo.usp_Read_UserSavedAndValuationSubmission", ordered: true, ("@PsrNumber", psrNumber))).Single();

    public async Task<ResultSet> ReadUserSavedSubmission(int psrNumber)
        => (await QueryAsync("dbo.usp_Read_UserSavedSubmission", ordered: true, ("@PsrNumber", psrNumber))).Single();

    public async Task<int> ReadValuationSubmissionId(string? schemeValuationSubmissionId)
        => Required(await ExecuteAsync("dbo.usp_Read_ValuationSubmissionId", "@ValuationSubmissionId",
            ("@SchemeValuationSubmissionId", schemeValuationSubmissionId)));

    public async Task<ResultSet[]> ReportRecentSubmissionsByDate(DateOnly createdDate)
        => [.. await QueryAsync("dbo.usp_Report_Recent_Submissions_By_Date", ordered: false, ("@CreatedDate", createdDate))];

    private static int Required(int? output)
        => output ?? throw new InvalidOperationException("The procedure completed but its OUTPUT parameter was NULL.");

    private async Task<int?> ExecuteAsync(string procedure, string outputParameter, params (string Name, object? Value)[] parameters)
    {
        await using var connection = await OpenAsync();
        await using var command = CreateCommand(connection, procedure, parameters);
        var output = command.Parameters.Add(outputParameter, SqlDbType.Int);
        output.Direction = ParameterDirection.Output;

        try
        {
            await command.ExecuteNonQueryAsync();
        }
        finally
        {
            ReportRoundTrips(connection);
        }

        return output.Value is DBNull ? null : (int)output.Value;
    }

    private async Task<List<ResultSet>> QueryAsync(string procedure, bool ordered, params (string Name, object? Value)[] parameters)
    {
        await using var connection = await OpenAsync();
        await using var command = CreateCommand(connection, procedure, parameters);
        var results = new List<ResultSet>();
        try
        {
            await using var reader = await command.ExecuteReaderAsync();
            do
            {
                if (reader.FieldCount > 0)
                {
                    results.Add(await ResultSet.FromReaderAsync(reader, ordered));
                }
            }
            while (await reader.NextResultAsync());
        }
        finally
        {
            ReportRoundTrips(connection);
        }

        return results;
    }

    private async Task<SqlConnection> OpenAsync()
    {
        var connection = new SqlConnection(connectionString) { StatisticsEnabled = onRoundTrips is not null };
        await connection.OpenAsync();
        return connection;
    }

    private void ReportRoundTrips(SqlConnection connection)
        => onRoundTrips?.Invoke((long)connection.RetrieveStatistics()["ServerRoundtrips"]!);

    private static SqlCommand CreateCommand(SqlConnection connection, string procedure, (string Name, object? Value)[] parameters)
    {
        var command = new SqlCommand(procedure, connection) { CommandType = CommandType.StoredProcedure };
        foreach (var (name, value) in parameters)
        {
            var parameter = command.Parameters.AddWithValue(name, value ?? DBNull.Value);
            switch (value)
            {
                case DateTime:
                    parameter.SqlDbType = SqlDbType.DateTime2;
                    break;
                case DateOnly date:
                    parameter.SqlDbType = SqlDbType.Date;
                    parameter.Value = date.ToDateTime(TimeOnly.MinValue);
                    break;
            }
        }

        return command;
    }
}
