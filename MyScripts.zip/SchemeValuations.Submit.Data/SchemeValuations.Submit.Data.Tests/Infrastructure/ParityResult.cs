using System.Text;

namespace SchemeValuations.Submit.Data.Tests.Infrastructure;

/// <summary>The outcome of one scenario run against both implementations.</summary>
public sealed class ParityResult(Transcript legacy, Transcript efCore, DatabaseSnapshot legacyDatabase, DatabaseSnapshot efCoreDatabase)
{
    public Transcript Legacy { get; } = legacy;

    public Transcript EfCore { get; } = efCore;

    public DatabaseSnapshot LegacyDatabase { get; } = legacyDatabase;

    public DatabaseSnapshot EfCoreDatabase { get; } = efCoreDatabase;

    /// <summary>
    /// Asserts that every call returned the same value (or failed with the same message), and that afterwards every
    /// table in both databases holds exactly the same rows, identity values included.
    /// </summary>
    public void AssertIdentical() => AssertIdenticalExcept([], []);

    /// <summary>As <see cref="AssertIdentical"/>, but ignoring the named steps and tables, which the caller asserts separately.</summary>
    public void AssertIdenticalExcept(string[] steps, string[] tables)
    {
        var report = new StringBuilder();

        if (!Legacy.Entries.Select(e => e.Step).SequenceEqual(EfCore.Entries.Select(e => e.Step)))
        {
            report.AppendLine("The two runs did not execute the same steps.");
        }

        foreach (var (step, legacyOutcome, efCoreOutcome) in Legacy.Entries.Zip(EfCore.Entries, (l, e) => (l.Step, l.Outcome, e.Outcome)))
        {
            if (!steps.Contains(step) && legacyOutcome != efCoreOutcome)
            {
                report.AppendLine($"Step \"{step}\" differs.")
                    .AppendLine($"  stored procedure: {legacyOutcome}")
                    .AppendLine($"  EF Core:          {efCoreOutcome}");
            }
        }

        foreach (var table in LegacyDatabase.Tables.Keys.Union(EfCoreDatabase.Tables.Keys, StringComparer.OrdinalIgnoreCase))
        {
            if (tables.Contains(table, StringComparer.OrdinalIgnoreCase))
            {
                continue;
            }

            var legacyRows = LegacyDatabase.Tables.GetValueOrDefault(table)?.ToString();
            var efCoreRows = EfCoreDatabase.Tables.GetValueOrDefault(table)?.ToString();
            if (legacyRows != efCoreRows)
            {
                report.AppendLine($"Table {table} differs.")
                    .AppendLine("  stored procedure:").AppendLine(legacyRows ?? "  (table missing)")
                    .AppendLine("  EF Core:").AppendLine(efCoreRows ?? "  (table missing)");
            }
        }

        if (report.Length > 0)
        {
            Assert.Fail(report.AppendLine().AppendLine("Stored procedure transcript:").AppendLine(Legacy.ToString()).ToString());
        }
    }
}
