﻿/*
Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be prepended to the build script.		
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

PRINT 'BEGIN TRANSACTION DeploymentEndToEnd with rollback on error'
SET XACT_ABORT ON;
BEGIN TRANSACTION DeploymentEndToEnd

PRINT('Running pre-deployment scripts...');
GO

:r .\SchemaChanges\Script.SchemaChangesPreDeployment.sql

