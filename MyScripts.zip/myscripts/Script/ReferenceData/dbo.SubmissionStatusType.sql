﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.SubmissionStatusType';
GO

-- insert required values into temp table

DROP TABLE IF EXISTS #SubmissionStatusType;

SELECT 
    SubmissionStatusTypeId,
    SubmissionStatusName,
    SubmissionStatusDescription,
    IsActive
INTO 
    #SubmissionStatusType
FROM (
    VALUES
        (1, 'IN_PROGRESS', 'In progress', 1),
        (2, 'SUBMITTED', 'Submitted', 1),
        (3, 'CANCELLED', 'Cancelled', 1),
        (4, 'SUPERSEDED', 'Superseded', 1)  
    ) x
        (  
        SubmissionStatusTypeId,
        SubmissionStatusName,
        SubmissionStatusDescription,
        IsActive
        );

-- UPDATE any required rows in dbo.SubmissionStatusType

UPDATE s
SET  
    SubmissionStatusName = temp.SubmissionStatusName,
    SubmissionStatusDescription = temp.SubmissionStatusDescription,
    IsActive = temp.IsActive
FROM 
    #SubmissionStatusType temp
JOIN 
    dbo.SubmissionStatusType s
ON 
   s.SubmissionStatusTypeId = temp.SubmissionStatusTypeId
WHERE 
    (
    temp.SubmissionStatusName <> s.SubmissionStatusName
    OR temp.SubmissionStatusDescription COLLATE Latin1_General_100_CS_AI <> s.SubmissionStatusDescription COLLATE Latin1_General_100_CS_AI
    OR temp.IsActive <> s.IsActive
    );

-- INSERT any new rows into dbo.SubmissionStatusType

INSERT INTO dbo.SubmissionStatusType 
    (
        SubmissionStatusTypeId,
        SubmissionStatusName,
        SubmissionStatusDescription,
        IsActive
    )
    SELECT 
        SubmissionStatusTypeId,
        SubmissionStatusName,
        SubmissionStatusDescription,
        IsActive
    FROM 
        #SubmissionStatusType
EXCEPT
    SELECT   
        SubmissionStatusTypeId,
        SubmissionStatusName,
        SubmissionStatusDescription,
        IsActive
    FROM 
        dbo.SubmissionStatusType;

GO

