﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.GuardQuestionAnswer';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #GuardQuestionAnswer;

SELECT 
    GuardQuestionAnswerId,
    GuardQuestionId,
    GuardAnswerName,
    GuardAnswerDescription
INTO 
    #GuardQuestionAnswer
FROM 
(
    VALUES
        (1, 1, 'DEFICIT', 'The scheme is in deficit'), 
        (2, 1, 'SURPLUS', 'The scheme is in surplus')
) AS x
(
    GuardQuestionAnswerId,
    GuardQuestionId,
    GuardAnswerName,
    GuardAnswerDescription
);

-- UPDATE any required rows in dbo.GuardQuestionAnswer

UPDATE gqa
SET  
    GuardAnswerName = temp.GuardAnswerName,
    GuardAnswerDescription = temp.GuardAnswerDescription
FROM 
    #GuardQuestionAnswer temp
JOIN 
    dbo.GuardQuestionAnswer gqa
ON 
    gqa.GuardQuestionAnswerId = temp.GuardQuestionAnswerId
    AND gqa.GuardQuestionId = temp.GuardQuestionId
WHERE 
    (
        temp.GuardAnswerName <> gqa.GuardAnswerName
        OR temp.GuardAnswerDescription <> gqa.GuardAnswerDescription
    );

-- INSERT any new rows into dbo.GuardQuestionAnswer

INSERT INTO dbo.GuardQuestionAnswer 
(
    GuardQuestionAnswerId,
    GuardQuestionId,
    GuardAnswerName,
    GuardAnswerDescription
)
    SELECT 
        GuardQuestionAnswerId,
        GuardQuestionId,
        GuardAnswerName,
        GuardAnswerDescription
    FROM 
        #GuardQuestionAnswer
EXCEPT
    SELECT   
        GuardQuestionAnswerId,
        GuardQuestionId,
        GuardAnswerName,
        GuardAnswerDescription
    FROM 
        dbo.GuardQuestionAnswer;

GO