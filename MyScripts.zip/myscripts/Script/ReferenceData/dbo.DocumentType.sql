﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.DocumentType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #DocumentType;

SELECT 
    DocumentTypeId,
    DocumentTypeName,
    DocumentTypeDescription,
    IsActive
INTO 
    #DocumentType
FROM 
(
    VALUES
        (1, 'COMBINED_VALUATION_RECOVERY_CONTRIBUTIONS_SCHEDULE', 'Actuarial valuation, recovery plan and schedule of contributions', 1), 
        (2, 'STATEMENT_OF_STRATEGY', 'Statement of strategy', 1),
        (3, 'ACTUARIAL_VALUATION', 'Actuarial valuation', 1),
        (4, 'MAXIMUM_AFFORDABLE_CONTRIBUTIONS', 'Trustees'' analysis of maximum affordable contributions', 1),
        (5, 'ASSESSMENT_OF_SUPPORTABLE_RISK', 'Assessment of supportable risk over the reliabilityperiod',1)
) AS x
(
    DocumentTypeId,
    DocumentTypeName,
    DocumentTypeDescription,
    IsActive
);

-- UPDATE any required rows in dbo.DocumentType

UPDATE target
SET  
    DocumentTypeName = temp.DocumentTypeName,
    DocumentTypeDescription = temp.DocumentTypeDescription,
    IsActive = temp.IsActive
FROM 
    #DocumentType temp
JOIN 
    dbo.DocumentType target
ON 
    target.DocumentTypeId = temp.DocumentTypeId
WHERE 
    (
        temp.DocumentTypeName <> target.DocumentTypeName
        OR temp.DocumentTypeDescription <> target.DocumentTypeDescription
        OR temp.IsActive <> target.IsActive
    );

-- INSERT any new rows into dbo.DocumentType

INSERT INTO dbo.DocumentType 
(
    DocumentTypeId,
    DocumentTypeName,
    DocumentTypeDescription,
    IsActive
)
    SELECT 
        DocumentTypeId,
        DocumentTypeName,
        DocumentTypeDescription,
        IsActive
    FROM 
        #DocumentType
EXCEPT
    SELECT   
        DocumentTypeId,
        DocumentTypeName,
        DocumentTypeDescription,
        IsActive
    FROM 
        dbo.DocumentType;

GO
