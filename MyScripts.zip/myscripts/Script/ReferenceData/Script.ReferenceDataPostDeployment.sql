﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
:r .\dbo.AdditionalRequiredDocumentType.sql
:r .\dbo.FastTrackOrBespokeType.sql
:r .\dbo.DeficitOrSurplusType.sql
:r .\dbo.DocumentType.sql
:r .\dbo.DocumentStatusType.sql
:r .\dbo.EventType.sql
:r .\dbo.EventSourceType.sql
:r .\dbo.GuardQuestion.sql
:r .\dbo.GuardQuestionAnswer.sql
:r .\dbo.SubmissionStatusType.sql