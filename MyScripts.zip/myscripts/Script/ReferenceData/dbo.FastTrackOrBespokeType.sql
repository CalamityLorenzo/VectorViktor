﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.FastTrackOrBespokeType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #FastTrackOrBespokeType;

SELECT 
    FastTrackOrBespokeTypeId,
    FastTrackOrBespokeName,
    FastTrackOrBespokeDescription,
    IsActive
INTO 
    #FastTrackOrBespokeType
FROM 
(
    VALUES
        (0, 'FAST_TRACK', 'Fast-tracked valuation', 1), 
        (1, 'BESPOKE', 'Bespoke valuation', 1)
) AS x
(
    FastTrackOrBespokeTypeId,
    FastTrackOrBespokeName,
    FastTrackOrBespokeDescription,
    IsActive
);

-- UPDATE any required rows in dbo.FastTrackOrBespokeType

UPDATE target
SET  
    FastTrackOrBespokeName = temp.FastTrackOrBespokeName,
    FastTrackOrBespokeDescription = temp.FastTrackOrBespokeDescription,
    IsActive = temp.IsActive
FROM 
    #FastTrackOrBespokeType temp
JOIN 
    dbo.FastTrackOrBespokeType target
ON 
    target.FastTrackOrBespokeTypeId = temp.FastTrackOrBespokeTypeId
WHERE 
    (
        temp.FastTrackOrBespokeName <> target.FastTrackOrBespokeName
        OR temp.FastTrackOrBespokeDescription <> target.FastTrackOrBespokeDescription
        OR temp.IsActive <> target.IsActive
    );

-- INSERT any new rows into dbo.FastTrackOrBespokeType

INSERT INTO dbo.FastTrackOrBespokeType 
(
    FastTrackOrBespokeTypeId,
    FastTrackOrBespokeName,
    FastTrackOrBespokeDescription,
    IsActive
)
    SELECT 
        FastTrackOrBespokeTypeId,
        FastTrackOrBespokeName,
        FastTrackOrBespokeDescription,
        IsActive
    FROM 
        #FastTrackOrBespokeType
EXCEPT
    SELECT   
        FastTrackOrBespokeTypeId,
        FastTrackOrBespokeName,
        FastTrackOrBespokeDescription,
        IsActive
    FROM 
        dbo.FastTrackOrBespokeType;

GO
