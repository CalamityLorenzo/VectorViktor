﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.EventSourceType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #EventSourceType;

SELECT 
    EventSourceTypeId,
    EventSourceName,
    EventSourceDescription,
    IsActive
INTO 
    #EventSourceType
FROM 
(
    VALUES
        (1, 'Scheme Valuation Submission', 'Submit your Scheme Valuation application', 1), 
        (2, 'Scheme Valuation Submission Event Messaging', 'Submit your Scheme Valuation - event messaging', 1),
        (3, 'IT Database change - End-event cancelled status (simultaneous submissions)', 'IT Database change - end-date ValuationSubmissionStatus - simultaneous submission scenario', 1), 
        (4, 'IT Database change - supersede cancelled & end-dated submitted submissions', 'IT Database change - superseding automatically cancelled submissions (if previously submitted)', 1),
        (5, 'IT Database change - populate historical submitted dates', 'IT Database change - populate historical submitted dates in dbo.SubmittedDetail', 1)

) AS x
(
    EventSourceTypeId,
    EventSourceName,
    EventSourceDescription,
    IsActive
);

-- UPDATE any required rows in dbo.EventSourceType

UPDATE e
SET  
    EventSourceName = temp.EventSourceName,
    EventSourceDescription = temp.EventSourceDescription,
    IsActive = temp.IsActive
FROM 
    #EventSourceType temp
JOIN 
    dbo.EventSourceType e
ON 
    e.EventSourceTypeId = temp.EventSourceTypeId
WHERE 
    (
        temp.EventSourceName <> e.EventSourceName
        OR temp.EventSourceDescription <> e.EventSourceDescription
        OR temp.IsActive <> e.IsActive
    );

-- INSERT any new rows into dbo.EventSourceType

INSERT INTO dbo.EventSourceType 
(
    EventSourceTypeId,
    EventSourceName,
    EventSourceDescription,
    IsActive
)
    SELECT 
        EventSourceTypeId,
        EventSourceName,
        EventSourceDescription,
        IsActive
    FROM 
        #EventSourceType
EXCEPT
    SELECT   
        EventSourceTypeId,
        EventSourceName,
        EventSourceDescription,
        IsActive
    FROM 
        dbo.EventSourceType;

GO
