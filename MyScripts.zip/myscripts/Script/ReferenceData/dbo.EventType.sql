﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.EventType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #EventType;

SELECT 
    EventTypeId,
    EventTypeName,
    EventTypeDescription,
    IsActive
INTO 
    #EventType
FROM 
(
    VALUES
        (1, 'SCHEME_VALUATION_SUBMISSION_STARTED', 'A new scheme valuation submission has been started', 1),
        (2, 'SCHEME_IN_DEFICIT_GUARD_QUESTION_ANSWERED', 'The is scheme in deficit guard question has been answered', 1),
        (3, 'STATEMENT_OF_STRATEGY_UPLOADED', 'The statement of strategy document has been uploaded', 1),
        (4, 'ACTUARIAL_VALUATION_UPLOADED', 'The actuarial valuation document has been uploaded', 1),
        (5, 'COMBINED_VALUATION_RECOVERY_CONTRIBUTIONS_SCHEDULE', 'The combined document containing actuarial valuation, recovery document and statement of contributions has been uploaded', 1),
        (6, 'SCHEME_VALUATION_SUBMITTED', 'Scheme valuation has been submitted', 1), 
        (7, 'CASE_REFERENCE_RECEIVED', 'Case reference received', 1),
        (8, 'MAXIMUM_AFFORDABLE_CONTRIBUTIONS_UPLOADED', 'The trustees'' analysis of maximum affordable contributions document has been uploaded', 1),
        (9, 'ASSESSMENT_OF_SUPPORTABLE_RISK_OVER_THE_RELIABILITY_PERIOD_UPLOADED', 'Assessment of supportable risk over the reliability period uploaded', 1),
        (10, 'STATEMENT_OF_STRATEGY_EXTRACTED', 'Statement of strategy extracted', 1),
        (11, 'CONFIRMATION_DATES_ADDED', 'Confirmation dates were added', 1),
        (12, 'SCHEME_VALUATION_SUPERSEDED', 'A scheme valuation was superseded by a submission with the same PSR and effective date', 1),
        (13, 'USER_UPLOADED_DOCUMENT_CANCELLED', 'A previoulsy uploaded document has been cancelled', 1),
        (14, 'USER_SAVED_SUBMISSION', 'The current submission has been saved as a draft, before submission', 1),
        (15, 'USER_CHANGED_SUBMISSION_STATUS', 'The submission status has been superseded by a user action', 1),
        (16, 'DYNAMIC_USER_JOURNEY_SAVED', 'The dynamic user journey has been saved', 1),
        (17, 'SPECIAL_UPDATE', 'Special database update', 1)
) AS x
(
    EventTypeId,
    EventTypeName,
    EventTypeDescription,
    IsActive
);

-- UPDATE any required rows in dbo.EventType

UPDATE e
SET  
    EventTypeName = temp.EventTypeName,
    EventTypeDescription = temp.EventTypeDescription,
    IsActive = temp.IsActive
FROM 
    #EventType temp
JOIN 
    dbo.EventType e
ON 
    e.EventTypeId = temp.EventTypeId
WHERE 
    (
        temp.EventTypeName <> e.EventTypeName
        OR temp.EventTypeDescription <> e.EventTypeDescription
        OR temp.IsActive <> e.IsActive
    );

-- INSERT any new rows into dbo.EventType

INSERT INTO dbo.EventType 
(
    EventTypeId,
    EventTypeName,
    EventTypeDescription,
    IsActive
)
    SELECT 
        EventTypeId,
        EventTypeName,
        EventTypeDescription,
        IsActive
    FROM 
        #EventType
EXCEPT
    SELECT   
        EventTypeId,
        EventTypeName,
        EventTypeDescription,
        IsActive
    FROM 
        dbo.EventType;

GO
