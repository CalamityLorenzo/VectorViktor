﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.GuardQuestion';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #GuardQuestion;

SELECT 
    GuardQuestionId,
    GuardQuestionName,
    GuardQuestionDescription,
    IsActive
INTO 
    #GuardQuestion
FROM 
(
    VALUES
        (1, 
        'IS_SCHEME_IN_DEFICIT', 
        'At the effective date was the scheme in deficit on a technical provisions basis?', 
        1)
) AS x
(
    GuardQuestionId,
    GuardQuestionName,
    GuardQuestionDescription,
    IsActive
);

-- UPDATE any required rows in dbo.GuardQuestion

UPDATE g
SET  
    GuardQuestionName = temp.GuardQuestionName,
    GuardQuestionDescription = temp.GuardQuestionDescription,
    IsActive = temp.IsActive
FROM 
    #GuardQuestion temp
JOIN 
    dbo.GuardQuestion g
ON 
    g.GuardQuestionId = temp.GuardQuestionId
WHERE 
    (
        temp.GuardQuestionName <> g.GuardQuestionName
        OR temp.GuardQuestionDescription <> g.GuardQuestionDescription
        OR temp.IsActive <> g.IsActive
    );

-- INSERT any new rows into dbo.GuardQuestion

    INSERT INTO dbo.GuardQuestion 
    (
        GuardQuestionId,
        GuardQuestionName,
        GuardQuestionDescription,
        IsActive
    )
    SELECT 
        GuardQuestionId,
        GuardQuestionName,
        GuardQuestionDescription,
        IsActive
    FROM 
        #GuardQuestion
EXCEPT
    SELECT   
        GuardQuestionId,
        GuardQuestionName,
        GuardQuestionDescription,
        IsActive
    FROM 
        dbo.GuardQuestion;

GO


