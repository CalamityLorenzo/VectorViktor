﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.AdditionalRequiredDocumentType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #AdditionalRequiredDocumentType;

SELECT 
    [AdditionalRequiredDocumentTypeId],
    [AdditionalRequiredDocumentName],
    [AdditionalRequiredDocumentDescription],
    [IsActive]
INTO 
    #AdditionalRequiredDocumentType
FROM 
(
    VALUES
        (0, 'NONE', 'No additional document is required', 1),
        (1, 'MAXIMUM_AFFORDABLE_CONTRIBUTIONS', 'Trustees'' analysis of maximum affordable contributions is required - SASV-00184', 1),
        (2, 'ASSESSMENT_OF_SUPPORTABLE_RISK', 'Assessment of supportable risk over the reliabilityperiod is required - SASV-00185', 1)
) AS x
(
    AdditionalRequiredDocumentTypeId,
    AdditionalRequiredDocumentName,
    AdditionalRequiredDocumentDescription,
    IsActive
);

-- UPDATE any required rows in dbo.AdditionalRequiredDocumentType

UPDATE target
SET  
    AdditionalRequiredDocumentName = temp.AdditionalRequiredDocumentName,
    AdditionalRequiredDocumentDescription = temp.AdditionalRequiredDocumentDescription,
    IsActive = temp.IsActive
FROM 
    #AdditionalRequiredDocumentType temp
JOIN 
    dbo.AdditionalRequiredDocumentType target
ON 
    target.AdditionalRequiredDocumentTypeId = temp.AdditionalRequiredDocumentTypeId
WHERE 
    (
        temp.AdditionalRequiredDocumentName <> target.AdditionalRequiredDocumentName
        OR temp.AdditionalRequiredDocumentDescription <> target.AdditionalRequiredDocumentDescription
        OR temp.IsActive <> target.IsActive
    );

-- INSERT any new rows into dbo.AdditionalRequiredDocumentType

INSERT INTO dbo.AdditionalRequiredDocumentType 
(
    AdditionalRequiredDocumentTypeId,
    AdditionalRequiredDocumentName,
    AdditionalRequiredDocumentDescription,
    IsActive
)
    SELECT 
        AdditionalRequiredDocumentTypeId,
        AdditionalRequiredDocumentName,
        AdditionalRequiredDocumentDescription,
        IsActive
    FROM 
        #AdditionalRequiredDocumentType
EXCEPT
    SELECT   
        AdditionalRequiredDocumentTypeId,
        AdditionalRequiredDocumentName,
        AdditionalRequiredDocumentDescription,
        IsActive
    FROM 
        dbo.AdditionalRequiredDocumentType;

GO
