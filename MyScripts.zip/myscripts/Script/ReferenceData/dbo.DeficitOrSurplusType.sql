﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.DeficitOrSurplusType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #DeficitOrSurplusType;

SELECT 
    DeficitOrSurplusTypeId,
    DeficitOrSurplusName,
    DeficitOrSurplusDescription,
    IsActive
INTO 
    #DeficitOrSurplusType
FROM 
(
    VALUES
        (1, 'DEFICIT', 'Scheme is in deficit', 1), 
        (2, 'SURPLUS', 'Scheme is in surplus', 1)
) AS x
(
    DeficitOrSurplusTypeId,
    DeficitOrSurplusName,
    DeficitOrSurplusDescription,
    IsActive
);

-- UPDATE any required rows in dbo.DeficitOrSurplusType

UPDATE target
SET  
    DeficitOrSurplusName = temp.DeficitOrSurplusName,
    DeficitOrSurplusDescription = temp.DeficitOrSurplusDescription,
    IsActive = temp.IsActive
FROM 
    #DeficitOrSurplusType temp
JOIN 
    dbo.DeficitOrSurplusType target
ON 
    target.DeficitOrSurplusTypeId = temp.DeficitOrSurplusTypeId
WHERE 
    (
        temp.DeficitOrSurplusName <> target.DeficitOrSurplusName
        OR temp.DeficitOrSurplusDescription <> target.DeficitOrSurplusDescription
        OR temp.IsActive <> target.IsActive
    );

-- INSERT any new rows into dbo.DeficitOrSurplusType

INSERT INTO dbo.DeficitOrSurplusType 
(
    DeficitOrSurplusTypeId,
    DeficitOrSurplusName,
    DeficitOrSurplusDescription,
    IsActive
)
    SELECT 
        DeficitOrSurplusTypeId,
        DeficitOrSurplusName,
        DeficitOrSurplusDescription,
        IsActive
    FROM 
        #DeficitOrSurplusType
EXCEPT
    SELECT   
        DeficitOrSurplusTypeId,
        DeficitOrSurplusName,
        DeficitOrSurplusDescription,
        IsActive
    FROM 
        dbo.DeficitOrSurplusType;

GO
