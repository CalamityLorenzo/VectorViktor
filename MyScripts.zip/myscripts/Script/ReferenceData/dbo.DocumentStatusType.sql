﻿-------------------------------------------------------
PRINT 'INSERT INTO dbo.DocumentStatusType';
GO

-- Insert required values into temp table

DROP TABLE IF EXISTS #DocumentStatusType;

SELECT 
    DocumentStatusTypeId,
    DocumentStatusName,
    DocumentStatusDescription,
    IsActive
INTO 
    #DocumentStatusType
FROM 
(
    VALUES
        (1, 'VIRUS_SCAN_SUCCESSFUL', 'Document virus scan was successful', 1),
        (2, 'VIRUS_SCAN_FAILED', 'Document virus scan failed', 1)
) AS x
(
    DocumentStatusTypeId,
    DocumentStatusName,
    DocumentStatusDescription,
    IsActive
);

-- UPDATE any required rows in dbo.DocumentStatusType

UPDATE d
SET  
    DocumentStatusName = temp.DocumentStatusName,
    DocumentStatusDescription = temp.DocumentStatusDescription,
    IsActive = temp.IsActive
FROM 
    #DocumentStatusType temp
JOIN 
    dbo.DocumentStatusType d
ON 
    d.DocumentStatusTypeId = temp.DocumentStatusTypeId
WHERE 
    (
        temp.DocumentStatusName <> d.DocumentStatusName
        OR temp.DocumentStatusDescription <> d.DocumentStatusDescription
        OR temp.IsActive <> d.IsActive
    );

-- INSERT any new rows into dbo.DocumentStatusType

INSERT INTO dbo.DocumentStatusType 
(
    DocumentStatusTypeId,
    DocumentStatusName,
    DocumentStatusDescription,
    IsActive
)
    SELECT 
        DocumentStatusTypeId,
        DocumentStatusName,
        DocumentStatusDescription,
        IsActive
    FROM 
        #DocumentStatusType
EXCEPT
    SELECT   
        DocumentStatusTypeId,
        DocumentStatusName,
        DocumentStatusDescription,
        IsActive
    FROM 
        dbo.DocumentStatusType;

GO
