﻿IF COL_LENGTH('dbo.[ValuationSubmission]', 'TrancheId') IS NOT NULL AND OBJECT_ID('TempDb..#DeleteTrancheIdFromValuationSubmission') IS NULL
BEGIN
	PRINT 'Backing up data from [dbo].[ValuationSubmission] into #DeleteTrancheIdFromValuationSubmission'
    SELECT *
    INTO #DeleteTrancheIdFromValuationSubmission
    FROM [dbo].[ValuationSubmission]

    PRINT 'Disabling constraints connected to [dbo].[ValuationSubmission]'
    ALTER TABLE [dbo].[Document] 
    NOCHECK CONSTRAINT [FK_Document_ValuationSubmission]

    ALTER TABLE [dbo].[Event] 
    NOCHECK CONSTRAINT [FK_Event_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationCase] 
    NOCHECK CONSTRAINT [FK_ValuationCase_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationSubmissionGuardQuestionAnswer] 
    NOCHECK CONSTRAINT [FK_ValuationSubmissionGuardQuestionAnswer_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationSubmissionStatus] 
    NOCHECK CONSTRAINT [FK_ValuationSubmissionStatus_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationSubmissionConfirmationDates]
    NOCHECK CONSTRAINT [FK_ValuationSubmissionConfirmationDates_ValuationSubmission]
    
    PRINT 'DELETE data from [dbo].[ValuationSubmission]'
    WHILE EXISTS (SELECT 1 FROM [dbo].[ValuationSubmission])
    BEGIN
        DELETE TOP(5000) from [dbo].[ValuationSubmission]
    END
END