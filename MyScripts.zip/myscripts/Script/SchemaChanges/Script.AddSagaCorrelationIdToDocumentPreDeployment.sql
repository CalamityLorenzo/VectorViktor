IF COL_LENGTH('dbo.[Document]', 'SagaUploadedFileCorrelationId') IS NULL
    AND OBJECT_ID('TempDb..#AddSagaCorrelationIdToDocument') IS NULL
    AND OBJECT_ID('[dbo].[Document]') IS NOT NULL
BEGIN
    PRINT 'Backing up data from [dbo].[Document] into #AddSagaCorrelationIdToDocument'

    SELECT *
    INTO #AddSagaCorrelationIdToDocument
    FROM [dbo].[Document]

    PRINT 'Disabling constraints connected to [dbo].[Document]'

    ALTER TABLE [dbo].[Document]
    NOCHECK CONSTRAINT [FK_Document_DocumentType]

    ALTER TABLE [dbo].[Document]
    NOCHECK CONSTRAINT [FK_Document_ValuationSubmission]

    ALTER TABLE [dbo].[Document]
    NOCHECK CONSTRAINT [FK_Document_Event_Start]

    ALTER TABLE [dbo].[Document]
    NOCHECK CONSTRAINT [FK_Document_Event_End]

    ALTER TABLE [dbo].[DocumentStatus]
    NOCHECK CONSTRAINT [FK_DocumentStatus_Document]

    ALTER TABLE [dbo].[ValuationSubmissionData]
    NOCHECK CONSTRAINT [FK_ValuationSubmissionData_Document]

    PRINT 'DELETE data from [dbo].[Document]'

    WHILE EXISTS (SELECT 1 FROM [dbo].[Document])
    BEGIN
        PRINT 'DELETING NEXT TOP 1000 rows from Document'
        DELETE TOP(1000) FROM [dbo].[Document]
        PRINT 'DELETED TOP 1000 rows from Document'
    END

    PRINT 'FINISHED dbo.[Document] DELETION'
END