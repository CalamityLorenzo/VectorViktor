IF COL_LENGTH('dbo.[Document]', 'SagaUploadedFileCorrelationId') IS NOT NULL
    AND OBJECT_ID('TempDb..#AddSagaCorrelationIdToDocument') IS NOT NULL
BEGIN

    PRINT 'Restoring data to [dbo].[Document]'
    SET IDENTITY_INSERT [dbo].[Document] ON;

    INSERT dbo.[Document](
         [DocumentId]
        ,[ValuationSubmissionId]
        ,[UploadedFileName]
        ,[InternalFileName]
        ,[FileHash]
        ,[FileSize]
        ,[DocumentTypeId]
        ,[StartEventReference]
        ,[EndEventReference]
    )
    SELECT
         [DocumentId]
        ,[ValuationSubmissionId]
        ,[UploadedFileName]
        ,[InternalFileName]
        ,[FileHash]
        ,[FileSize]
        ,[DocumentTypeId]
        ,[StartEventReference]
        ,[EndEventReference]
    FROM #AddSagaCorrelationIdToDocument

    SET IDENTITY_INSERT [dbo].[Document] OFF;

    PRINT 'Restoring constraints connected to [dbo].[Document]'

    ALTER TABLE [dbo].[Document]
    CHECK CONSTRAINT [FK_Document_DocumentType]

    ALTER TABLE [dbo].[Document]
    CHECK CONSTRAINT [FK_Document_ValuationSubmission]

    ALTER TABLE [dbo].[Document]
    CHECK CONSTRAINT [FK_Document_Event_Start]

    ALTER TABLE [dbo].[Document]
    CHECK CONSTRAINT [FK_Document_Event_End]

    ALTER TABLE [dbo].[DocumentStatus]
    CHECK CONSTRAINT [FK_DocumentStatus_Document]

    ALTER TABLE [dbo].[ValuationSubmissionData]
    CHECK CONSTRAINT [FK_ValuationSubmissionData_Document]

    DROP TABLE #AddSagaCorrelationIdToDocument;
END