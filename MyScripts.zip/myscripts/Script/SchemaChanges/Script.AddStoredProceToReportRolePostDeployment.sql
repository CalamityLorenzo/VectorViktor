﻿/*
Add your newly created report stored procedure to the db_reportreader role
So it can be picked up by the reporting account.
*/

IF EXISTS(SELECT 1 AS RoleName FROM sys.database_principals WHERE type = 'R' AND name = 'db_reportreader')
BEGIN
    IF NOT EXISTS(SELECT  1
                            FROM 
                                sys.database_permissions perm
                                JOIN sys.database_principals dp ON perm.grantee_principal_id = dp.principal_id
                                JOIN sys.objects obj ON perm.major_id = obj.object_id
                            WHERE 
                                obj.name = 'usp_Report_Recent_Submissions_By_Date'
                                AND perm.permission_name = 'EXECUTE'
                                AND dp.type = 'R'
                                AND dp.name = 'db_reportreader')
        BEGIN
            PRINT 'Adding EXECUTE permission on [dbo].[usp_Report_Recent_Submissions_By_Date] to db_reportreader role';
            GRANT EXECUTE ON OBJECT::[dbo].[usp_Report_Recent_Submissions_By_Date] TO [db_reportreader];
        END
END