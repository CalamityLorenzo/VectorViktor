﻿IF COL_LENGTH('dbo.[UserSavedSubmission]', 'UserSavedSubmissionStatusTypeId') IS NOT NULL
	BEGIN
		PRINT 'Deleting from table dbo.[UserSavedSubmission]...'
		DELETE FROM dbo.[UserSavedSubmission]
		PRINT 'Table dbo.[UserSavedSubmission] rows were deleted successfully!'

		PRINT 'Deleting from table dbo.[UserSavedSubmissionStatusType]...'
		DELETE FROM dbo.[UserSavedSubmissionStatusType]
		PRINT 'Table dbo.[UserSavedSubmissionStatusType] rows were deleted successfully!'
	END
ELSE
	BEGIN	
		PRINT 'Column dbo.[UserSavedSubmission].UserSavedSubmissionStatusTypeId does not exist. No action taken (Script.DeleteOriginalUserSavedSubmissionTables)'
	END