﻿if OBJECT_ID('[dbo].[UserManagedSubmission]') iS NOT NULL
	BEGIN
		PRINT 'Delete Data UserManagedSubmissionStatus'
			DELETE FROM [dbo].[UserManagedSubmissionStatus];
		PRINT 'Delete Data UserManagedSubmission'
			DELETE FROM [dbo].[UserManagedSubmission];
		PRINT 'Delete Data UserManagedSubmissionStatusType'
			DELETE FROM [dbo].[UserManagedSubmissionStatusType];

		PRINT 'UserManagedSubmission tables cleared successfully.'
	END