﻿IF OBJECT_ID('TempDb..#DeleteDataverseNamespace') IS NOT NULL
	BEGIN
	PRINT 'TempDb..#DeleteDataverseNamespace'
		DROP TABlE #DeleteDataverseNamespace;
	END
