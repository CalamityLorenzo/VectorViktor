﻿/*
Removing the DataverseEndpoint schema and all its objects as part of decommissioning the Dataverse integration.
This script backs up data from the OutboxData table into a temporary table before deleting the data.
*/
IF EXISTS(SELECT 1 from INFORMATION_SCHEMA.SCHEMATA where SCHEMA_NAME='DataverseEndpoint') AND OBJECT_ID ('[DataverseEndpoint].[OutboxData]') IS NOT NULL
	BEGIN

	PRINT 'Backing up data from [DataverseEndpoint].[OutboxData] into #DeleteDataverseNamespace'
    SELECT *
    INTO #DeleteDataverseNamespace
    FROM [DataverseEndpoint].[OutboxData]
   
    PRINT 'DELETE data from [DataverseEndpoint].[OutboxData]'
    DELETE FROM [DataverseEndpoint].[OutboxData]
END