﻿IF COL_LENGTH('dbo.[ValuationSubmission]', 'TrancheId') IS NULL AND OBJECT_ID('TempDb..#DeleteTrancheIdFromValuationSubmission') IS NOT NULL
BEGIN

    PRINT 'Restoring data to [dbo].[ValuationSubmission]'
    SET IDENTITY_INSERT [dbo].[ValuationSubmission] ON;
    
    INSERT dbo.ValuationSUbmission(
       [ValuationSubmissionId]
      ,[ValuationSchemeId]
      ,[SchemeValuationSubmissionId]
      ,[EffectiveDate]
      ,[StartEventReference]
      ,[EndEventReference]
    )
    SELECT [ValuationSubmissionId]
      ,[ValuationSchemeId]
      ,[SchemeValuationSubmissionId]
      ,[EffectiveDate]
      ,[StartEventReference]
      ,[EndEventReference]
      from  #DeleteTrancheIdFromValuationSubmission

    SET IDENTITY_INSERT [dbo].[ValuationSubmission] OFF;

    PRINT 'Restoring constraints connected to [dbo].[ValuationSubmission]'
	ALTER TABLE [dbo].[Document] 
    CHECK CONSTRAINT [FK_Document_ValuationSubmission]

    ALTER TABLE [dbo].[Event] 
    CHECK CONSTRAINT [FK_Event_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationCase] 
    CHECK CONSTRAINT [FK_ValuationCase_ValuationSubmission]
    
    ALTER TABLE [dbo].[ValuationSubmissionGuardQuestionAnswer] 
    CHECK CONSTRAINT [FK_ValuationSubmissionGuardQuestionAnswer_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationSubmissionStatus] 
    CHECK CONSTRAINT [FK_ValuationSubmissionStatus_ValuationSubmission]

    ALTER TABLE [dbo].[ValuationSubmissionConfirmationDates]
    CHECK CONSTRAINT [FK_ValuationSubmissionConfirmationDates_ValuationSubmission]
    
    DROP TABLE #DeleteTrancheIdFromValuationSubmission;
END

