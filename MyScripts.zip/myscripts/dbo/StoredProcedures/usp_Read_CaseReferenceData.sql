﻿
-- =============================================
-- Author:		samuelh
-- Create date: 11 Feb 2025
-- Description:	The purpose of this procedure is to return the case referece
--		        with associated data for a submission
--
-- Input: 
-- @SchemeValuationSubmissionId - e.g. 'SCHEMEVALUATION-10000835-20250202-7ccb22fe'
-- =============================================
CREATE PROCEDURE usp_Read_CaseReferenceData
	@SchemeValuationSubmissionId VARCHAR(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT 
	   [ValuationCaseId],
       [ValuationSchemeId],
       [PSRNumber],
       [SchemeName],
       [ValuationSubmissionId],
       [CaseReference],
       [SchemeValuationSubmissionId],
       [EffectiveDate]
  FROM
    [dbo].[uvw_ValuationCase]
  WHERE
    SchemeValuationSubmissionId = @SchemeValuationSubmissionId
  ;
END
GO
