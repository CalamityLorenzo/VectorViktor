﻿CREATE PROCEDURE [dbo].[usp_Write_ValuationSubmission]
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@PSRNumber INT,
	@SchemeName VARCHAR(100),
	@EffectiveDate DATE, 
	@UserId VARCHAR(50),
	@EventSourceType SMALLINT,
	@IsExcludedSubmission BIT = 0,
	@ValuationSubmissionId INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	24 July 2024

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@PSRNumber						- The PSR number of the Scheme to which the event relates
	@SchemeName						- The name of the scheme
	@EffectiveDate					- The effective date of the scheme. Used to determine the tranche 
	@UserId							- The id of the User initiating the event
	@EventSourceType				- Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation
	@IsExcludedSubmission			- 1 = submission for excluded (i.e. test) scheme, 0 = submission for non-excluded schemes

Returns: 
	@ValuationSubmissionId			- The id of the inserted ValuationSubmission row

Purpose: 
	Inserts a new ValuationSubmission row

Comments: 

*/

AS
BEGIN
		SET NOCOUNT ON;

		DECLARE @ValuationStartedEventReference INT,
				@RC INT,
				@ValuationSchemeId INT, 
				
				@ErrorMessage VARCHAR(400),
				@ValuationSubmissionStatusId INT,

				@SchemeValuationSubmissionIdForThisPsrAndEffectiveDate VARCHAR(255),
				@PreviousSubmissionStatusTypeId SMALLINT,
				@ReplacementSubmissionStatusTypeId SMALLINT,
				@SupersededEventReference INT,

				@SubmissionStartedEventTypeId SMALLINT = 1,				-- SCHEME_VALUATION_STARTED,
				@SubmissionSupsersededEventTypeId SMALLINT = 12			-- SCHEME_VALUATION_SUPERSEDED

		BEGIN TRY
						
			BEGIN TRANSACTION;

				IF ISNULL(@EffectiveDate, '01 Jan 1900') = '01 Jan 1900'
				BEGIN
						;
					THROW 50005,
						'EffectiveDate cannot be blank.',
						1;
				END

				-- Do we have a previous, SUBMITTED version of this SchemeValuationSubmission? (i.e. with matching PSRNumber & EffectiveDate)
				-- we should only have a single in-progress ValuationSubmission row for this PSR Number and Effective date, 
				-- so the previous one is either superseded or cancelled.

				SELECT 
					@SchemeValuationSubmissionIdForThisPsrAndEffectiveDate = SchemeValuationSubmissionId, 
					@PreviousSubmissionStatusTypeId = SubmissionStatusTypeId
				FROM 
					uvw_SchemeValuationSubmissions_Current
				WHERE 
					PSRNumber = @PSRNumber
				AND EffectiveDate = @EffectiveDate
				AND EndEventReference IS NULL
				AND (SubmissionStatusTypeId = 2		-- SUBMITTED
					OR SubmissionStatusTypeId = 1)	-- or IN-PROGRESS

				IF (@SchemeValuationSubmissionIdForThisPsrAndEffectiveDate IS NOT NULL)
					BEGIN

						-- Supsersede or cancel. But do NOT End-Event the ValuationSubmission 

						IF (@PreviousSubmissionStatusTypeId = 2)	-- SUBMITTED
							BEGIN
								SET @ReplacementSubmissionStatusTypeId = 4	-- SUPERSEDED
							END
						ELSE
							BEGIN
								SET @ReplacementSubmissionStatusTypeId = 3	-- CANCELLED
							END

						-- NOTE event row is tied to a SchemeValuationSubmissionId, so there is ONE event for each superseded submission and a DIFFERENT event for the new submission 

						EXECUTE @RC = dbo.usp_Create_EventById 
							@EventTypeId = @SubmissionSupsersededEventTypeId,
							@SchemeValuationSubmissionId = @SchemeValuationSubmissionIdForThisPsrAndEffectiveDate,
							@UserId = @UserId,
							@EventSourceTypeId = @EventSourceType,
							@EventReference = @SupersededEventReference OUTPUT

						-- Set status to Superseded (for submitted submissions), or cancelled (for in-progress submissions)

						EXEC	@RC = dbo.usp_Write_ValuationSubmissionStatus 
								@SchemeValuationSubmissionId = @SchemeValuationSubmissionIdForThisPsrAndEffectiveDate,
								@SubmissionStatusType = @ReplacementSubmissionStatusTypeId,
								@UserId = @UserId,
								@CurrentEventReference = @SupersededEventReference,		
								@ValuationSubmissionStatusId = @ValuationSubmissionStatusId OUTPUT
						
					END

				-- create event to start a new schemeValuation

				EXECUTE @RC = dbo.usp_Create_EventById 
					@EventTypeId = @SubmissionStartedEventTypeId,				
					@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
					@UserId = @UserId,
					@EventSourceTypeId = @EventSourceType,
					@EventReference = @ValuationStartedEventReference OUTPUT

				-- insert new base record ValuationScheme, if it doesn't exist, or if the name has changed
					   
				SELECT 
					@ValuationSchemeId = ValuationSchemeId
				FROM 
					dbo.ValuationScheme
				WHERE PSRNumber = @PSRNumber
					AND SchemeName = @SchemeName
					AND EndEventReference IS NULL

				IF @ValuationSchemeId IS NULL
				BEGIN 
					EXECUTE @RC = dbo.usp_Write_ValuationScheme
						@PSRNumber = @PSRNumber,
						@SchemeName = @SchemeName, 
						@EventReference = @ValuationStartedEventReference, 
						@ValuationSchemeId = @ValuationSchemeId OUTPUT
				END

				INSERT INTO 
					dbo.ValuationSubmission 
					(
					   SchemeValuationSubmissionId,
					   ValuationSchemeId,
					   EffectiveDate,
					   IsExcludedSubmission,
					   StartEventReference
					)
				 VALUES
					(
						@SchemeValuationSubmissionId, 
						@ValuationSchemeId,
						@EffectiveDate,
						@IsExcludedSubmission,
						@ValuationStartedEventReference
					)

				IF @@ROWCOUNT <> 1
				BEGIN
					SET @ErrorMessage = 'Insert to dbo.ValuationSubmission created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
					;
					THROW 50005
						,@ErrorMessage
						,1
					;
				END
				;

				-- Set the valuation submission status to In progress/Started

				EXEC	@RC = dbo.usp_Write_ValuationSubmissionStatus 
								@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
								@SubmissionStatusType = 1,
								@UserId = @UserId,
								@CurrentEventReference = @ValuationStartedEventReference,
								@ValuationSubmissionStatusId = @ValuationSubmissionStatusId OUTPUT

			COMMIT TRANSACTION

			SET @ValuationSubmissionId = SCOPE_IDENTITY()
			;

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @ValuationSubmissionId = NULL
			;
			THROW
			;
		END CATCH

END