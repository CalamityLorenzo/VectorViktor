﻿CREATE PROCEDURE [dbo].[usp_Read_ValuationSubmissionId]
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@ValuationSubmissionId INT OUT
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	24 Oct 2024
Reason:			Get ValuationSubmissionId from dbo.ValuationSubmission 
				Throws error if not found
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
Returns: 
	@ValuationSubmissionId			- The id of the ValuationSubmission row with matching ValuationSubmissionId

Purpose: 
	Retrieves ValuationSubmissionId for a given @SchemeValuationSubmissionId

Comments: 

*/
AS

BEGIN

	DECLARE @ErrorMessage VARCHAR(512)

	SELECT 
		@ValuationSubmissionId = ValuationSubmissionId
	FROM 
		dbo.ValuationSubmission
	WHERE 
		SchemeValuationSubmissionId = @SchemeValuationSubmissionId


	IF @ValuationSubmissionId IS NULL
	BEGIN
		SET @ErrorMessage = '@SchemeValuationSubmissionId:' + ISNULL(@SchemeValuationSubmissionId, 'NULL') + ' is not a valid SchemeValuationSubmissionId '
		;
		THROW 50005
			,@ErrorMessage
			,1 ;
	END

END

GO
