﻿
CREATE PROCEDURE [dbo].[usp_Read_Submission]
	@SchemeValuationSubmissionId  VARCHAR(255),
	@SubmissionStatusTypeId INT = NULL
/*
-----------------------------------------------------------------------
Created by: 	samuelh
Created on: 	01 Nov 2025
--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@SubmissionStatusTypeId			- The status of the submission

Returns: 
	
	@SchemeValuationSubmissionId 
	@ValuationSubmissionId
	@SubmissionStatusTypeId
	@EffectiveDate
	@DateFundingAndInvestmentStrategyWasFinalised	- Date funding and investment strategy was finalised
	@DateStatementOfStrategyWasSigned				- Date statement of strategy was signed
	@CreateDateTime									- Date submission was started
	@SubmittedDateTime								- Date submission was submitted by user
	@UserId											- User who started the submission	

Purpose: To read the details of a submission
	

Comments: 


*/
AS
BEGIN

	SET NOCOUNT ON;
	
	SELECT SchemeValuationSubmissionId,
		   ValuationSubmissionId,
		   SchemeName,
		   SubmissionStatusTypeId,
		   EffectiveDate,
		   DateFundingAndInvestmentStrategyWasFinalised,
		   DateStatementOfStrategyWasSigned,
		   CreateDateTime,
		   IsExcludedSubmission, 
		   SubmittedDateTime,
		   UserId
	FROM dbo.uvw_SchemeValuationSubmissions svs
	WHERE svs.SchemeValuationSubmissionId = @SchemeValuationSubmissionId
	AND ((@SubmissionStatusTypeId IS NOT NULL AND @SubmissionStatusTypeId = svs.SubmissionStatusTypeId)
		OR @SubmissionStatusTypeId IS NULL)
	;

END
