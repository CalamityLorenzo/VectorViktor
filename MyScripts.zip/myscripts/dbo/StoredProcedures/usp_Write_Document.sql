﻿CREATE PROCEDURE dbo.usp_Write_Document
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@UserId VARCHAR(50),
	@EventSourceType SMALLINT,
	@EventType SMALLINT,				
    @UploadedFileName VARCHAR(512),
    @InternalFileName VARCHAR(512),
    @FileHash VARCHAR(512),
	@FileSize BIGINT,
	@SagaUploadedFileCorrelationId UNIQUEIDENTIFIER,
	@DocumentType SMALLINT,
	@DocumentStatusType SMALLINT,
	@DocumentId INT OUT

)
/* 
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	01 Aug 2024

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@UserId							- The id of the User initiating the event
	@EventSourceType				- Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation
	@EventType						- Id - expecting one of the "XXXX_UPLOADED" event types in EventType table
	@UploadedFileName				- The original file name of the document when it was uploaded by the user
    @InternalFileName				- The filename used internally within TPR
    @FileHash						- The file hash
	@FileSize						- The filesize in bytes
    @DocumentTypeId					- The type of document
	@DocumentStatusTypeId			- The initial status of the document

Returns: 
	@DocumentId		- The id of the document added

Purpose: 
	Write a new row in the Document table and also set the initial status of the document

Comments: 


*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @DocumentStatusId INT, 
				@CurrentDocumentStatusTypeId INT, 
				@ErrorMessage VARCHAR(900),
				@ReturnedEventReference INT,
				@RC INT,
				@ValuationSubmissionId INT,
				@CurrentDocumentIdOfThisType INT

		BEGIN TRY
			
			IF(@FileSize IS NULL)
				BEGIN
					SET @ErrorMessage = 'Filesize cannot be null for filename "'+ @UploadedFileName + '" and SubmissionId "' + @SchemeValuationSubmissionId + ' and DocumentType ' + CAST(@DocumentType AS VARCHAR(10)) + '".'
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

				IF(@SchemeValuationSubmissionId IS NULL)
				BEGIN
					SET @ErrorMessage = 'SchemeValuationSubmissionId cannot be null.';
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END
				IF(@DocumentType IS NULL)
				BEGIN
					SET @ErrorMessage = 'DocumentType cannot be null for filename "'+ @UploadedFileName + '" and SubmissionId "' + @SchemeValuationSubmissionId + '".'
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

				IF(@SagaUploadedFileCorrelationId = CAST('00000000-0000-0000-0000-000000000000' AS UNIQUEIDENTIFIER))
				BEGIN
					SET @ErrorMessage = 'SagaUploadedFileCorrelationId cannot be the default GUID value.';
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END


			-- Get ValuationSubmissionId from dbo.ValuationSubmission (We need to allow for either current OR cancelled/end-dated submissions, in case simultaneous 
			-- submissions are being submitted (e.g. automation tests), so don't use uvw_SchemeValuationSubmissions_Current here)

			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@ValuationSubmissionId = @ValuationSubmissionId OUTPUT


			-- If the user clicked the back button, then clicks next without making changes, the row we're about to insert will already exist. 
			-- So we just use the DocumentId of the existing row

			SELECT 
				@DocumentId = d.DocumentId, 
				@CurrentDocumentStatusTypeId = ds.DocumentStatusTypeId 
			FROM 
				dbo.Document d
			JOIN
				dbo.DocumentStatus ds
			ON ds.DocumentId = d.DocumentId
			WHERE
				d.ValuationSubmissionId = @ValuationSubmissionId
			AND d.UploadedFileName = @UploadedFileName
			AND d.InternalFileName = @InternalFileName
			AND d.FileHash = @FileHash
			AND d.SagaUploadedFileCorrelationId = @SagaUploadedFileCorrelationId
			AND d.DocumentTypeId = @DocumentType
			AND d.EndEventReference IS NULL


			IF @DocumentId IS NOT NULL 
				BEGIN
					IF (@CurrentDocumentStatusTypeId != @DocumentStatusType)
					BEGIN
						-- If Document already exists, but DocumentStatus has changed, update status 

						EXECUTE @RC = dbo.usp_Write_DocumentStatus
								@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
								@DocumentStatusTypeId = @DocumentStatusType,
								@DocumentId = @DocumentId,
								@EventSourceType = @EventSourceType,
								@UserId = @UserId,
								@EventTypeId = @EventType,
								@DocumentStatusId = @DocumentStatusId OUTPUT
					END

					RETURN
				END
			ELSE
				BEGIN
					
					BEGIN TRANSACTION;

						EXECUTE @RC = dbo.usp_Create_EventById 
							@EventTypeId = @EventType,				
							@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
							@UserId = @UserId,
							@EventSourceTypeId = @EventSourceType,
							@EventReference = @ReturnedEventReference OUTPUT

						-- Set EndEventReference this Document upload is replacing a previously uploaded document of the same type for this ValuationSubmission

						SELECT 
							@CurrentDocumentIdOfThisType = DocumentId
						FROM 
							dbo.Document
						WHERE
							ValuationSubmissionId = @ValuationSubmissionId
						AND DocumentTypeId = @DocumentType
						AND EndEventReference IS NULL

				
						IF (ISNULL(@CurrentDocumentIdOfThisType,0) > 0)
						BEGIN
							-- EndEvent the current one before inserting; we should only have one current document of this type for this valuation submission
							UPDATE 
								dbo.Document
							SET 
								EndEventReference = @ReturnedEventReference
							WHERE 
								ValuationSubmissionId = @ValuationSubmissionId
							AND DocumentTypeId = @DocumentType
							AND EndEventReference IS NULL  
						END


						INSERT INTO dbo.Document
							(
								ValuationSubmissionId,
								UploadedFileName,
								InternalFileName,
								FileHash,
								FileSize,
								SagaUploadedFileCorrelationId,
								DocumentTypeId,
								StartEventReference
							)
							VALUES
							(
								@ValuationSubmissionId, 
								@UploadedFileName, 
								@InternalFileName,
								@FileHash,
								@FileSize,
								@SagaUploadedFileCorrelationId,
								@DocumentType, 
								@ReturnedEventReference
							)

						IF @@ROWCOUNT <> 1
							BEGIN
								;
								SET @ErrorMessage = 'Insert into dbo.Document created ' + CAST(@@ROWCOUNT AS VARCHAR(20)) + ' row(s) instead of 1'
								;
								THROW 50005
									,@ErrorMessage
									,1
								;
							END
							;

						SET @DocumentId = SCOPE_IDENTITY()
						;


					-- set initial status 

					EXECUTE @RC = dbo.usp_Write_DocumentStatus
							@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
							@DocumentStatusTypeId = @DocumentStatusType,
							@DocumentId = @DocumentId,
							@EventReference = @ReturnedEventReference,
							@DocumentStatusId = @DocumentStatusId OUTPUT

				COMMIT TRANSACTION
			
			END

		END TRY

		BEGIN CATCH

			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @DocumentId = NULL
			SET @DocumentStatusId = NULL
			;
			THROW
			;

		END CATCH

END
