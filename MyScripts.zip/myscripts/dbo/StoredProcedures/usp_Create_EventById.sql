﻿CREATE PROCEDURE [dbo].[usp_Create_EventById]
	@EventTypeId					SMALLINT,
	@ValuationSubmissionId			INT = NULL,
	@SchemeValuationSubmissionId	VARCHAR(255) =  NULL,
	@UserId							VARCHAR(50),
	@TransactionId					VARCHAR(50)	= NULL,
	@EventSourceTypeId				SMALLINT,
	@NotificationDate				DATETIME2 = NULL,
	@EventReference					INT OUTPUT
AS

/*
Created by: Denise Groves 
Created on: 24/07/2024
--------------------------------------------------------------------
--------------------------------------------------------------------
Input parameters: 
	@EventTypeId					- The numeric Id of the type of event being created,
	@ValuationSubmissionId			- The primary key of the ValuationSubmission table, used within this application to uniquely identify a valuation submission
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@UserId							- The id of the User initiating the event
	@TransactionId					- The transaction reference (messageID) relating to the event
	@EventSourceTypeId				- The system carrying out the event - see EventSource table
	@NotificationDate				- The date of the event  - defaults to current date/time if not specified. 
									  Allows us to specify the time of the message notification, in case it differs from the time this proc was called
	@EventReference					- OUTPUT - The ID of the generated event. This is expected to be used as a foreign key value in another table

Returns: 
	@EventReference	- The id of the generated Event

Purpose: 
	To create an entry in dbo.Event, for tracking historical changes to data
	(Modified from original sproc usp_SM_Create_EventById in Registry)

Comments: 

*/
BEGIN
	DECLARE @NotifyDate DATETIME2, 
			@ErrorMessage VARCHAR(400)
	
	IF @EventTypeId IS NULL
	BEGIN
		;
		THROW 50005
			,'@EventTypeId cannot be NULL'
			,1
		;
	END

	SET NOCOUNT ON

	BEGIN TRY
		IF NOT EXISTS (SELECT 1 FROM dbo.EventType WHERE EventTypeId = @EventTypeId)
			BEGIN
				SET @ErrorMessage = 'EventTypeId ' + CAST(@EventTypeId AS VARCHAR(20)) + ' does not exist in dbo.EventType'
				;
				THROW 50005
					,@ErrorMessage
					,1 ;
			END

		IF(@UserId IS NULL OR @UserId = '')
			BEGIN
				SET @ErrorMessage = 'UserId cannot be null or empty.';
				;
				THROW 50005,
					@ErrorMessage
					,1;
			END

		IF(@SchemeValuationSubmissionId IS NULL OR @SchemeValuationSubmissionId = '')
			BEGIN
				SET @ErrorMessage = 'SchemeValuationSubmissionId cannot be null or empty.';
				;
				THROW 50005,
					@ErrorMessage
					,1;
			END



		BEGIN TRANSACTION;
		
			INSERT INTO dbo.[Event] 
			(
				EventTypeId,
				ValuationSubmissionId,
				SchemeValuationSubmissionId,
				UserId,
				TransactionId,
				NotificationDate,
				EventSourceTypeId
			)
			SELECT	
				EventTypeId,
				@ValuationSubmissionId,
				@SchemeValuationSubmissionId,
				@UserId,
				@TransactionId,
				@NotificationDate,
				@EventSourceTypeId
			FROM	
				dbo.EventType et
			WHERE	
				et.EventTypeId = @EventTypeId
				AND et.IsActive = 1
		

			--As there is a where clause here, need to check the rowcount

			IF @@ROWCOUNT <> 1
				BEGIN
					SET @ErrorMessage = 'Insert to dbo.Event created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
					;
					THROW 50005
						,@ErrorMessage
						,1
					;
				END
				;

		COMMIT TRANSACTION

		SET @EventReference = SCOPE_IDENTITY()
		;

	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
		;
		SET @EventReference = NULL
		;
		THROW
		;
	END CATCH

END