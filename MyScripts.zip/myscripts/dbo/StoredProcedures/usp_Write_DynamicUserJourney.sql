﻿CREATE PROCEDURE [dbo].[usp_Write_DynamicUserJourney]
(
	@SchemeValuationSubmissionId VARCHAR(255),	
	@FastTrackOrBespokeType	SMALLINT, 
	@DeficitOrSurplusType SMALLINT,
	@AdditionalRequiredDocumentType SMALLINT,
	@IsMultiDocUpload BIT = 0,
	@UserId VARCHAR(50),
	@EventSourceType SMALLINT,
	@DynamicUserJourneyId INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	14 May 2026

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId		- The id used throughout TPR to uniquely identify an individual valuation submission version
	@FastTrackOrBespokeType				- The type of valuation
	@DeficitOrSurplusType				- The deficit/surplus status of the uploaded valuation
	@AdditionalRequiredDocumentTypeId	- The type of additional document required (if applicable)
	@IsMultiDocUpload					- Whether this is a multi-document upload (i.e. whether the user will be uploading multiple documents as part of this journey)
	@UserId							- The id of the User initiating the event
	@EventSourceType				- Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation

Returns: 
	@DynamicUserJourneyId		- The id of the document added

Purpose: 
	Write a new row in the DynamicUserJourney table

Comments: 
*/

AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ErrorMessage VARCHAR(900),
			@ReturnedEventReference INT,
			@RC INT,
			@ValuationSubmissionId INT,
			@CurrentDynamicUserJourneyId INT,
			@CurrentFastTrackOrBespokeType	SMALLINT,
			@CurrentDeficitOrSurplusType SMALLINT,
			@CurrentAdditionalRequiredDocumentTypeId SMALLINT,
			@CurrentIsMultiDocUpload SMALLINT,
			@EventType SMALLINT = 16 --DYNAMIC_USER_JOURNEY_SAVED
			

		BEGIN TRY
		
			IF(@SchemeValuationSubmissionId IS NULL)
				BEGIN
					SET @ErrorMessage = 'SchemeValuationSubmissionId cannot be null.';
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

			IF(@FastTrackOrBespokeType IS NULL)
				BEGIN
					SET @ErrorMessage = 'FastTrackOrBespokeType cannot be null for SchemeValuationSubmissionId "'+ @SchemeValuationSubmissionId + '".'
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

			IF(@DeficitOrSurplusType IS NULL)
				BEGIN
					SET @ErrorMessage = 'DeficitOrSurplusType cannot be null for SchemeValuationSubmissionId "'+ @SchemeValuationSubmissionId + '".'
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

			IF(@AdditionalRequiredDocumentType IS NULL)
				BEGIN
					SET @ErrorMessage = 'AdditionalDocumentTypeId cannot be null for SchemeValuationSubmissionId "'+ @SchemeValuationSubmissionId + '".'
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

			IF(@IsMultiDocUpload IS NULL)
				BEGIN
					SET @ErrorMessage = 'IsMultiDocUpload cannot be null for SchemeValuationSubmissionId "'+ @SchemeValuationSubmissionId + '".'
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

			-- Get ValuationSubmissionId from dbo.ValuationSubmission (We need to allow for either current OR cancelled/end-dated submissions, in case simultaneous 
			-- submissions are being submitted (e.g. automation tests), so don't use uvw_SchemeValuationSubmissions_Current here)


			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@ValuationSubmissionId = @ValuationSubmissionId OUTPUT

			-- if we already have this entry in the DB for this, just set the out param and return

			SELECT 
				@CurrentDynamicUserJourneyId = DynamicUserJourneyId,
				@CurrentFastTrackOrBespokeType  = FastTrackOrBespokeTypeId,
				@CurrentDeficitOrSurplusType = DeficitOrSurplusTypeId, 
				@CurrentAdditionalRequiredDocumentTypeId = AdditionalRequiredDocumentTypeId,
				@CurrentIsMultiDocUpload = IsMultiDocUpload
			FROM 
				dbo.DynamicUserJourney
			WHERE 
				ValuationSubmissionId = @ValuationSubmissionId
				AND EndEventReference IS NULL

			IF (ISNULL(@CurrentDynamicUserJourneyId,0) > 0 
				AND (@CurrentFastTrackOrBespokeType IS NOT NULL AND @CurrentFastTrackOrBespokeType = @FastTrackOrBespokeType)
				AND (@CurrentDeficitOrSurplusType IS NOT NULL AND @CurrentDeficitOrSurplusType = @DeficitOrSurplusType)
				AND (@CurrentAdditionalRequiredDocumentTypeId IS NOT NULL AND @CurrentAdditionalRequiredDocumentTypeId = @AdditionalRequiredDocumentType)
				AND (@CurrentIsMultiDocUpload IS NOT NULL AND @CurrentIsMultiDocUpload = @IsMultiDocUpload)
				)
			BEGIN
				SET @DynamicUserJourneyId = @CurrentDynamicUserJourneyId
				RETURN
			END

			BEGIN TRANSACTION

				EXECUTE @RC = dbo.usp_Create_EventById
								@EventTypeId = @EventType,
								@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
								@UserId = @UserId,
								@EventSourceTypeId = @EventSourceType,
								@EventReference = @ReturnedEventReference OUTPUT

				IF (ISNULL(@CurrentDynamicUserJourneyId,0) > 0)
					BEGIN
						-- EndEvent the current one before inserting; we should only have one current ValuationCase row for this valuation submission
						UPDATE 
							dbo.DynamicUserJourney
						SET 
							EndEventReference = @ReturnedEventReference
						WHERE 
			 				ValuationSubmissionId = @ValuationSubmissionId		-- IF we're using this as the foreign key
							AND EndEventReference IS NULL
					END

				INSERT INTO 
					dbo.[DynamicUserJourney]
					(
						ValuationSubmissionId,
						FastTrackOrBespokeTypeId,
						DeficitOrSurplusTypeId,
						AdditionalRequiredDocumentTypeId,
						IsMultiDocUpload,
						StartEventReference
					)
				VALUES 
					(
						@ValuationSubmissionId,
						@FastTrackOrBespokeType,
						@DeficitOrSurplusType,
						@AdditionalRequiredDocumentType,
						@IsMultiDocUpload,
						@ReturnedEventReference
					)

				IF @@ROWCOUNT <> 1
					BEGIN
						SET @ErrorMessage = 'Insert to dbo.DynamicUserJourney created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
						;
						THROW 50005
							,@ErrorMessage
							,1
						;
					END
					;

			COMMIT TRANSACTION

			SET @DynamicUserJourneyId = SCOPE_IDENTITY()
			;
		END TRY

		BEGIN CATCH

			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @DynamicUserJourneyId = NULL
			;
			THROW
			;

		END CATCH

END