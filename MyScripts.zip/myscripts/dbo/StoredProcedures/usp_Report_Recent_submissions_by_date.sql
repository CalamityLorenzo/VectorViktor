﻿CREATE PROCEDURE dbo.usp_Report_Recent_Submissions_By_Date
(
	@CreatedDate  DATE
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Paul Lawrence
Created on: 	11 11 2025
Reason:			For daily reporting gets all the events for submissions on a particular date.
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@CreatedDate - The date the events were created on that you are querying. Does not take into account time, or end of day
Returns: 

Purpose: 
	Review all events for a particular date and return details.
Comments: 

*/
AS
BEGIN
	SET NOCOUNT ON;

	DROP TABLE IF EXISTS #RecentEvents
	;
	SELECT t.EventTypeDescription AS EventType
		,st.EventSourceDescription AS EventSource
		,e.EventReference
		,e.SchemeValuationSubmissionId
		,e.UserId
		,e.CreateDateTime
		,e.NotificationDate
	INTO #RecentEvents
	FROM dbo.[Event] e
	JOIN dbo.EventSourceType st
		ON st.EventSourceTypeId = e.EventSourceTypeId
	JOIN dbo.EventType t
		ON t.EventTypeId = e.EventTypeId
	WHERE CAST(e.CreateDateTime as DATE) = @CreatedDate
	;
	SELECT	EventType,
			EventSource,
			EventReference,
			SchemeValuationSubmissionId,
			UserId,
			CreateDateTime,
			NotificationDate
	FROM #RecentEvents
	ORDER BY CreateDateTime
	;
	SELECT PSRNumber
		,SchemeName
		,sch.StartEventReference AS SchemeStartEvent
		,sch.EndEventReference	 AS SchemeEndEvent
		,sub.SchemeValuationSubmissionId
		,sub.EffectiveDate		 AS SubmissionEffectiveDate
		,sub.StartEventReference AS SubmissionStartEvent
		,sub.EndEventReference	 AS SubmissionEndEvent
		,cd.DateFundingAndInvestmentStrategyWasFinalised
		,cd.DateStatementOfStrategyWasSigned
		,cd.StartEventReference AS ConfirmationDatesStartEvent
		,cd.EndEventReference   AS ConfirmationDatesEndEvent
		,vsstat.StartEventReference AS SubmissionStatusStartEvent
		,vsstat.EndEventReference	AS SubmissionStatusEndEvent
		,st.SubmissionStatusName
		,st.SubmissionStatusDescription
		,st.IsActive
	FROM dbo.ValuationScheme sch
	JOIN dbo.ValuationSubmission sub
		ON sub.ValuationSchemeId = sch.ValuationSchemeId
	LEFT JOIN dbo.ValuationSubmissionConfirmationDates cd
		ON cd.ValuationSubmissionId = sub.ValuationSubmissionId
	LEFT JOIN dbo.ValuationSubmissionStatus vsstat
		ON vsstat.ValuationSubmissionId = sub.ValuationSubmissionId
	LEFT JOIN dbo.SubmissionStatusType st
		ON st.SubmissionStatusTypeId = vsstat.SubmissionStatusTypeId
	WHERE EXISTS (
		SELECT 1
		FROM #RecentEvents re
		WHERE (re.EventReference = sch.StartEventReference
			OR re.EventReference = sub.StartEventReference
			OR re.EventReference = cd.StartEventReference
			OR re.EventReference = vsstat.StartEventReference
			OR re.EventReference = sch.EndEventReference
			OR re.EventReference = sub.EndEventReference
			OR re.EventReference = cd.EndEventReference
			OR re.EventReference = vsstat.EndEventReference
			)
		)
	;
	SELECT d.UploadedFileName
		,d.InternalFileName
		,d.FileHash
		,d.StartEventReference
		,d.EndEventReference
		,dt.DocumentTypeName
		,dt.DocumentTypeDescription
		,dt.IsActive
		,dst.DocumentStatusName
		,dst.DocumentStatusDescription
		,dst.IsActive
	FROM dbo.Document d
	LEFT JOIN dbo.DocumentType dt
		ON dt.DocumentTypeId = d.DocumentTypeId
	LEFT JOIN dbo.DocumentStatus ds
		ON ds.DocumentId = d.DocumentId
	LEFT JOIN dbo.DocumentStatusType dst
		ON dst.DocumentStatusTypeId = ds.DocumentStatusTypeId
	LEFT JOIN dbo.ValuationSubmissionData vsd
		ON vsd.DocumentId = d.DocumentId
	WHERE EXISTS (
		SELECT 1
		FROM #RecentEvents re
		WHERE (re.EventReference = d.StartEventReference
			OR re.EventReference = ds.StartEventReference
			OR re.EventReference = vsd.StartEventReference

			OR re.EventReference = d.EndEventReference
			OR re.EventReference = ds.EndEventReference
			OR re.EventReference = vsd.EndEventReference
			)
		)
END