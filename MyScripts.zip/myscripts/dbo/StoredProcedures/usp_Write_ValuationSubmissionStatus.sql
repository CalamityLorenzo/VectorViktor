﻿CREATE PROCEDURE dbo.usp_Write_ValuationSubmissionStatus 
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@SubmissionStatusType SMALLINT,
	@UserId VARCHAR(50),
	@EventSourceType SMALLINT = 0,
	@EventType SMALLINT = 0,
	@CurrentEventReference INT = 0,
	@ValuationSubmissionStatusId INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Komal Polavarapu
Created on: 	29 Aug 2024

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@SubmissionStatusTypeId			- The id is the status e.g. 1 - IN PROGRESS 2 - SUBMITTED 3 - CANCELLED
	@UserId							- The id of the User initiating the event
	
	If this is NOT part of an existing DB event transaction:

	@EventSourceType				- pass the Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation
	@EventType						- pass in an Id from from the EventType table

	If this IS part of an existing DB event transaction:

	@CurrentEventReference			- pass in the EventReference to use for the StartEventReference/EndEventReference.
									  If this is NULL or 0, a new event will be created and the EventReference returned

Returns: 
	@ValuationSubmissionStatusId	- The id of the Submission status added

Purpose: 
	Create the valuation submission status record

Comments: 

*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @CurrentValuationSubmissionStatusId INT,
				@CurrentSubmissionStatusTypeId INT,
				@ErrorMessage VARCHAR(400),
				@ValuationSubmissionId INT,
				@RC INT

		BEGIN TRY
		
			-- Get ValuationSubmissionId from dbo.ValuationSubmission (We need to allow for either current OR cancelled/end-dated submissions, in case simultaneous 
			-- submissions are being submitted (e.g. automation tests), so don't use uvw_SchemeValuationSubmissions_Current here)

			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
					@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
					@ValuationSubmissionId = @ValuationSubmissionId OUTPUT

			-- Get the current status and submission id

			SELECT 
				@CurrentSubmissionStatusTypeId = SubmissionStatusTypeId,
				@CurrentValuationSubmissionStatusId = ValuationSubmissionStatusId
			FROM 
				dbo.[ValuationSubmissionStatus]
			WHERE 
				ValuationSubmissionId = @ValuationSubmissionId
			AND	EndEventReference IS NULL


			IF @CurrentSubmissionStatusTypeId IS NOT NULL AND @CurrentSubmissionStatusTypeId =  @SubmissionStatusType 
				BEGIN
					-- If the current status is the same as the requested status, there's no update required, so return the current ValuationSubmissionStatus id
					SET @ValuationSubmissionStatusId = @CurrentValuationSubmissionStatusId
				END
			
			ELSE
				BEGIN
					
					BEGIN TRANSACTION;

						IF (@CurrentEventReference IS NULL OR @CurrentEventReference = 0)
							BEGIN
								EXECUTE @RC = dbo.usp_Create_EventById 
									@EventTypeId = @EventType,				
									@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
									@UserId = @UserId,
									@EventSourceTypeId = @EventSourceType,
									@EventReference = @CurrentEventReference OUTPUT
							END
						ELSE
							BEGIN
								IF NOT EXISTS (SELECT 1 FROM dbo.Event WHERE EventReference = @CurrentEventReference)
								BEGIN
									SET @ErrorMessage = 'CurrentEventReference ' + CAST(@CurrentEventReference AS VARCHAR(20)) + ' does not exist in dbo.Event'
									;
									THROW 50005
										,@ErrorMessage
										,1 ;
								END
							END

						-- If there is an existing status row for this ValuationSubmisssion, and it's NOT same as the @CurrentValuationSubmissionStatusId passed in, 
						-- soft-delete the current status before inserting a new record
						-- (we should only have one current status for this valuation submission)

						IF @CurrentValuationSubmissionStatusId IS NOT NULL
							BEGIN
								UPDATE 
									[dbo].[ValuationSubmissionStatus] 
								SET 
									EndEventReference = @CurrentEventReference
								WHERE 
									ValuationSubmissionStatusId = @CurrentValuationSubmissionStatusId
							END						

						INSERT INTO [dbo].[ValuationSubmissionStatus]
							   ([SubmissionStatusTypeId]
							   ,[ValuationSubmissionId]
							   ,[StartEventReference])
							VALUES
							(
								@SubmissionStatusType, 
								@ValuationSubmissionId,
								@CurrentEventReference
							)

						IF @@ROWCOUNT <> 1
							BEGIN
								SET @ErrorMessage = 'Insert into dbo.ValuationSubmissionStatus created ' + CAST(@@ROWCOUNT AS VARCHAR(20)) + ' row(s) instead of 1'
								;
								THROW 50005
									,@ErrorMessage
									,1 ;
							END

						SET @ValuationSubmissionStatusId = SCOPE_IDENTITY();

					COMMIT TRANSACTION
			
				END

		END TRY

		BEGIN CATCH

			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION;
			SET @ValuationSubmissionStatusId = NULL;
			THROW;

		END CATCH

END
