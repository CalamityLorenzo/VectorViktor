﻿
CREATE PROCEDURE [dbo].[usp_Read_UserSavedAndValuationSubmission]
	@PsrNumber INT
/*
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	5 June 2026
--------------------------------------------------------------------
Input parameters: 
	@PsrNumber	- The id of the scheme

Returns: 
	UserSavedSubmission details for the current, in-progress User-saved submission, along with related columns from:
    - ValuationSubmission
    - DynamicUserJourney
    - ValuationSubmissionConfirmationDates 
    (all from [uvw_UserSavedSubmissions_Current])

Purpose: To read the details of a user-saved submission and all related ValuationSubmission data, for a given scheme

*/

AS
BEGIN
	DECLARE @ErrorMessage VARCHAR(255);

	SET NOCOUNT ON;
	
	SELECT 
        [UserSavedSubmissionId]
        ,[PSRNumber]
        ,[SchemeValuationSubmissionId]
        ,[EffectiveDate]
        ,[LastUpdated]
        ,[LastActionPageId]
        ,[LastPageData]
        ,[UserSavedSubmissionStartEventReference]
        ,[SchemeName]
        ,[ValuationSchemeId]
        ,[SubmissionStatusTypeId]
        ,[ValuationSubmissionCreateDateTime]
        ,[ValuationSubmissionId]
        ,[DateFundingAndInvestmentStrategyWasFinalised]
        ,[DateStatementOfStrategyWasSigned]
        ,[IsExcludedSubmission]
        ,[StartEventReference]
        ,[EndEventReference]
        ,[CreateDateTime]
        ,[ValuationSubmissionUserId]
        
        ,[AdditionalRequiredDocumentTypeId]
        ,[AdditionalRequiredDocumentDescription]
        ,[DynamicUserJourneyId]
        ,[FastTrackOrBespokeTypeId]
        ,[FastTrackOrBespokeDescription]
        ,[DeficitOrSurplusTypeId]
        ,[DeficitOrSurplusDescription]
        ,[IsMultiDocUpload]
    FROM [dbo].[uvw_UserSavedSubmissions_Current]

	WHERE PsrNumber = @PsrNumber
    AND [SubmissionStatusTypeId] = 1
	ORDER BY [UserSavedSubmissionId] DESC

END

