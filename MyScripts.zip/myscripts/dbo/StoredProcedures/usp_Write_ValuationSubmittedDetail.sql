﻿CREATE PROCEDURE [dbo].[usp_Write_ValuationSubmittedDetail]
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@SubmittedDateTime DATETIME2,
	@UserId	VARCHAR(50),
	@EventType SMALLINT = 6,
	@EventSourceType SMALLINT, 
	@ValuationSubmittedDetailId INT OUT
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	12 Feb 2025
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@SubmittedDateTime				- The date and time that the submit button was clicked
	@UserId							- The id of the User initiating the event
	@EventType						- Id fron the EventType table - the type of event taking place
	@EventSourceType				- Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation
Returns: 
	@ValuationSubmittedDetailId		- The id of the inserted ValuationSubmittedDetail row

Purpose: 
	1) Inserts rows in table dbo.ValuationSubmittedDetail, to record details of when the valuation was submitted. 
	2) Also calls usp_Write_ValuationSubmissionStatus to set the valuation submission status to Submitted (using the same EventReference)

Comments: 

*/

AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE @ValuationSubmissionId INT, 
			@ReturnedEventReference INT,
			@CurrentValuationSubmittedDetailId INT,
			@ErrorMessage VARCHAR(512),
			@RC INT, 
			@ValuationSubmissionStatusId INT, 
			@CurrentSubmissionStatusTypeId SMALLINT

	BEGIN TRY
		
		IF(@SchemeValuationSubmissionId IS NULL)
		BEGIN
			SET @ErrorMessage = 'SchemeValuationSubmissionId cannot be null.';
			THROW 50005, @ErrorMessage, 1;
		END

		IF @SubmittedDateTime IS NULL
		BEGIN
			SET @ErrorMessage = 'SubmittedDateTime cannot be null.';
			THROW 50005, @ErrorMessage, 1;
		END

		IF @EventSourceType IS NULL
		BEGIN
			SET @ErrorMessage = 'EventSourceType cannot be null.';
			THROW 50005, @ErrorMessage, 1;
		END

		-- Get ValuationSubmissionId from dbo.ValuationSubmission (We need to allow for either current OR cancelled/end-dated submissions, in case simultaneous 
		-- submissions are being submitted (e.g. automation tests), so don't use uvw_SchemeValuationSubmissions_Current here)

		EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
					@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
					@ValuationSubmissionId = @ValuationSubmissionId OUTPUT
		
		IF(@ValuationSubmissionId IS NULL)
			BEGIN
				SET @ErrorMessage = 'Cannot find ValuationSubmissionId from @SchemeValuationSubmissionId: ' + @SchemeValuationSubmissionId + '.';
				THROW 50005, @ErrorMessage, 1;
			END

		SELECT @CurrentSubmissionStatusTypeId = SubmissionStatusTypeId
		FROM dbo.ValuationSubmissionStatus 
		WHERE ValuationSubmissionId = @ValuationSubmissionId
		AND EndEventReference IS NULL

		IF (@CurrentSubmissionStatusTypeId = 3)
			BEGIN
				SET @ErrorMessage = 'Unable to submit because the submission has already been cancelled! @SchemeValuationSubmissionId: ' + @SchemeValuationSubmissionId + '.';
				THROW 50005, @ErrorMessage, 1;
			END

		IF (@CurrentSubmissionStatusTypeId = 4)
			BEGIN
				SET @ErrorMessage = 'Unable to submit because the submission has already been superseded! @SchemeValuationSubmissionId: ' + @SchemeValuationSubmissionId + '.';
				THROW 50005, @ErrorMessage, 1;
			END

		SELECT 
			@CurrentValuationSubmittedDetailId = ValuationSubmittedDetailId
		FROM 
			dbo.ValuationSubmittedDetail
		WHERE 
			ValuationSubmissionId = @ValuationSubmissionId
			AND EndEventReference IS NULL


		BEGIN TRANSACTION;		

			EXECUTE @RC = dbo.usp_Create_EventById 
					@EventTypeId = @EventType,				
					@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
					@UserId = @UserId,
					@EventSourceTypeId = @EventSourceType,
					@EventReference = @ReturnedEventReference OUTPUT

			IF (ISNULL(@CurrentValuationSubmittedDetailId,0) > 0)
			BEGIN
				-- it's probably impossible to submit twice but just in case...
				-- EndEvent the current one before inserting; we should only have one current ValuationSubmittedDetail row for this valuation submission
				UPDATE 
					dbo.ValuationSubmittedDetail
				SET 
					EndEventReference = @ReturnedEventReference
				WHERE 
					ValuationSubmissionId = @ValuationSubmissionId
					AND EndEventReference IS NULL
			END

			-- 1) Set the valuation submission status to Submitted

			EXEC	@RC = dbo.usp_Write_ValuationSubmissionStatus 
					@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
					@SubmissionStatusType = 2,	
					@UserId = @UserId,
					@CurrentEventReference = @ReturnedEventReference,
					@ValuationSubmissionStatusId = @ValuationSubmissionStatusId OUTPUT

			-- 2) Now store the submission date/time in dbo.ValuationSubmittedDetail

			INSERT INTO 
				dbo.ValuationSubmittedDetail
				(
					ValuationSubmissionId,
					SubmittedDateTime,
					StartEventReference
				)
			VALUES 
				(
					@ValuationSubmissionId,
					@SubmittedDateTime,
					@ReturnedEventReference
				)

			IF @@ROWCOUNT <> 1
				BEGIN
					SET @ErrorMessage = 'Insert to dbo.ValuationSubmittedDetail created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
					;
					THROW 50005
						,@ErrorMessage
						,1
					;
				END
				;

			SET @ValuationSubmittedDetailId = SCOPE_IDENTITY();

		COMMIT TRANSACTION

	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
		;
		SET @ValuationSubmittedDetailId = NULL
		;
		THROW
		;
	END CATCH

END