﻿CREATE PROCEDURE dbo.usp_Write_ValuationSubmissionGuardQuestionAnswer
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@GuardQuestionAnswerId INT,
	@UserId VARCHAR(50),
	@EventSourceType SMALLINT,
	@EventType SMALLINT,
	@ValuationSubmissionGuardQuestionAnswerId INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	31 July 2024

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@GuardQuestionAnswerId			- The identifier for the guard question answer
	@UserId							- The id of the User initiating the event, 
	@EventSourceType				- Id from the EventSource table, identifying the system calling this sproc 

Returns: 
	@ValuationSubmissionGuardQuestionAnswerId	- The id of the inserted row

Purpose: 
	Insert a new ValuationSubmissionGuardQuestionAnswer row
	Unless the answer to the question has not changed, in which case it just returns the ID of the existing @ValuationSubmissionGuardQuestionAnswerId

Comments: 
*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @ReturnedEventReference INT,
				@RC INT,
				@ValuationSubmissionId INT, 
				@GuardQuestionId INT,
				@ErrorMessage VARCHAR(400),
				@CurrentValuationSubmissionGuardQuestionAnswerId INT

		BEGIN TRY
		
			-- Get ValuationSubmissionId from dbo.ValuationSubmission (We need to allow for either current OR cancelled/end-dated submissions, in case simultaneous 
			-- submissions are being submitted (e.g. automation tests), so don't use uvw_SchemeValuationSubmissions_Current here)

			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
					@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
					@ValuationSubmissionId = @ValuationSubmissionId OUTPUT
		

			-- If we already have THIS answer for THIS valuationSubmission, just return the ID 

			SELECT 
				@ValuationSubmissionGuardQuestionAnswerId = ValuationSubmissionGuardQuestionAnswerId
			FROM 
				[dbo].uvw_ValuationSubmissionGuardQuestionAnswers_Current
			WHERE
				ValuationSubmissionId = @ValuationSubmissionId
			AND GuardQuestionAnswerId = @GuardQuestionAnswerId

			IF (@ValuationSubmissionGuardQuestionAnswerId IS NOT NULL)
			BEGIN
				RETURN;
			END


			BEGIN TRANSACTION;

				EXECUTE @RC = dbo.usp_Create_EventById 
					@EventTypeId = @EventType			
					,@SchemeValuationSubmissionId = @SchemeValuationSubmissionId
					,@UserId = @UserId
					,@EventSourceTypeId = @EventSourceType		
					,@EventReference = @ReturnedEventReference OUTPUT


				-- If we have previous answers to THIS question for THIS ValuationSubmissionId, they need to be marked as no longer current 
				-- with a soft delete i.e. set the EndEventReference before inserting the new answer to this question

				SELECT 
					@GuardQuestionId = GuardQuestionId
				FROM 
					GuardQuestionAnswer 
				WHERE 
					GuardQuestionAnswerId = @GuardQuestionAnswerId


				SELECT 
					@CurrentValuationSubmissionGuardQuestionAnswerId = ValuationSubmissionGuardQuestionAnswerId
				FROM 
					dbo.ValuationSubmissionGuardQuestionAnswer vsgqa
				INNER JOIN dbo.GuardQuestionAnswer gqa 
					ON gqa.GuardQuestionAnswerId = vsgqa.GuardQuestionAnswerId
				WHERE 
					vsgqa.ValuationSubmissionId = @ValuationSubmissionId				
				AND gqa.GuardQuestionId = @GuardQuestionId
				AND vsgqa.EndEventReference IS NULL

				IF (ISNULL(@CurrentValuationSubmissionGuardQuestionAnswerId, 0) > 0)
				BEGIN
					-- EndEvent the current one before inserting; we should only have one current anwser to this question for this valuation submission

					UPDATE 
						vsgqa
					SET 
						vsgqa.EndEventReference = @ReturnedEventReference
					FROM 
						dbo.ValuationSubmissionGuardQuestionAnswer vsgqa
					INNER JOIN dbo.GuardQuestionAnswer gqa 
						ON gqa.GuardQuestionAnswerId = vsgqa.GuardQuestionAnswerId 
					WHERE 
						vsgqa.ValuationSubmissionId = @ValuationSubmissionId
					AND gqa.GuardQuestionId = @GuardQuestionId
					AND vsgqa.EndEventReference IS NULL

				END
								

				INSERT INTO dbo.ValuationSubmissionGuardQuestionAnswer
					(
						ValuationSubmissionId,
						GuardQuestionAnswerId,
						StartEventReference
					)
					VALUES 
					(
						@ValuationSubmissionId, 
						@GuardQuestionAnswerId,
						@ReturnedEventReference
					)

				IF @@ROWCOUNT <> 1
				BEGIN
					SET @ErrorMessage = 'Insert to dbo.ValuationSubmissionGuardQuestionAnswer created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
					;
					THROW 50005
						,@ErrorMessage
						,1
					;
				END
				;
			
			COMMIT TRANSACTION

			SET @ValuationSubmissionGuardQuestionAnswerId = SCOPE_IDENTITY()
			;

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @ValuationSubmissionGuardQuestionAnswerId = NULL
			;
			THROW
			;
		END CATCH

END