﻿CREATE PROCEDURE dbo.usp_Write_DocumentStatus
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@DocumentStatusTypeId SMALLINT,
    @DocumentId INT,
	@EventReference INT = NULL,
	@UserId VARCHAR(50) = NULL,
	@EventSourceType  SMALLINT = NULL,
	@EventTypeId SMALLINT = NULL,
	@DocumentStatusId INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	01 Aug 2024

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@DocumentStatusTypeId			- The status of the document
	@DocumentId						- Unique identifier for the document / file

	IF this IS being called as part of an existing db event:

	@EventReference					- The EventReference (unique identifier of Event table)

	If this IS NOT part of an existing DB event:

	@UserId							- The id of the User initiating the event. 
	@EventSourceTypeId				- Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation
	@EventTypeId					- Id from the EventType table to identify the db event which is creating this row, 

Returns: 
	@DocumentStatusId				- The id of the DocumentStatus row added

Purpose: 
	Write a new row in the DocumentStatus table and to set status of the document

Comments: 

*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @RC INT,
				@PSRNumber INT,
				@ErrorMessage VARCHAR(400),
				@CurrentDocumentStatusId INT,
				@ValuationSchemeId INT, 
				@ValuationSubmissionId INT,
				@SchemesFormerNamesCount SMALLINT,
				@ExistingDocumentStatusId INT

		BEGIN TRY
				
			-- have we already recorded this status for this document? 
				
			SELECT
				@ExistingDocumentStatusId = DocumentStatusId
			FROM
				dbo.DocumentStatus
			WHERE 
				DocumentStatusTypeId = @DocumentStatusTypeId
			AND DocumentId = @DocumentId
			AND EndEventReference IS NULL

			IF (@ExistingDocumentStatusId IS NOT NULL)
			BEGIN 
				SET @DocumentStatusId = @ExistingDocumentStatusId
				RETURN
			END
			

			BEGIN TRANSACTION;

				IF (@EventReference IS NULL)
				BEGIN
					EXECUTE @RC = dbo.usp_Create_EventById 
						@EventTypeId = @EventTypeId,				
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@UserId = @UserId,
						@EventSourceTypeId = @EventSourceType,
						@EventReference = @EventReference OUTPUT
				END

				-- if we're replacing an existing status for this document, soft delete the previous entry by setting EndEventReference

				SELECT 
					@CurrentDocumentStatusId = DocumentStatusId
				FROM 
					dbo.DocumentStatus
				WHERE
					DocumentId = @DocumentId
				AND EndEventReference IS NULL

				
				IF (ISNULL(@CurrentDocumentStatusId,0) > 0)
				BEGIN
					-- EndEvent the current one before inserting; we should only have one current DocumentStatus row for this document
					UPDATE 
						dbo.DocumentStatus
					SET 
						EndEventReference = @EventReference
					WHERE
						DocumentId = @DocumentId
					AND EndEventReference IS NULL
				END

				-- insert new row...

				INSERT INTO dbo.DocumentStatus
					(
						DocumentStatusTypeId,
						DocumentId,
						StartEventReference
					)
					VALUES
					(
						@DocumentStatusTypeId,
						@DocumentId,
						@EventReference
					)

				IF @@ROWCOUNT <> 1
					BEGIN
						;
						SET @ErrorMessage = 'Insert into dbo.DocumentStatus created ' + CAST(@@ROWCOUNT AS VARCHAR(20)) + ' rows instead of 1'
						;
						THROW 50005
							,@ErrorMessage
							,1
						;
					END
					;

				SET @DocumentStatusId = SCOPE_IDENTITY()
				;

			COMMIT TRANSACTION

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @DocumentStatusId = NULL
			;
			THROW
			;
		END CATCH

END
