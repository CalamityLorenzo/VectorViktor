﻿CREATE PROCEDURE dbo.usp_Write_CancelDocument
(
	@SchemeValuationSubmissionId	VARCHAR(255),
	@DocumentType					SMALLINT,	
	@UserId							VARCHAR(50),	
	@DocumentId						INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Si Collins
Created on: 	Feb 2026

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@DocumentType					- The Type of the document being cancelled
	@UserId							- The id of the User initiating the event	

Returns: 
	@DocumentId						- The Id of Document that was EndEvented (if found), returns 0 if nothing was EndEvented

Purpose: 
	Used for Cancelling previoulsy uplodaded files. Updates a Document row (if found) for the given ValuationSubmissionId and DocumentType, by setting the EndeventReference

*/

AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RC INT,
			@ValuationSubmissionId INT,
			@ErrorMessage VARCHAR(400),
			@ReturnedEventReference INT		

		BEGIN TRY

			IF(@SchemeValuationSubmissionId IS NULL)
			BEGIN
				SET @ErrorMessage = 'SchemeValuationSubmissionId cannot be null.';
				THROW 50005, @ErrorMessage, 1;
			END


			-- Get ValuationSubmissionId from dbo.ValuationSubmission
			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@ValuationSubmissionId = @ValuationSubmissionId OUTPUT

			IF(@ValuationSubmissionId IS NULL)
			BEGIN
				SET @ErrorMessage = 'Cannot find ValuationSubmissionId from @SchemeValuationSubmissionId: ' + @SchemeValuationSubmissionId + '.';
				THROW 50005, @ErrorMessage, 1;
			END
				
			-- Find relevant Document record to EndEvent, based on DocumentType and ValuationSubmissionId
			SELECT	@DocumentId = DocumentId
			FROM	dbo.Document
			WHERE	DocumentTypeId = @DocumentType 
					AND ValuationSubmissionId = @ValuationSubmissionId 
					AND EndEventReference IS NULL


			IF (@DocumentId IS NULL)
				BEGIN
					-- if no document found, return and do nothing
					RETURN 0
				END
			ELSE

				BEGIN
					BEGIN TRANSACTION;

						-- create USER_UPLOADED_DOCUMENT_CANCELLED event and get ref back
						EXECUTE @RC = dbo.usp_Create_EventById 
								@EventTypeId = 13, -- 'USER_UPLOADED_DOCUMENT_CANCELLED'
								@ValuationSubmissionId = @ValuationSubmissionId,
								@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
								@UserId = @UserId,
								@EventSourceTypeId = 1, -- 'Scheme Valuation Submission'
								@EventReference = @ReturnedEventReference OUTPUT

						-- update Document by setting EndEventReference to the returned event reference from the cancellation event above
						UPDATE	dbo.Document
						SET		EndEventReference = @ReturnedEventReference
						WHERE	DocumentId = @DocumentId

						IF @@ROWCOUNT <> 1
						BEGIN
							SET @ErrorMessage = 'Update dbo.Document failed. Updated ' + CAST(@@ROWCOUNT AS VARCHAR(20)) + ' rows instead of 1';
							THROW 50005, @ErrorMessage, 1;
						END

					COMMIT TRANSACTION				
				END
						

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @DocumentId = NULL
			;
			THROW
			;
		END CATCH

END
