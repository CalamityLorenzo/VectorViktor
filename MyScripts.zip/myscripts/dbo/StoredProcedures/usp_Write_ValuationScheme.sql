﻿CREATE PROCEDURE dbo.usp_Write_ValuationScheme
(
	@PSRNumber INT,
	@SchemeName VARCHAR(100), 
	@EventReference INT, 
	@ValuationSchemeId INT OUTPUT
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	30 July 2024
Reason: Inserts rows in base table dbo.ValuationScheme. 
        If the scheme name for this PSR number has changed, it sets EndEventReference for the previous entry before inserting the new one
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@PSRNumber		- The PSR number of the Scheme to which the event relates
	@SchemeName		- The name of the scheme
	@EventReference	- The unique identifier of the event which idenifies this database action

Returns: 
	@ValuationSchemeId	- The id of the inserted ValuationScheme row

Purpose: 
	Inserts a new ValuationScheme row. 

Comments: 

*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @CurrentValuationSchemeId INT,
				@CurrentSchemeName VARCHAR(100), 
				@EffectiveDateAsString VARCHAR(50), 
				@ErrorMessage VARCHAR(400)

		BEGIN TRY
				
			SELECT 
				@CurrentValuationSchemeId = ValuationSchemeId,
				@CurrentSchemeName = SchemeName
			FROM 
				dbo.ValuationScheme
			WHERE 
				PSRNumber = @PSRNumber
				AND EndEventReference IS NULL

			IF (ISNULL(@CurrentValuationSchemeId, 0) > 0 AND @CurrentSchemeName IS NOT NULL AND @CurrentSchemeName = @SchemeName)

				BEGIN
					-- If the current name is the same as the new name, there's no update required, so return the CurrentValuationSchemeId
					SET @ValuationSchemeId = @CurrentValuationSchemeId
				END
			
			ELSE

				BEGIN

					BEGIN TRANSACTION;				

						IF (ISNULL(@CurrentValuationSchemeId,0) > 0)
						BEGIN
							-- EndEvent the current one before inserting; we should only have one current Scheme for this PSR
							UPDATE 
								dbo.ValuationScheme
							SET 
								EndEventReference = @EventReference
							WHERE 
								PSRNumber = @PSRNumber
							AND EndEventReference IS NULL
						END

						INSERT INTO 
							dbo.ValuationScheme
							(
								PSRNumber,
								SchemeName,
								StartEventReference
							)
						VALUES 
							(
								@PSRNumber,
								@SchemeName,
								@EventReference
							)

						IF @@ROWCOUNT <> 1
							BEGIN
								SET @ErrorMessage = 'Insert to dbo.ValuationScheme created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
								;
								THROW 50005
									,@ErrorMessage
									,1
								;
							END
							;
			
					COMMIT TRANSACTION

					SET @ValuationSchemeId = SCOPE_IDENTITY()
					;

			END
		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @ValuationSchemeId = NULL
			;
			THROW
			;
		END CATCH

END
