CREATE PROCEDURE [dbo].[usp_Read_PsrHasUserSubmissionInProgress]
	@PsrNumber int = 0
	/*
	-----------------------------------------------------------------------
	Created by:		Paul Lawrence
	Created on: 	03 September 2026
	--------------------------------------------------------------------
	Input parameters: 
		@PsrNumber	- The PSR number of the Scheme to check for an in progress submission.
					  Defaults to 0, which causes the procedure to return without a result set.

	Returns: 
		HasInProgressSubmission	- 1 when at least one in progress submission exists for the
								  PSR number, otherwise 0

	Purpose: 
		Indicates whether the Scheme identified by the supplied PSR number has a valuation
		submission currently in progress.

	Comments: 
		A submission counts as in progress when the UserSavedSubmission is still in progress
		(EndEventReference IS NULL) and its current ValuationSubmissionStatus
		(EndEventReference IS NULL) has SubmissionStatusTypeId = 1 (In Progress).
		When @PsrNumber is 0 the procedure returns early with no result set.

	*/
AS
BEGIN
	SET NOCOUNT ON;
	IF @PsrNumber = 0
	BEGIN
		RETURN 0;
	END
		SELECT IIF(Count(*)>0,1, 0) as HasInProgressSubmission
		FROM UserSavedSubmission uss 
		INNER JOIN ValuationSubmission vs on vs.ValuationSubmissionId = uss.ValuationSubmissionId 
		INNER JOIN  ValuationScheme vsch on vsch.ValuationSchemeId = vs.ValuationSchemeId
		INNER JOIN ValuationSubmissionStatus vss on vs.ValuationSubmissionId  = vss.ValuationSubmissionId 
				AND vss.EndEventReference is null 
				AND vss.SubmissionStatusTypeId = 1
		WHERE vsch.PSRNumber = @PsrNumber
		AND uss.EndEventReference is null
END