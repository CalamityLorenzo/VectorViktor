﻿CREATE PROCEDURE [dbo].[usp_Write_UserSavedSubmission]
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@UserId VARCHAR(50),
	@EventSourceTypeId SMALLINT,
	@LastActionPageId UNIQUEIDENTIFIER,
	@LastPageData NVARCHAR(1024),
	@LastUpdated DATETIME2(7),
	@UserSavedSubmissionId INT OUT
)
/* 
-----------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	1 June 2026

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId			- The id used throughout TPR to uniquely identify an individual valuation submission version
	@UserId									- The id of the User initiating the event
	@EventSourceTypeId						- The system carrying out the event - see EventSource table
	@LastActionPageId								- The unique identifier of the last page visited
	@LastPageData							- The data associated with the last page

Returns: 
	@UserSavedSubmissionId					- The id of the inserted UserSavedSubmission row
	@EventReference							- The id of the created Event row

Purpose: 
	Creates an Event (EventTypeId = 14) and then inserts:
	- a new UserSavedSubmission row using that EventReference as StartEventReference

	Also "closes" any previous open rows by setting EndEventReference to the new EventReference:
	- previous UserSavedSubmission rows for this SchemeValuationSubmissionId (where EndEventReference IS NULL)
	- previous UserSavedSubmissionStatus rows for the previous UserSavedSubmissionId (where EndEventReference IS NULL)

Comments: 

*/

AS
BEGIN

SET NOCOUNT ON;

	DECLARE @RC INT,
			@NewUserSubmissionEventReference INT,
			@PreviousUserSavedSubmissionId INT,
			@ValuationSubmissionId INT,
			@ErrorMessage VARCHAR(400),
			@UserSavedSubmissionStartedEventTypeId SMALLINT = 14 -- User Submitted Saved Submission

	BEGIN TRY

		BEGIN TRANSACTION;

			IF(@SchemeValuationSubmissionId IS NULL)
			BEGIN
				SET @ErrorMessage = 'SchemeValuationSubmissionId cannot be null.';
				THROW 50005, @ErrorMessage, 1;
			END

			-- Get ValuationSubmissionId from dbo.ValuationSubmission

			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@ValuationSubmissionId = @ValuationSubmissionId OUTPUT

			-- Find any previous OPEN UserSavedSubmission for this SchemeValuationSubmissionId (we'll close it after inserting the new row)
			SELECT TOP 1
				@PreviousUserSavedSubmissionId = ums.UserSavedSubmissionId
			FROM dbo.UserSavedSubmission ums
			WHERE ums.ValuationSubmissionId = @ValuationSubmissionId
				AND ums.EndEventReference IS NULL
			ORDER BY ums.LastUpdated DESC, ums.UserSavedSubmissionId DESC
			;

			-- Create Event row
			EXECUTE @RC = dbo.usp_Create_EventById 
				@EventTypeId = @UserSavedSubmissionStartedEventTypeId,
				@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
				@UserId = @UserId,
				@EventSourceTypeId = @EventSourceTypeId,
				@EventReference = @NewUserSubmissionEventReference OUTPUT
			;

			-- Insert the new UserSavedSubmission record
			INSERT INTO [dbo].[UserSavedSubmission]
			(
				[ValuationSubmissionId],
				[LastUpdated],
				[LastActionPageId],
				[LastPageData],
				[StartEventReference]
			)
			VALUES
			(
				@ValuationSubmissionId,
				@LastUpdated,
				@LastActionPageId,
				@LastPageData,
				@NewUserSubmissionEventReference
			)
			;

			IF @@ROWCOUNT <> 1
			BEGIN
				SET @ErrorMessage = 'Insert to dbo.UserSavedSubmission created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
				;
				THROW 50005
					,@ErrorMessage
					,1
				;
			END
			;

			SET @UserSavedSubmissionId = SCOPE_IDENTITY()
			;

			-- Close any previous OPEN USerSavedSubmission rows for this submission id (excluding the just inserted row)

			UPDATE [dbo].[UserSavedSubmission]
			SET [EndEventReference] = @NewUserSubmissionEventReference
			WHERE [ValuationSubmissionId] = @ValuationSubmissionId
			  AND [EndEventReference] IS NULL
			  AND [UserSavedSubmissionId] <> @UserSavedSubmissionId

		COMMIT TRANSACTION

	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT <> 0
			ROLLBACK TRANSACTION
		;
		SET @UserSavedSubmissionId = NULL
		;
		THROW
		;
	END CATCH

END