﻿CREATE PROCEDURE [dbo].[usp_Read_IsUserSubmissionInProgress]
	@UserSavedSubmissionId int
/*
-----------------------------------------------------------------------
Created by:		Paul Lawrence
Created on: 	03 September 2026
--------------------------------------------------------------------
Input parameters: 
	@UserSavedSubmissionId	- The id of the UserSavedSubmission to check

Returns: 
	SchemeValuationSubmissionId
	EffectiveDate

Purpose: 
	Returns the SchemeValuationSubmissionId and EffectiveDate of the ValuationSubmission
	linked to the specified UserSavedSubmission, indicating a submission is in progress.

Comments: 
	Only returns the row if the UserSavedSubmission is still 'In Progress' (EndEventReference IS NULL).
	No rows are returned when the saved submission does not exist or has been closed.

*/

AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
	vs.SchemeValuationSubmissionId,
	vs.EffectiveDate
	FROM UserSavedSubmission uss 
	INNER JOIN ValuationSubmission vs on vs.ValuationSubmissionId = uss.ValuationSubmissionId
	INNER JOIN  ValuationScheme vsch on vsch.ValuationSchemeId = vs.ValuationSchemeId
	WHERE uss.UserSavedSubmissionId = @UserSavedSubmissionId
	AND uss.EndEventReference is null
END