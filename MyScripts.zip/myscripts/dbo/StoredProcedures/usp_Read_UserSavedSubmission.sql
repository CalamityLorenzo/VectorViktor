﻿CREATE PROCEDURE [dbo].[usp_Read_UserSavedSubmission]
	@PsrNumber INT
/*
-----------------------------------------------------------------------
Created by:		Denise Groves
Created on: 	1 June 2026
--------------------------------------------------------------------
Input parameters: 
	@PSRNumber	- The PSR number of the Scheme to which the submissions relate

Returns: 
	UserSavedSubmissionId
	PSRNumber
	SchemeValuationSubmissionId
	EffectiveDate
	LastActionPageId
	LastPageData
	LastUpdated
	UserSavedSubmissionStatusTypeId
	UserSavedSubmissionStatusType

Purpose: 
	Returns UserSavedSubmission rows for a PSRNumber, with the current (open) status type description.
	Results are ordered by LastUpdated descending.

Comments: 
	Only returns OPEN rows (EndEventReference IS NULL) for both UserSavedSubmission and UserSavedSubmissionStatus.

*/

AS

BEGIN
	SET NOCOUNT ON;
	
    SELECT  
        u.[UserSavedSubmissionId],
        sch.PSRNumber,
        vs.[SchemeValuationSubmissionId],
        vs.[EffectiveDate],
        u.[LastActionPageId],
        u.[LastPageData],
        u.[LastUpdated],
        sta.SubmissionStatusTypeId,
        sst.SubmissionStatusDescription,
		vc.CaseReference
    FROM 
        [dbo].[UserSavedSubmission] u
    INNER JOIN dbo.ValuationSubmission vs
        ON vs.ValuationSubmissionId = u.ValuationSubmissionId
       AND vs.EndEventReference IS NULL
    INNER JOIN dbo.ValuationSubmissionStatus sta
        ON vs.ValuationSubmissionId = sta.ValuationSubmissionId
       AND sta.EndEventReference IS NULL
    INNER JOIN dbo.SubmissionStatusType sst
        ON sst.SubmissionStatusTypeId = sta.SubmissionStatusTypeId
    INNER JOIN dbo.ValuationScheme sch
        ON sch.ValuationSchemeId = vs.ValuationSchemeId
    LEFT OUTER JOIN dbo.ValuationCase vc
        ON vc.ValuationSubmissionId = vs.ValuationSubmissionId
       AND vc.EndEventReference IS NULL
    WHERE u.EndEventReference IS NULL
    AND sch.PSRNumber = @PsrNumber

    ORDER BY u.LastUpdated DESC
  
END