﻿/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Paul Lawrence
Created on: 	24 Oct 2024
Reason:			Retrieves key data for a currently submitted Submission
				Once a submission is made certain info is required to update the SOS.				
				This is fired at the point the SOS is sent to be published.
				It cannot be guaranteed to work at any other time. If a PSR updates the effective date or makes a new submission 
				with the same effective date, this procedure is invalid for that SchemeValuationSubmissionId.
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
Returns: 
	SubmissionId, EffectiveDate, ValuationSubmissionId, SubmissionStatusTypeId,DateFundingAndInvestmentStrategyWasFinalised,DateStatementOfStrategyWasSigned, DateSubmitted
Comments: 

*/
CREATE PROCEDURE [dbo].[usp_Read_SubmittedSubmission]
	@SchemeValuationSubmissionId  VARCHAR(255)
AS

BEGIN
		SET NOCOUNT ON;

		DECLARE  @ValuationSubmissionId INT
				,@EffectiveDate DATE
				,@ValSubmissionEndEventId INT
				,@FISSignedDate DATE
				,@SOSSignedDate DATE
				,@SubmittedDate DATETIME
				,@ErrorMessage VARCHAR(400)
				,@SubmissionStatusTypeId INT = 2; -- Submitted

		  -- VALUATION SUBMISSION
		  SELECT @SchemeValuationSubmissionId = SchemeValuationSubmissionId
				,@ValuationSubmissionId = ValuationSubmissionId
				,@SubmissionStatusTypeId  = SubmissionStatusTypeId 
				,@EffectiveDate = EffectiveDate 				
				,@FISSignedDate = DateFundingAndInvestmentStrategyWasFinalised
				,@SOSSignedDate = DateStatementOfStrategyWasSigned
				,@SubmittedDate = ISNULL(SubmittedDateTime, CreateDateTime)			-- old submissions won't have SubmittedDateTime so use CreateDateTime instead 
		  FROM dbo.uvw_SchemeValuationSubmissions svs
		  WHERE svs.SchemeValuationSubmissionId = @SchemeValuationSubmissionId
		  AND @SubmissionStatusTypeId = svs.SubmissionStatusTypeId;


			-- 3 SubmissionStatusTypeId 'Cancelled' (Technically should not be able to reach this)
			-- 1
			-- NULL is unexpected
			IF(@SubmissionStatusTypeId IS NULL) 
				BEGIN
					SET @ErrorMessage = 'Cannot find "' + @SchemeValuationSubmissionId + '" status.';
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END
			IF(@SubmissionStatusTypeId = 3) 
				BEGIN
					SET @ErrorMessage = 'Scheme Cancelled "' + @SchemeValuationSubmissionId + '".';
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END

			IF(@SubmissionStatusTypeId = 1) 
				BEGIN
					SET @ErrorMessage = 'Scheme not submitted "' + @SchemeValuationSubmissionId + '".';
					;
					THROW 50005,
						@ErrorMessage
						,1;
				END


			SELECT  
				@SchemeValuationSubmissionId AS SchemeValuationSubmissionId
				,@ValuationSubmissionId AS ValuationSubmissionId
				,@SubmissionStatusTypeId AS SubmissionStatusTypeId
				,@EffectiveDate AS EffectiveDate
				,@FISSignedDate AS DateFundingAndInvestmentStrategyWasFinalised
				,@SOSSignedDate AS DateStatementOfStrategyWasSigned		
				,@SubmittedDate AS DateSubmitted
END
GO