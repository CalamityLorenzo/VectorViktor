﻿
CREATE PROCEDURE [dbo].[usp_Read_DocumentMetadata]
	@SchemeValuationSubmissionId VARCHAR(255),
	@SubmissionStatusType INT = NULL

/* 
-----------------------------------------------------------------------
Created by: 	samuelh
Created on: 	20 Oct 2025

--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@SubmissionStatusType			- The id is the status e.g. 1 - IN PROGRESS 2 - SUBMITTED 3 - CANCELLED

Returns: 
	Document metadata result set

Purpose: 
	Reads the document metadata.

Comments: 


*/

AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT 
		[ValuationSchemeId],
		[PSRNumber],
		submissions.[ValuationSubmissionId],
		[SchemeValuationSubmissionId],
		[ValuationSubmissionStatusId],
		[SubmissionStatusTypeId],
		[UploadedFileName],
		[InternalFileName],
		[FileHash],
		[FileSize],
		[SagaUploadedFileCorrelationId],
		[DocumentTypeId] as DocumentType,
		[DocumentTypeDescription],
		[DocumentStatusId],
		[DocumentStatusTypeId],
		[DocumentStatusName],
		[DocumentStatusDescription]
	FROM
		[dbo].[uvw_SchemeValuationSubmissions] submissions
	INNER JOIN
		[dbo].[uvw_Documents_Current] docs
	ON submissions.ValuationSubmissionId = docs.ValuationSubmissionId
	WHERE
		submissions.SchemeValuationSubmissionId = @SchemeValuationSubmissionId
	AND (@SubmissionStatusType IS NULL
		OR (@SubmissionStatusType IS NOT NULL AND @SubmissionStatusType = submissions.SubmissionStatusTypeId))

END


