﻿CREATE PROCEDURE dbo.usp_Write_ValuationCase
(
	@SchemeValuationSubmissionId VARCHAR(255),
	@CaseReference VARCHAR(50),
	@UserId VARCHAR(50),
	@EventType SMALLINT,
	@EventSourceType SMALLINT, 
	@NotificationDate DATETIME2 = NULL,
	@ValuationCaseId INT OUT
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Created on: 	9 Sept 2024
Reason:			Inserts rows in table dbo.ValuationCase, to assign a D365 case id to the submission
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version
	@CaseReference					- The case reference assigned (by D365)
	@UserId							- The id of the User initiating the event
	@EventType						- Id fron the EventType table - the type of event taking place
	@EventSourceType				- Id from the EventSource table, identifying the system calling this stored procedure e.g. Scheme Valuation
Returns: 
	@ValuationCaseId				- The id of the inserted ValuationCase row (or the existing row if we already hold the specified Case ID for this SchemeValuation

Purpose: 
	Inserts a new ValuationCase row. 

Comments: 

*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @ValuationSubmissionId INT, 
				@ReturnedEventReference INT,
				@CurrentCaseReference VARCHAR(50),
				@CurrentValuationCaseId INT,
				@ErrorMessage VARCHAR(512),
				@RC INT

		BEGIN TRY
		
			-- Get ValuationSubmissionId from dbo.ValuationSubmission (We need to allow for either current OR cancelled/end-dated submissions, in case simultaneous 
			-- submissions are being submitted (e.g. automation tests), so don't use uvw_SchemeValuationSubmissions_Current here)

			EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@ValuationSubmissionId = @ValuationSubmissionId OUTPUT
		

			-- if we already have this case ID for this valuationSubmission, just set the @ValuationSubmissionId out param and return

			SELECT 
				@CurrentCaseReference = CaseReference,
				@CurrentValuationCaseId = ValuationCaseId
			FROM 
				dbo.ValuationCase
			WHERE 
				ValuationSubmissionId = @ValuationSubmissionId
				AND EndEventReference IS NULL

			IF (ISNULL(@CurrentValuationCaseId,0) > 0 AND @CurrentCaseReference IS NOT NULL AND @CurrentCaseReference = @CaseReference)
			BEGIN
				SET @ValuationCaseId = @CurrentValuationCaseId
				RETURN
			END

			BEGIN TRANSACTION;		

				EXECUTE @RC = dbo.usp_Create_EventById 
						@EventTypeId = @EventType,				
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@UserId = @UserId,
						@EventSourceTypeId = @EventSourceType,
						@NotificationDate = @NotificationDate,
						@EventReference = @ReturnedEventReference OUTPUT

				IF (ISNULL(@CurrentValuationCaseId,0) > 0)
				BEGIN
					-- EndEvent the current one before inserting; we should only have one current ValuationCase row for this valuation submission
					UPDATE 
						dbo.ValuationCase
					SET 
						EndEventReference = @ReturnedEventReference
					WHERE 
						ValuationSubmissionId = @ValuationSubmissionId
						AND EndEventReference IS NULL
				END

				INSERT INTO 
					dbo.ValuationCase
					(
						ValuationSubmissionId,
						CaseReference,
						StartEventReference
					)
				VALUES 
					(
						@ValuationSubmissionId,
						@CaseReference,
						@ReturnedEventReference
					)

				IF @@ROWCOUNT <> 1
					BEGIN
						SET @ErrorMessage = 'Insert to dbo.ValuationCase created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
						;
						THROW 50005
							,@ErrorMessage
							,1
						;
					END
					;
			
			COMMIT TRANSACTION

			SET @ValuationCaseId = SCOPE_IDENTITY()
			;

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @ValuationCaseId = NULL
			;
			THROW
			;
		END CATCH

END
