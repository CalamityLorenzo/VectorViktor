﻿CREATE PROCEDURE dbo.usp_Write_ValuationSubmissionData
(
    @QuestionsAndResponses VARCHAR(MAX),   
    @DocumentId INT,
	@UserId VARCHAR(50),
	@SchemeValuationSubmissionId VARCHAR(255),
	@EventSourceType SMALLINT,
	@ValuationSubmissionDataId INT OUT
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Joel Godden
Created on: 	05 November 2024
Reason:			Inserts rows in table dbo.ValuationSubmissionData, to record valuation data from uploaded Excel form
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@QuestionsAndResponses			- JSON representation of the valuation data from the uploaded Excel form.
	@DocumentId						- Id of the uploaded document
Returns: 
	@ValuationSubmissionDataId		- The id of the inserted ValuationSubmissionData row

Purpose: 
	Inserts a new ValuationSubmissionData row. 

Comments: 

*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE
				@ErrorMessage VARCHAR(512),
				@EventType SMALLINT = 10, -- STATEMENT_OF_STRATEGY_EXTRACTED
				@RC INT,
				@ReturnedEventReference INT

		BEGIN TRY

			SELECT
				@ValuationSubmissionDataId = vsd.ValuationSubmissionDataId
			FROM
				dbo.ValuationSubmissionData vsd
			WHERE
			    vsd.DocumentId = @DocumentId
				AND vsd.EndEventReference IS NULL

			BEGIN TRANSACTION;

					EXECUTE @RC = dbo.usp_Create_EventById
							@EventTypeId = @EventType,
							@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
							@UserId = @UserId,
							@EventSourceTypeId = @EventSourceType,
							@EventReference = @ReturnedEventReference OUTPUT

					IF (ISNULL(@ValuationSubmissionDataId,0) > 0)
						BEGIN
							UPDATE
								dbo.ValuationSubmissionData
							SET
								EndEventReference = @ReturnedEventReference
							WHERE
								ValuationSubmissionDataId = @ValuationSubmissionDataId
							AND EndEventReference IS NULL
						END


				IF @ValuationSubmissionDataId IS NULL
					BEGIN
						INSERT INTO
							dbo.ValuationSubmissionData
							(
								QuestionsAndResponses,
								DocumentId,
								[StartEventReference]
							)
						VALUES
							(
								@QuestionsAndResponses,
								@DocumentId,
								@ReturnedEventReference
							)

						IF @@ROWCOUNT <> 1
							BEGIN
								SET @ErrorMessage = 'Insert to dbo.ValuationSubmissionData created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
								;
								THROW 50005
									,@ErrorMessage
									,1
								;
							END
							;
						SET @ValuationSubmissionDataId = SCOPE_IDENTITY()
					END
			COMMIT TRANSACTION

			;

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @ValuationSubmissionDataId = NULL
			;
			THROW
			;
		END CATCH

END
