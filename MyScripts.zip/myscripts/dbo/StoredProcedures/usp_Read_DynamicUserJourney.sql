﻿CREATE PROCEDURE [dbo].[usp_Read_DynamicUserJourney]
	@SchemeValuationSubmissionId  VARCHAR(255)
/*
-----------------------------------------------------------------------
Created by: 	DeniseG
Created on: 	22 May 2026
--------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId	- The id used throughout TPR to uniquely identify an individual valuation submission version

Returns: 
	
    [DynamicUserJourneyId]          - the id of the dynammic user journey record
    [ValuationSubmissionId]         - the id of the valuation submission record associated with this dynamic user journey
    [FastTrackOrBespokeTypeId]      - the type of valuation (fast track or bespoke)
    [DeficitOrSurplusTypeId]        - the deficit/surplus status of the uploaded valuation
    [AdditionalRequiredDocumentTypeId] - the type of additional document required (if applicable)
    [IsMultiDocUpload]              - whether this is a multi-document upload (i.e. whether the user will be uploading multiple documents as part of this journey)
    [StartEventReference]           - the reference to the event record for the start of this dynamic user journey

Purpose: To read the details of a submission

Comments: 

*/
AS
BEGIN
    SET NOCOUNT ON;

	SELECT d.[DynamicUserJourneyId]
		,d.[ValuationSubmissionId]
		,d.[FastTrackOrBespokeTypeId]
		,d.[DeficitOrSurplusTypeId]
		,d.[AdditionalRequiredDocumentTypeId]
		,d.[IsMultiDocUpload]
		,d.[StartEventReference]
		,d.[EndEventReference]
    FROM 
        [dbo].[DynamicUserJourney] d
	INNER JOIN dbo.ValuationSubmission vs
	ON
		d.ValuationSubmissionId = vs.ValuationSubmissionId
	WHERE 
		vs.SchemeValuationSubmissionId = @SchemeValuationSubmissionId
	AND d.EndEventReference IS NULL

END

GO;
