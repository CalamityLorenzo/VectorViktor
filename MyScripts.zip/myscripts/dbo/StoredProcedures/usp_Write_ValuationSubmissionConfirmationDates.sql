﻿CREATE PROCEDURE dbo.usp_Write_ValuationSubmissionConfirmationDates
(
	@SchemeValuationSubmissionId VARCHAR(255),
    @DateFundingAndInvestmentStrategyWasFinalised DATE,   
    @DateStatementOfStrategyWasSigned DATE,   
	@UserId VARCHAR(50),
	@EventSourceType SMALLINT,
	@ValuationSubmissionConfirmationDatesId INT OUT
)
/* 
-----------------------------------------------------------------------------------------------------------------------------------------
Created by: 	Ben Hughes
Created on: 	25 February 2025
Reason:			Inserts rows in table dbo.ValuationSubmissionConfirmationDates, to record confirmation dates provided by user
-----------------------------------------------------------------------------------------------------------------------------------------
Input parameters: 
	@SchemeValuationSubmissionId					- Id of the scheme valuation submission this data relates to
	@DateFundingAndInvestmentStrategyWasFinalised	- The date the funding and investment strategy was finalised
	@DateStatementOfStrategyWasSigned				- The date the statement of strategy was signed
	@UserId											- The id of the user making the submission
	@EventSourceType								- The underlying event type that this action was triggered by
Returns: 
	@ValuationSubmissionConfirmationDatesId			- The id of the inserted ValuationSubmissionConfirmationDates row

Purpose: 
	Inserts the confirmation dates provided by the user
*/

AS
BEGIN
	SET NOCOUNT ON;

		DECLARE
				@ErrorMessage VARCHAR(512),
				@EventType SMALLINT = 11, -- CONFIRMATION_DATES_ADDED
				@RC INT,
				@ReturnedEventReference INT,
				@ValuationSubmissionId INT

		BEGIN TRY

			BEGIN TRANSACTION;

				-- Use the SchemeValuationSubmissionId to get the ValuationSubmissionId
				EXECUTE @RC = [dbo].[usp_Read_ValuationSubmissionId] 
							@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
							@ValuationSubmissionId = @ValuationSubmissionId OUTPUT

				-- Create a new event for this call
				EXECUTE @RC = dbo.usp_Create_EventById
						@EventTypeId = @EventType,
						@SchemeValuationSubmissionId = @SchemeValuationSubmissionId,
						@UserId = @UserId,
						@EventSourceTypeId = @EventSourceType,
						@EventReference = @ReturnedEventReference OUTPUT
			
				-- Get if there is an existing row for this ValuationSubmissionId
				SELECT
					@ValuationSubmissionConfirmationDatesId = vscd.ValuationSubmissionConfirmationDatesId
				FROM
					dbo.ValuationSubmissionConfirmationDates vscd
				WHERE
					vscd.ValuationSubmissionId = @ValuationSubmissionId
					AND vscd.EndEventReference IS NULL


				-- If there is an existing row then use this new event id to mark the end of the previous row
				IF (ISNULL(@ValuationSubmissionConfirmationDatesId, 0) > 0)
					BEGIN
						UPDATE
							dbo.ValuationSubmissionConfirmationDates
						SET
							EndEventReference = @ReturnedEventReference
						WHERE
							ValuationSubmissionConfirmationDatesId = @ValuationSubmissionConfirmationDatesId
						AND EndEventReference IS NULL
					END

				-- Now insert a new row for this submission
				INSERT INTO
					dbo.ValuationSubmissionConfirmationDates
					(
						ValuationSubmissionId,
						DateFundingAndInvestmentStrategyWasFinalised,
						DateStatementOfStrategyWasSigned,
						[StartEventReference]
					)
				VALUES
					(
						@ValuationSubmissionId,
						@DateFundingAndInvestmentStrategyWasFinalised,
						@DateStatementOfStrategyWasSigned,
						@ReturnedEventReference
					)

				-- Throw out if the wrong number of rows were affected
				IF @@ROWCOUNT <> 1
					BEGIN
						SET @ErrorMessage = 'Insert to dbo.ValuationSubmissionConfirmationDates created ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' row(s) instead of 1'
						;
						THROW 50005
							,@ErrorMessage
							,1
						;
					END
					;
				SET @ValuationSubmissionConfirmationDatesId = SCOPE_IDENTITY()

			COMMIT TRANSACTION

			;

		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT <> 0
				ROLLBACK TRANSACTION
			;
			SET @ValuationSubmissionConfirmationDatesId = NULL
			;
			THROW
			;
		END CATCH

END
