﻿CREATE TABLE [dbo].[SubmissionStatusType] (
    [SubmissionStatusTypeId]      SMALLINT      NOT NULL,
    [SubmissionStatusName]      VARCHAR(16)      NOT NULL,
    [SubmissionStatusDescription] VARCHAR (100) NOT NULL
    CONSTRAINT [PK_SubmissionStatusType] PRIMARY KEY CLUSTERED ([SubmissionStatusTypeId] ASC), 
    [IsActive] BIT NOT NULL DEFAULT 1
);

