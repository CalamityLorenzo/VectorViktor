﻿CREATE TABLE [dbo].[ValuationCase] (
    [ValuationCaseId]           INT              IDENTITY (1, 1) NOT NULL,
    [ValuationSubmissionId]     INT              NOT NULL,
    [CaseReference]             VARCHAR(50)      NOT NULL,
    [StartEventReference]       INT              NOT NULL,
    [EndEventReference]         INT              NULL,
    CONSTRAINT [PK_ValuationCase] PRIMARY KEY CLUSTERED ([ValuationCaseId] ASC),
    CONSTRAINT [FK_ValuationCase_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
    CONSTRAINT [FK_ValuationCase_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationCase_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO

CREATE NONCLUSTERED INDEX [IX_ValuationCase_ValuationSubmissionId]
    ON [dbo].[ValuationCase] ([ValuationSubmissionId] ASC)
    INCLUDE ([CaseReference], [EndEventReference]);
GO

