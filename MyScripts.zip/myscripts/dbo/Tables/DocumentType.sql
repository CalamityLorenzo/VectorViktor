﻿CREATE TABLE [dbo].[DocumentType] (
    [DocumentTypeId]      SMALLINT      NOT NULL,
    [DocumentTypeName]    VARCHAR (50)  NOT NULL,
    [DocumentTypeDescription] VARCHAR (200) NOT NULL,
    CONSTRAINT [PK_DocumentType] PRIMARY KEY CLUSTERED ([DocumentTypeId] ASC), 
    [IsActive] BIT NOT NULL DEFAULT 1
);

