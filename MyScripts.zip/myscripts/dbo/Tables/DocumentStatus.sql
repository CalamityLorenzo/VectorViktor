﻿CREATE TABLE [dbo].[DocumentStatus] (
    [DocumentStatusId]     INT              IDENTITY (1, 1) NOT NULL,
    [DocumentStatusTypeId] SMALLINT         NOT NULL,
    [DocumentId]           INT              NOT NULL,
    [StartEventReference]  INT              NOT NULL,
    [EndEventReference]    INT              NULL,
    CONSTRAINT [PK_DocumentStatus] PRIMARY KEY CLUSTERED ([DocumentStatusId] ASC),
    CONSTRAINT [FK_DocumentStatus_Document] FOREIGN KEY ([DocumentId]) REFERENCES [dbo].[Document] ([DocumentId]),
    CONSTRAINT [FK_DocumentStatus_DocumentStatusType] FOREIGN KEY ([DocumentStatusTypeId]) REFERENCES [dbo].[DocumentStatusType] ([DocumentStatusTypeId]),
    CONSTRAINT [FK_DocumentStatus_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_DocumentStatus_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);

