﻿CREATE TABLE [dbo].[GuardQuestionAnswer] (
    [GuardQuestionAnswerId]  INT           NOT NULL,
    [GuardQuestionId]        INT           NOT NULL,
    [GuardAnswerName]        VARCHAR(50)   NOT NULL,
    [GuardAnswerDescription] VARCHAR (200) NOT NULL,
    CONSTRAINT [PK_GuardQuestionAnswer] PRIMARY KEY CLUSTERED ([GuardQuestionAnswerId] ASC),
    CONSTRAINT [FK_GuardQuestionAnswer_GuardQuestion] FOREIGN KEY ([GuardQuestionId]) REFERENCES [dbo].[GuardQuestion] ([GuardQuestionId])
);

