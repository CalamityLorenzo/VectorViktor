﻿CREATE TABLE [dbo].[ValuationSubmissionGuardQuestionAnswer] (
    [ValuationSubmissionGuardQuestionAnswerId] INT IDENTITY (1, 1) NOT NULL,
    [ValuationSubmissionId]                    INT NOT NULL,
    [GuardQuestionAnswerId]                    INT NOT NULL,
    [StartEventReference]                      INT NOT NULL,
    [EndEventReference]                        INT NULL,
    CONSTRAINT [PK_ValuationSubmissionGuardQuestionAnswer] PRIMARY KEY CLUSTERED ([ValuationSubmissionGuardQuestionAnswerId] ASC),
    CONSTRAINT [FK_ValuationSubmissionGuardQuestionAnswer_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
    CONSTRAINT [FK_ValuationSubmissionGuardQuestionAnswer_GuardQuestionAnswer] FOREIGN KEY ([GuardQuestionAnswerId]) REFERENCES [dbo].[GuardQuestionAnswer] ([GuardQuestionAnswerId]),
    CONSTRAINT [FK_ValuationSubmissionGuardQuestionAnswer_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmissionGuardQuestionAnswer_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);

