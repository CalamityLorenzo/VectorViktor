﻿ CREATE TABLE [dbo].[ValuationSubmissionConfirmationDates] (
    [ValuationSubmissionConfirmationDatesId]            INT     IDENTITY (1, 1) NOT NULL,
    [ValuationSubmissionId]                             INT     NOT NULL,
    [DateFundingAndInvestmentStrategyWasFinalised]      DATE    NOT NULL,
    [DateStatementOfStrategyWasSigned]                  DATE    NOT NULL,
    [StartEventReference]                               INT     NOT NULL,
    [EndEventReference]                                 INT     NULL,
    CONSTRAINT [PK_ValuationSubmissionConfirmationDates] PRIMARY KEY CLUSTERED ([ValuationSubmissionConfirmationDatesId] ASC),
    CONSTRAINT [FK_ValuationSubmissionConfirmationDates_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),   
    CONSTRAINT [FK_ValuationSubmissionConfirmationDates_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmissionConfirmationDates_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO
CREATE NONCLUSTERED INDEX [IX_ValuationSubmissionConfirmationDates_ValuationSubmissionId]
    ON [dbo].[ValuationSubmissionConfirmationDates] ([ValuationSubmissionId] ASC)
    INCLUDE ([DateFundingAndInvestmentStrategyWasFinalised],
             [DateStatementOfStrategyWasSigned], [EndEventReference]);
GO

