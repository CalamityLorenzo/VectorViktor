﻿CREATE TABLE [dbo].[UserSavedSubmission]
(
	[UserSavedSubmissionId] INT IDENTITY(1,1) NOT NULL,
	[ValuationSubmissionId] INT NOT NULL,
	[LastUpdated] DATETIME2 NOT NULL,
	[LastActionPageId] UNIQUEIDENTIFIER NOT NULL,
	[LastPageData] NVARCHAR(1024) NOT NULL,
	[StartEventReference] INT NOT NULL,
	[EndEventReference] INT NULL,
	CONSTRAINT [PK_UserSavedSubmission] PRIMARY KEY CLUSTERED ([UserSavedSubmissionId] ASC),
	INDEX [IX_UserSavedSubmission_ValuationSubmissionId] NONCLUSTERED ([ValuationSubmissionId] ASC),
	CONSTRAINT [FK_UserSavedSubmission_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
	CONSTRAINT [FK_UserSavedSubmission_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_UserSavedSubmission_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
)