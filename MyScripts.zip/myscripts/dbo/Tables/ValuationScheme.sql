﻿CREATE TABLE [dbo].[ValuationScheme] (
    [ValuationSchemeId]   INT           IDENTITY (1, 1) NOT NULL,
    [PSRNumber]           INT           NOT NULL,
    [SchemeName]          VARCHAR (100) NOT NULL,
    [StartEventReference] INT           NOT NULL,
    [EndEventReference]   INT           NULL,
    CONSTRAINT [PK_ValuationScheme] PRIMARY KEY CLUSTERED ([ValuationSchemeId] ASC),
    CONSTRAINT [FK_ValuationScheme_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationScheme_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO
CREATE NONCLUSTERED INDEX [IX_ValuationScheme_PSRNumber]
    ON [dbo].[ValuationScheme] ([PSRNumber] ASC);
GO
