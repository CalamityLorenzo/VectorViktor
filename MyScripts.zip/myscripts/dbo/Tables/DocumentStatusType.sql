﻿CREATE TABLE [dbo].[DocumentStatusType] (
    [DocumentStatusTypeId]  SMALLINT      NOT NULL,
    [DocumentStatusName] VARCHAR (50) NOT NULL,
    [DocumentStatusDescription] VARCHAR (100) NOT NULL
    CONSTRAINT [PK_DocumentStatusType] PRIMARY KEY CLUSTERED ([DocumentStatusTypeId] ASC), 
    [IsActive] BIT NOT NULL DEFAULT 1
);

