﻿CREATE TABLE [dbo].[Document] (
    [DocumentId]            INT IDENTITY (1, 1) NOT NULL,
    [ValuationSubmissionId] INT              NOT NULL,
    [UploadedFileName]      VARCHAR (512)    NOT NULL,
    [InternalFileName]      VARCHAR (512)    NOT NULL,
    [FileHash]              VARCHAR (512)    NOT NULL,
    [FileSize]              BIGINT           NULL,
    [SagaUploadedFileCorrelationId]     UNIQUEIDENTIFIER NOT NULL DEFAULT CAST(0x0 AS UNIQUEIDENTIFIER),
    [DocumentTypeId]        SMALLINT         NOT NULL,
    [StartEventReference]   INT              NOT NULL,
    [EndEventReference]     INT              NULL,
    CONSTRAINT [PK_Document] PRIMARY KEY CLUSTERED ([DocumentId] ASC),
    CONSTRAINT [FK_Document_DocumentType] FOREIGN KEY ([DocumentTypeId]) REFERENCES [dbo].[DocumentType] ([DocumentTypeId]),
    CONSTRAINT [FK_Document_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
    CONSTRAINT [FK_Document_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_Document_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO 
CREATE NONCLUSTERED INDEX [IX_Document_ValuationSubmissionId]
    ON [dbo].[Document] ([ValuationSubmissionId] ASC)
    INCLUDE ([UploadedFileName], [InternalFileName], [FileHash], [FileSize], [DocumentTypeId], [EndEventReference], [SagaUploadedFileCorrelationId]);
GO

