﻿CREATE TABLE [dbo].[ValuationSubmissionStatus] (
    [ValuationSubmissionStatusId] INT      IDENTITY (1, 1) NOT NULL,
    [SubmissionStatusTypeId]      SMALLINT NOT NULL,
    [ValuationSubmissionId]       INT      NOT NULL,
    [StartEventReference]         INT      NOT NULL,
    [EndEventReference]           INT      NULL,
    CONSTRAINT [PK_ValuationSubmissionStatus] PRIMARY KEY CLUSTERED ([ValuationSubmissionStatusId] ASC),
    CONSTRAINT [FK_ValuationSubmissionStatus_Event] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmissionStatus_SubmissionStatusType] FOREIGN KEY ([SubmissionStatusTypeId]) REFERENCES [dbo].[SubmissionStatusType] ([SubmissionStatusTypeId]),
    CONSTRAINT [FK_ValuationSubmissionStatus_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
    CONSTRAINT [FK_ValuationSubmissionStatus_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmissionStatus_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])

    );
    GO

    CREATE NONCLUSTERED INDEX [IX_ValuationSubmissionStatus_ValuationSubmissionId]
    ON [dbo].[ValuationSubmissionStatus] ([ValuationSubmissionId] ASC)
    INCLUDE ([SubmissionStatusTypeId], [EndEventReference]);
    GO


