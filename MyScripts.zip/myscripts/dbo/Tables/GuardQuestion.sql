﻿CREATE TABLE [dbo].[GuardQuestion] (
    [GuardQuestionId]  INT           NOT NULL,
    [GuardQuestionName] VARCHAR (50) NOT NULL,
    [GuardQuestionDescription] VARCHAR (200) NOT NULL
    CONSTRAINT [PK_GuardQuestion] PRIMARY KEY CLUSTERED ([GuardQuestionId] ASC), 
    [IsActive] BIT NOT NULL DEFAULT 1
);

