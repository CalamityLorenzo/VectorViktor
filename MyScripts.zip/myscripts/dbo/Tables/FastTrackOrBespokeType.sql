﻿CREATE TABLE [dbo].[FastTrackOrBespokeType]
(
	[FastTrackOrBespokeTypeId]              SMALLINT NOT NULL,
	[FastTrackOrBespokeName]                VARCHAR(20) NOT NULL,
    [FastTrackOrBespokeDescription]         VARCHAR (100) NOT NULL
    CONSTRAINT [PK_FastTrackOrBespokeType]  PRIMARY KEY CLUSTERED ([FastTrackOrBespokeTypeId] ASC), 
    [IsActive]                              BIT NOT NULL DEFAULT 1
)
