﻿CREATE TABLE [dbo].[DeficitOrSurplusType]
(
	[DeficitOrSurplusTypeId]                SMALLINT NOT NULL,
	[DeficitOrSurplusName]                  VARCHAR(20)NOT NULL,
    [DeficitOrSurplusDescription]           VARCHAR (100) NOT NULL
    CONSTRAINT [PK_DeficitOrSurplusType]    PRIMARY KEY CLUSTERED ([DeficitOrSurplusTypeId] ASC), 
    [IsActive]                              BIT NOT NULL DEFAULT 1
)
