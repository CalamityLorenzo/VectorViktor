﻿CREATE TABLE [dbo].[AdditionalRequiredDocumentType]
(
	[AdditionalRequiredDocumentTypeId] SMALLINT NOT NULL,
    [AdditionalRequiredDocumentName]    VARCHAR (50)  NOT NULL,
    [AdditionalRequiredDocumentDescription] VARCHAR (200) NOT NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    CONSTRAINT [PK_AdditionalRequiredDocumentType] PRIMARY KEY CLUSTERED ([AdditionalRequiredDocumentTypeId] ASC)
)
