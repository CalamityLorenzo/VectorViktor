﻿CREATE TABLE [dbo].[EventSourceType] (
    [EventSourceTypeId]   SMALLINT NOT NULL,
    [EventSourceName] VARCHAR (75) NOT NULL,
    [EventSourceDescription] VARCHAR (100) NOT NULL,
    [IsActive] BIT NOT NULL DEFAULT 1, 
    CONSTRAINT [PK_EventSourceType] PRIMARY KEY CLUSTERED ([EventSourceTypeId] ASC)
);

