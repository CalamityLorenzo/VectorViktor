﻿CREATE TABLE [dbo].[DynamicUserJourney]
(
	[DynamicUserJourneyId]						INT IDENTITY (1, 1) NOT NULL, 
	[ValuationSubmissionId]						INT NOT NULL,
	[FastTrackOrBespokeTypeId]					SMALLINT NOT NULL, 
	[DeficitOrSurplusTypeId]					SMALLINT NOT NULL,
	[AdditionalRequiredDocumentTypeId]			SMALLINT NOT NULL,
	[IsMultiDocUpload]							BIT NOT NULL DEFAULT 0,
	[StartEventReference]						INT NOT NULL,
    [EndEventReference]							INT NULL,
	CONSTRAINT [PK_DynamicUserJourney] PRIMARY KEY CLUSTERED ([DynamicUserJourneyId] ASC),
    CONSTRAINT [FK_DynamicUserJourney_FastTrackOrBespokeType] FOREIGN KEY ([FastTrackOrBespokeTypeId]) REFERENCES [dbo].[FastTrackOrBespokeType] ([FastTrackOrBespokeTypeId]),
    CONSTRAINT [FK_DynamicUserJourney_DeficitOrSurplusType] FOREIGN KEY ([DeficitOrSurplusTypeId]) REFERENCES [dbo].[DeficitOrSurplusType] ([DeficitOrSurplusTypeId]),
	CONSTRAINT [FK_DynamicUserJourney_AdditionalRequiredDocumentType] FOREIGN KEY (AdditionalRequiredDocumentTypeId) REFERENCES [dbo].[AdditionalRequiredDocumentType] ([AdditionalRequiredDocumentTypeId]),
	CONSTRAINT [FK_DynamicUserJourney_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
    CONSTRAINT [FK_DynamicUserJourney_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_DynamicUserJourney_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
)
