﻿ CREATE TABLE [dbo].[ValuationSubmissionData] (
    [ValuationSubmissionDataId] INT              IDENTITY (1, 1) NOT NULL,
    [QuestionsAndResponses]     VARCHAR (MAX)    NOT NULL,
    [DocumentId]                INT              NOT NULL,
    [StartEventReference]       INT              NOT NULL,
    [EndEventReference]         INT              NULL,
    CONSTRAINT [PK_ValuationSubmissionData] PRIMARY KEY CLUSTERED ([ValuationSubmissionDataId] ASC),
    CONSTRAINT [FK_ValuationSubmissionData_Document] FOREIGN KEY ([DocumentId]) REFERENCES [dbo].[Document] ([DocumentId]),   
    CONSTRAINT [FK_ValuationSubmissionData_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmissionData_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO
CREATE NONCLUSTERED INDEX [IX_ValuationSubmissionData_DocumentId]
    ON [dbo].[ValuationSubmissionData] ([DocumentId] ASC)
    INCLUDE ([EndEventReference]);
GO
