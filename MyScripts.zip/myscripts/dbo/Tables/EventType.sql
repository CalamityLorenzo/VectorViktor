﻿CREATE TABLE [dbo].[EventType] (
    [EventTypeId]          SMALLINT NOT NULL,
    [EventTypeName] VARCHAR (75) NOT NULL,
    [EventTypeDescription] VARCHAR (200) NOT NULL,
    [IsActive] BIT NOT NULL DEFAULT 1, 
    CONSTRAINT [PK_EventType] PRIMARY KEY CLUSTERED ([EventTypeId] ASC)
);

