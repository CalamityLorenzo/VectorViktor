﻿CREATE TABLE [dbo].[ValuationSubmission] (
    [ValuationSubmissionId]         INT  IDENTITY (1, 1) NOT NULL,
    [ValuationSchemeId]             INT  NOT NULL,
    [SchemeValuationSubmissionId]   VARCHAR(255) NOT NULL,
    [EffectiveDate]                 DATE NOT NULL,
    [IsExcludedSubmission]          BIT  NOT NULL DEFAULT 0,
    [StartEventReference]           INT  NOT NULL,
    [EndEventReference]             INT  NULL,
    CONSTRAINT [PK_ValuationSubmission] PRIMARY KEY CLUSTERED ([ValuationSubmissionId] ASC),
    CONSTRAINT [FK_ValuationSubmission_ValuationScheme] FOREIGN KEY ([ValuationSchemeId]) REFERENCES [dbo].[ValuationScheme] ([ValuationSchemeId]),
    CONSTRAINT [FK_ValuationSubmission_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmission_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO
CREATE UNIQUE NONCLUSTERED INDEX [UX_SchemeValuation] 
    ON [dbo].[ValuationSubmission]([SchemeValuationSubmissionId]);    
GO
CREATE NONCLUSTERED INDEX [IX_ValuationSubmission_ValuationSchemeId]
    ON [dbo].[ValuationSubmission] ([ValuationSchemeId] ASC, [EffectiveDate] ASC)
    INCLUDE ([SchemeValuationSubmissionId], [IsExcludedSubmission], [StartEventReference], [EndEventReference]);
GO