﻿CREATE TABLE [dbo].[ValuationSubmittedDetail]
(
	[ValuationSubmittedDetailId]	INT IDENTITY (1, 1) NOT NULL,
	[ValuationSubmissionId]	INT NOT NULL,
	[SubmittedDateTime]		DATETIME2 NOT NULL,
	[StartEventReference]	INT NOT NULL,
    [EndEventReference]		INT NULL,
	CONSTRAINT [PK_ValuationSubmittedDetail] PRIMARY KEY CLUSTERED ([ValuationSubmittedDetailId] ASC),
	CONSTRAINT [FK_ValuationSubmittedDetail_ValuationSubmission] FOREIGN KEY ([ValuationSubmissionId]) REFERENCES [dbo].[ValuationSubmission] ([ValuationSubmissionId]),
	CONSTRAINT [FK_ValuationSubmittedDetail_Event_Start] FOREIGN KEY ([StartEventReference]) REFERENCES [dbo].[Event] ([EventReference]),
    CONSTRAINT [FK_ValuationSubmittedDetail_Event_End] FOREIGN KEY ([EndEventReference]) REFERENCES [dbo].[Event] ([EventReference])
);
GO
CREATE NONCLUSTERED INDEX [IX_ValuationSubmittedDetail_ValuationSubmissionId]
    ON [dbo].[ValuationSubmittedDetail] ([ValuationSubmissionId] ASC)
    INCLUDE ([SubmittedDateTime], [StartEventReference], [EndEventReference]);
GO
