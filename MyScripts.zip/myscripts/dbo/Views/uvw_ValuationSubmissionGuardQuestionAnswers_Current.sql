﻿CREATE VIEW dbo.uvw_ValuationSubmissionGuardQuestionAnswers_Current
AS
/*
-----------------------------------------------------------------------------------------------------------	
Created by: 	Denise Groves
Date: 			01/08/2024
Reason:			Return details of all guard questions and answers for each scheme 
				(Just excludes answers which have been subsequently changed, but includes inactive questions as they may still be valid for old tranches / submissions)
				
-----------------------------------------------------------------------------------------------------------
*/

	SELECT 
		s.ValuationSchemeId,
		s.PSRNumber,
		s.SchemeName,
		s.ValuationSubmissionId,
		s.SchemeValuationSubmissionId,
		s.EffectiveDate,
		gq.GuardQuestionId,
		gq.GuardQuestionName,
		gq.GuardQuestionDescription,
		gq.IsActive, 
		gqa.GuardQuestionAnswerId,
		gqa.GuardAnswerName,
		gqa.GuardAnswerDescription,
		vsgqa.ValuationSubmissionGuardQuestionAnswerId,
		vsgqa.StartEventReference,
		vsgqa.EndEventReference
	FROM 
		dbo.ValuationSubmissionGuardQuestionAnswer vsgqa
	INNER JOIN dbo.GuardQuestionAnswer gqa 
		ON gqa.GuardQuestionAnswerId = vsgqa.GuardQuestionAnswerId			
	INNER JOIN dbo.uvw_SchemeValuationSubmissions_Current s
		ON s.ValuationSubmissionId = vsgqa.ValuationSubmissionId
	INNER JOIN dbo.GuardQuestion gq
		ON gqa.GuardQuestionId = gq.GuardQuestionId
	WHERE 
		vsgqa.EndEventReference IS NULL