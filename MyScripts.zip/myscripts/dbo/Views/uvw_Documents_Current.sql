﻿CREATE VIEW dbo.uvw_Documents_Current
AS
/*
-------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Date: 			23/10/2024
Reason:			Return details of all documents, types and statuses
-------------------------------------------------------------------------------------------------------------------
*/

  SELECT  d.[DocumentId],
          d.[ValuationSubmissionId],
          d.[UploadedFileName],
          d.[InternalFileName],
          d.[FileHash],
          d.[FileSize],
          d.[SagaUploadedFileCorrelationId],
          d.[DocumentTypeId],
          dt.DocumentTypeDescription,
          d.[StartEventReference],
          d.[EndEventReference],
          ds.DocumentStatusId,
          dst.[DocumentStatusTypeId],
          dst.[DocumentStatusName],
          dst.[DocumentStatusDescription],
          dst.[IsActive]
  FROM 
	dbo.Document d
  INNER JOIN 
    dbo.DocumentType dt
  ON d.DocumentTypeId = dt.DocumentTypeId
  LEFT JOIN 
	dbo.DocumentStatus ds
  ON d.DocumentId = ds.DocumentId
  LEFT JOIN 
    dbo.DocumentStatusType dst
  ON dst.DocumentStatusTypeId = ds.DocumentStatusTypeId
  WHERE 
    d.EndEventReference IS NULL
  AND ds.EndEventReference IS NULL

GO