﻿CREATE VIEW [dbo].[uvw_ValuationSubmissionData_Current]
AS
/*
-------------------------------------------------------------------------------------------------------------------
Created by: 	Denise Groves
Date: 			16/01/2025
Reason:			Returns data extracted from StatementOfStrategy spreadsheet
-------------------------------------------------------------------------------------------------------------------
*/

	SELECT d.[DocumentId]
			,d.[ValuationSubmissionId]
			,sd.[ValuationSubmissionDataId]
			,sd.[QuestionsAndResponses]
			,e.[CreateDateTime]
			,e.[UserId] AS StartEventUser
			,e.[NotificationDate]
			,et.[EventTypeDescription] as CreateEvent
			,sd.[EndEventReference]
			,ee.[CreateDateTime] AS EndEventDateTime
			,ee.[UserId] AS EndEventUser
			,eet.[EventTypeDescription] as EndEvent
	FROM 
		[dbo].ValuationSubmissionData sd 
	INNER JOIN 
		[dbo].uvw_Documents_Current d
	ON d.DocumentId = sd.DocumentId
		AND d.DocumentTypeId = 2	--STATEMENT_OF_STRATEGY
		AND sd.EndEventReference IS NULL
	INNER JOIN dbo.Event e
		ON sd.StartEventReference = e.EventReference
	LEFT OUTER JOIN dbo.Event ee
		ON sd.EndEventReference = ee.EventReference
	LEFT OUTER JOIN dbo.EventType et
		ON e.EventTypeId = et.EventTypeId
	LEFT OUTER JOIN dbo.EventType eet
		ON ee.EventTypeId = eet.EventTypeId

GO	
