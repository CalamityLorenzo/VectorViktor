﻿CREATE TABLE [WebSagaEndpoint].[SubmitSchemeValuationSaga] (
    [Id]                                        UNIQUEIDENTIFIER NOT NULL,
    [Metadata]                                  NVARCHAR (MAX)   NOT NULL,
    [Data]                                      NVARCHAR (MAX)   NOT NULL,
    [PersistenceVersion]                        VARCHAR (23)     NOT NULL,
    [SagaTypeVersion]                           VARCHAR (23)     NOT NULL,
    [Concurrency]                               INT              NOT NULL,
    [Correlation_SchemeValuationSubmissionId]   NVARCHAR (255)   NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [Index_Correlation_SchemeValuationSubmissionId]
    ON [WebSagaEndpoint].[SubmitSchemeValuationSaga]([Correlation_SchemeValuationSubmissionId] ASC) WHERE ([Correlation_SchemeValuationSubmissionId] IS NOT NULL);

