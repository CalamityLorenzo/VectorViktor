﻿CREATE SCHEMA [WebEndpoint]
    AUTHORIZATION [dbo];

