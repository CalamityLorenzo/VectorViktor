﻿CREATE SCHEMA [SharePointEndpoint]
    AUTHORIZATION [dbo];

